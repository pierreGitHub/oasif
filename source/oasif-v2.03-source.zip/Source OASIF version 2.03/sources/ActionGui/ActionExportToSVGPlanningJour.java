/*
 * ActionExportToSVGPlanningJour.java
 *
 * Created on 27 mars 2006, 09:31
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ActionGui;

import Ctrl.planning.PlanningSVGgenerator;
import FunctionsTools.SVGFileFilter;
import Gui.IOASIF;
import Gui.JComposant;
import Gui.JFileChooser.JFileChooserGui;
import Gui.JOptionPane.JOptionPaneGui;
import java.io.File;
import java.io.IOException;
import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JFileChooser;

/**
 * ** Action sur le menu "Fichier --> Exporter --> Planning journali� en SVG (dans fenetre Planning journali�)
 *
 * @author Pierre
 */
public class ActionExportToSVGPlanningJour extends AbstractAction {
    JDialog ownerframe;
    String chemin;
    String extension = ".svg";
    JComposant _planningjour = null;
    
    /** Creates a new instance of ActionExportToSVGPlanningJour */
    public ActionExportToSVGPlanningJour(JDialog parentframe,JComposant planningjour) {
        ownerframe = parentframe;
       _planningjour =planningjour;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        boolean validFileChooser =  FileChooserAction();
        if (validFileChooser){
            PlanningSVGgenerator svg=new PlanningSVGgenerator(_planningjour);
            try {
                svg.generator(chemin +extension);
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean FileChooserAction(){
        boolean validFileChooser = false;
        SVGFileFilter _SVGFileFilter =new SVGFileFilter();
        // FILECHOOSER
        JFileChooserGui chooserSaveas = new JFileChooserGui();
        chooserSaveas.setFileFilter(_SVGFileFilter);
        chooserSaveas.setDialogType(JFileChooser.SAVE_DIALOG);
        chooserSaveas.setDialogTitle("Exporter planning courant en SVG...");
        chooserSaveas.setApproveButtonToolTipText("Enregistrer le fichier SVG");
        chooserSaveas.repaint();
        
        // Resultat de la box FILECHOOSEER
        while (chooserSaveas.showSaveDialog(ownerframe)== JFileChooser.APPROVE_OPTION) {
            extension = ".svg";
            chemin = chooserSaveas.getSelectedFile().getAbsolutePath();
            File fichier = new File(chemin);
            if (fichier.exists()){
                JOptionPaneGui confirmeRemplacer = new JOptionPaneGui();
                int Resultconfirm = confirmeRemplacer.showConfirmDialog(chooserSaveas,new String("Voulez-vous remplacer le fichier existant ?"),"Question",JOptionPaneGui.YES_NO_OPTION,JOptionPaneGui.QUESTION_MESSAGE);
                if (Resultconfirm == JOptionPaneGui.OK_OPTION ){
                    extension ="";
                    validFileChooser = true;
                    break;
                }
                
            } else{
                validFileChooser = true;
                break;
            }
        }
        
        return validFileChooser;
    }
}
