/*
 * ActionFiltreActivite.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 9 janvier 2006, 10:57
 */

package ActionGui;

import Ctrl.planning.oActivite;
import Gui.JBarreOutilsLocale;
import Gui.JComposant;
import data.XMLDoc.XMLUserObject;
import data.oasif.ACTIVITEType;
import data.oasif.DESCRIPTIF_ACTIVITEType;
import data.oasif.PROPRIETES_ACTIVITESType;
import data.oasif.nCARACTERISTIQUEType;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 *Action "Filtre Activite" sur planning MODULE
 *
 * @author Pierre
 */
public class ActionFiltreActivite extends AbstractAction {
    long _IDCaracteristique;
    ArrayList<Component> _listActivite=new ArrayList<Component>();
    JComposant _planning;
    JBarreOutilsLocale _jBarreOutilsLocale;
    String _intitule;
    
    /** Creates a new instance of ActionFiltreActivite */
    public ActionFiltreActivite(JBarreOutilsLocale jBarreOutilsLocale,ArrayList<Component> listActivite,long ID,JComposant planning,String intitule) {
        _IDCaracteristique = ID;
        _listActivite = listActivite;
        _planning = planning;
        _jBarreOutilsLocale = jBarreOutilsLocale;
        _intitule = intitule;
        
    }
    
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        _jBarreOutilsLocale.initFiltre();
        // Si non renseign�
        if (_IDCaracteristique == -1){
            
        } else {
            Icon filtreSelected = new ImageIcon(getClass().getResource("/ressources/img/btnliste_map_sel.png"));
            _jBarreOutilsLocale.jButtonActivite.setIcon(filtreSelected);
            _jBarreOutilsLocale.jButtonActivite.setToolTipText(_intitule);
            for(int i=0;i<_listActivite.size();i++) {
                oActivite _oActivitecourant =(oActivite)_listActivite.get(i);
                
                
                ACTIVITEType NodeActivite = (ACTIVITEType)((XMLUserObject)_oActivitecourant.getUserObject()).getXMLNode();
                PROPRIETES_ACTIVITESType _PROPRIETES_ACTIVITESType = XMLTools.ActiviteXMLProprietes.get_Proprietes(NodeActivite);
                DESCRIPTIF_ACTIVITEType _DESCRIPTIF_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_ACTIVITESType);
                nCARACTERISTIQUEType _nCARACTERISTIQUEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif_Caracteristique(_DESCRIPTIF_ACTIVITEType);
                long IDCaracteristique = _nCARACTERISTIQUEType.getValue().getValue();
                
                // Si la caract�ristique est le meme alors visible = true
                if (_IDCaracteristique != IDCaracteristique)
                    
                {
                    _oActivitecourant.setColor(new java.awt.Color(255,255,204));
                    _oActivitecourant.setAlphaComposite(0.55f);
                }
                
            }
        }
        
        
        
    }
}
