/*
 * ActionCopyModule.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 18 janvier 2006, 13:47
 */

package ActionGui;

import CopierColler.CutCopyPasteObject;
import Ctrl.ArbreFormation.NoeudUserObject;
import Ctrl.planning.oFormation;
import Ctrl.planning.oModule;
import Gui.IOASIF;
import data.XMLDoc.XMLUserObject;
import data.oasif.FORMATIONType;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.AbstractAction;

/**
 *Copie l'object Module dans l'objet Copier/Coller
 * @author Pierre
 */
public class ActionInitCopyModule extends AbstractAction {
    
    IOASIF _oasif;
    oModule _oModule;
    
    oFormation _oFormation;
    ArrayList<Date> listdate;
    FORMATIONType _FORMATIONType;
    
    /** Creates a new instance of ActionCopyModule */
    public ActionInitCopyModule(oModule o, IOASIF oasif) {
        _oasif = oasif;
        _oModule = o;
        _oFormation = (oFormation)_oasif.getJPanelTree().getNoeudUserObjectFormationofSelection().getoComposant();
        NoeudUserObject module = _oasif.getJPanelTree().oComposanttoNoeudUserObject(o);
        int _numero = module.getNumero();
        listdate=new ArrayList<Date>();
        _FORMATIONType = (FORMATIONType)((XMLUserObject)_oFormation.getUserObject()).getXMLNode();
        listdate = XMLTools.FormationXMLParametrage.getDatePlanifieofModule(_FORMATIONType,_numero);
        
    }
    public void doAction(){
        _oasif.setCopyPasteObject(new CutCopyPasteObject(_oFormation,_oModule, listdate));
        
    }
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        doAction();
    }
    
}
