/*
 * ActionManuelOASIF.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 20 juin 2006, 13:43
 *
 */

package ActionGui;

import Gui.IOASIF;
import com.Ostermiller.util.Browser;
import java.io.File;
import java.util.prefs.Preferences;
import javax.swing.AbstractAction;

/**
 *
 *Affiche le Manuel d'utilisation de OASIF dans le navigateur
 *
 * @author Pierre
 */
public class ActionManuelOASIF extends AbstractAction {
    IOASIF _oasif;
    /** Creates a new instance of ActionManuelOASIF */
    public ActionManuelOASIF(IOASIF oasif) {
        _oasif =oasif ;
    }
    
     public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        Browser.init();
        
        try{
            String chemin= _oasif.getPreferenceUser().get("_userDir", System.getProperty("user.dir")) + File.separator +"Aide" +File.separator +"index.htm";
            File file = new File(chemin);
            
            Browser.displayURL(file.toURL().toString());
        } catch (Exception e) {
            System.out.println("Exception : Action --> Manuel d'utilisation de OASIF" + e);
        }
        
    }
}
