/*
 * ActionExportToSCORM.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 *
 * Created on 6 novembre 2006, 09:07
 *
 * 
 */

package ActionGui;

import Exportation.ExportToSCORM;
import FunctionsTools.ZIPFileFilter;
import Gui.IOASIF;
import Gui.JFileChooser.JFileChooserGui;
import Gui.JOptionPane.JOptionPaneGui;
import java.io.File;
import javax.swing.AbstractAction;
import javax.swing.JFileChooser;

/**
 *
 *Action sur le menu "Fichier --> Exporter --> Planning courant --> Formation au format SCORM"
 *
 * @author pierre.chanussot
 */
public class ActionExportToSCORM extends AbstractAction {
    IOASIF oasif;
    String chemin;
    JFileChooserGui chooserSaveas;
    int _typeExport;
    String extension = ".zip";
    
    /** Creates a new instance of ActionExportToSCORM */
    public ActionExportToSCORM(IOASIF i,int typeExport) {
        oasif = i;
        _typeExport = typeExport;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
    
         boolean validFileChooser =  FileChooserAction();
        
        if (validFileChooser){
            ExportToSCORM _ExportToSCORM = new ExportToSCORM(oasif,chemin,_typeExport);
            oasif.getPreferenceUser().put("_LastFileChooser",chooserSaveas.getCurrentDirectory().getAbsolutePath());
        
        }
    
    }
    
     public boolean FileChooserAction(){
        boolean validFileChooser = false;
        ZIPFileFilter _ZIPFileFilter = new ZIPFileFilter();
        // FILECHOOSER
        chooserSaveas = new JFileChooserGui(oasif.getPreferenceUser().get("_LastFileChooser", ""));
        //chooserSaveas.setFileFilter(_ZIPFileFilter);
        chooserSaveas.setDialogType(JFileChooser.SAVE_DIALOG);
        chooserSaveas.setDialogTitle("Exporter en SCORM...");
        chooserSaveas.setApproveButtonToolTipText("Enregistrer le fichier SCORM");
        chooserSaveas.repaint();
        
        // Resultat de la box FILECHOOSEER
        while (chooserSaveas.showSaveDialog(oasif.getFrameOASIF())== JFileChooser.APPROVE_OPTION) {
            extension = ".zip";
            chemin = chooserSaveas.getSelectedFile().getAbsolutePath();
            File fichier = new File(chemin);
            if (fichier.exists()){
                JOptionPaneGui confirmeRemplacer = new JOptionPaneGui();
                int Resultconfirm = confirmeRemplacer.showConfirmDialog(chooserSaveas,new String("Voulez-vous remplacer le fichier existant ?"),"Question",JOptionPaneGui.YES_NO_OPTION,JOptionPaneGui.QUESTION_MESSAGE);
                if (Resultconfirm == JOptionPaneGui.OK_OPTION ){
                    extension ="";
                    validFileChooser = true;
                    break;
                }
                
            } else{
                validFileChooser = true;
                break;
            }
        }
        
        return validFileChooser;
    }
    
}
