/*
 * ActionExportToHTML.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 16 mars 2006, 11:35
 *
 */

package ActionGui;

import Exportation.ExportToHTML;
import FunctionsTools.HTMLFileFilter;
import Gui.IOASIF;
import Gui.JFileChooser.JFileChooserGui;
import Gui.JOptionPane.JOptionPaneGui;
import java.io.File;
import javax.swing.AbstractAction;
import javax.swing.JFileChooser;



/**
 *
 * Action sur le menu "Fichier --> Exporter --> Formation au format HTML"
 *
 * @author Pierre
 */
public class ActionExportToHTML extends AbstractAction {
    IOASIF oasif;
    File chemin;
    JFileChooserGui chooserSaveas;
    
    
    /** Creates a new instance of ActionExportToHTML */
    public ActionExportToHTML(IOASIF i) {
        oasif = i;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        boolean validFileChooser =  FileChooserAction();
        
        if (validFileChooser){
             ExportToHTML _ExportToHTML = new ExportToHTML(oasif,chemin);
             oasif.getPreferenceUser().put("_LastFileChooser",chooserSaveas.getCurrentDirectory().getAbsolutePath());
             
        }
        
    }
    
    public boolean FileChooserAction(){
        boolean validFileChooser = false;
        // FILECHOOSER
        chooserSaveas = new JFileChooserGui(oasif.getPreferenceUser().get("_LastFileChooser", ""));
        chooserSaveas.setFileFilter(new HTMLFileFilter());
        chooserSaveas.setDialogType(JFileChooser.SAVE_DIALOG);
        chooserSaveas.setDialogTitle("Exporter planning courant en HTML...");
        chooserSaveas.setApproveButtonToolTipText("Enregistrer le fichier HTML");
        chooserSaveas.repaint();
        
        // Resultat de la box FILECHOOSEER
        while (chooserSaveas.showSaveDialog(oasif.getFrameOASIF())== JFileChooser.APPROVE_OPTION) {
            String path = chooserSaveas.getSelectedFile().getAbsolutePath();
            chemin = new File(path);
            if (chemin.exists() && chemin.isDirectory()){
                JOptionPaneGui confirmeRemplacer = new JOptionPaneGui();
                int Resultconfirm = confirmeRemplacer.showConfirmDialog(chooserSaveas,new String("Voulez-vous copier les fichiers d'exportation dans ce r�pertoire ?"),"Question",JOptionPaneGui.YES_NO_OPTION,JOptionPaneGui.QUESTION_MESSAGE);
                if (Resultconfirm == JOptionPaneGui.OK_OPTION ){
                    validFileChooser = true;
                    break;
                }
                
            } else{
                validFileChooser = true;
                break;
            }
        }
        
        return validFileChooser;
    }
    
   
    
}
