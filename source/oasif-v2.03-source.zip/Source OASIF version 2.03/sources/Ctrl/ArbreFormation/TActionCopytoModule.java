/*
 * TActionCopytoModule.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 12 septembre 2005, 14:30
 */

package Ctrl.ArbreFormation;

import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;


/**
 *
 * @author Pierre
 */
public class TActionCopytoModule extends AbstractUndoableEdit {
    NoeudUserObject  _newParent,_oldParent; 
    NoeudUserObject  _source;
    NoeudUserObject  _sourceclone;
    int _oldnumero,_newnumero;
   
    JTreeFormation _jtreeformation;
    
    
    /** Creates a new instance of TActionCopytoModule */
    public TActionCopytoModule(JTreeFormation jtree,NoeudUserObject newParent,NoeudUserObject oldParent, NoeudUserObject source,int numero) {
     
        _newParent=newParent;
        _oldParent=oldParent;
        _source=source;
        _jtreeformation = jtree;
        _newnumero = numero ;
       
        _doAction();
        
    }
    /**Action effectuer */
     void _doAction() {
              
      _sourceclone = _source.clone();  
      _sourceclone.setNumero(_newnumero);
      _jtreeformation.updateNumModule(_newParent,_newnumero,2);
      _jtreeformation.moveModuleNode(_newParent,_sourceclone,_newnumero-1);    
     
     
    }
    public void die() {
    }
    // Redo by setting the button state as it was initially.
    public void redo() throws CannotRedoException {
        super.redo();
        _doAction();
    }
    
    // Undo by setting the button state to the opposite value.
    public void undo() throws CannotUndoException {
        super.undo();
         _jtreeformation.setFocus(_jtreeformation.NoeudUserObjecttoDefaultMutableTreeNodeFormation(_oldParent));
         _jtreeformation.removeNode(_sourceclone);
         _jtreeformation.updateNumModule(_newParent,_newnumero,1);
         _jtreeformation.setFocus(_jtreeformation.NoeudUserObjecttoDefaultMutableTreeNodeFormation(_source));
        
    }
}
