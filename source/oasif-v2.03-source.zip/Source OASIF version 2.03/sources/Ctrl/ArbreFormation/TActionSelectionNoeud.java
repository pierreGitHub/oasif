/*
 * TActionSelectionNoeud.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 23 juin 2005, 15:12
 */

package Ctrl.ArbreFormation;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

/**
 *
 * @author Pierre
 */
public class TActionSelectionNoeud extends AbstractUndoableEdit {
    NoeudUserObject noeuduserobject ;
    NoeudUserObject noeuduserobjectold ;
    TreeSelectionEvent _tse;
    ITreeEvent _treeEvent;
    JTreeFormation _jtreeformation;
    
    /** Creates a new instance of TActionSelectionNoeud */
    public TActionSelectionNoeud(ITreeEvent treeEvent,TreeSelectionEvent tse,JTreeFormation jtreeformation) {
        _tse = tse;
        _treeEvent = treeEvent;
        _jtreeformation = jtreeformation;
        
        // Ancien element selectionner
        DefaultMutableTreeNode nold =  (DefaultMutableTreeNode)tse.getOldLeadSelectionPath().getLastPathComponent();
        noeuduserobjectold = (NoeudUserObject)nold.getUserObject();
        //Element actuellement selectionner
        DefaultMutableTreeNode n = (DefaultMutableTreeNode)tse.getPath().getLastPathComponent();
        noeuduserobject = (NoeudUserObject)n.getUserObject();
        noeuduserobject.setPreviousClickNoeudUserObject(noeuduserobjectold);
        _doAction();
        
    }
    
    /**Action effectuer */
    void _doAction() {
        _treeEvent.treeClicked(noeuduserobject);
    }
    public void die() {
    }
    // Redo by setting the button state as it was initially.
    public void redo() throws CannotRedoException {
        super.redo();
        _jtreeformation.setFocus(_jtreeformation.NoeudUserObjecttoDefaultMutableTreeNodeFormation(noeuduserobject));
        _treeEvent.treeClicked(noeuduserobject);
    }
    
    // Undo by setting the button state to the opposite value.
    public void undo() throws CannotUndoException {
        super.undo();
        _jtreeformation.setFocus(_jtreeformation.NoeudUserObjecttoDefaultMutableTreeNodeFormation(noeuduserobjectold));
        _treeEvent.treeClicked(noeuduserobjectold);
     }
    
}
