/*
 * JPanelTabbedActivite.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * Created on 11 juillet 2005, 14:09
 */

package Ctrl.Proprietes.Activite;

import Ctrl.planning.oActivite;
import Gui.IOASIF;
import Gui.JTabbedPane.JPanelTabbedGen;
import data.oasif.ACTIVITEType;
import data.oasif.FORMATIONType;

/**
 *
 * "PanelParent" des onglets "Activite"
 *
 * @author Pierre
 */
public class JPanelTabbedActivite extends JPanelTabbedGen {
    JTabbedPaneActivite jTabbedPaneActivite;
    FORMATIONType _FORMATIONType ;
    ACTIVITEType _ACTIVITEType ;
    oActivite _oActivite;
    /** Creates a new instance of JPanelTabbedActivite */
    public JPanelTabbedActivite(ACTIVITEType nodeactivite,FORMATIONType nodeformation,oActivite composant,IOASIF o) {
        super();
        _FORMATIONType = nodeformation;
        _ACTIVITEType= nodeactivite;
        _oActivite = composant;
        jTabbedPaneActivite  = new JTabbedPaneActivite(_ACTIVITEType,_FORMATIONType,_oActivite,o);
        add(jTabbedPaneActivite, java.awt.BorderLayout.CENTER);
    }
    
    /**
     *Rend actif , inactif les champs
     *
     */
    public void refreshGlobalPropriete(){
        jTabbedPaneActivite.refreshGlobalPropriete();
    }
    
}
