/*
 * JPanelTabbedModule.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 11 juillet 2005, 14:06
 */

package Ctrl.Proprietes.Module;

import Ctrl.planning.oModule;
import Gui.IOASIF;
import Gui.JTabbedPane.JPanelTabbedGen;
import data.oasif.FORMATIONType;
import data.oasif.MODULEType;

/**
 *
 * "PanelParent" des onglets "Module"
 *
 * @author Pierre
 */
public class JPanelTabbedModule extends JPanelTabbedGen {
    JTabbedPaneModule jTabbedPaneModule;
    FORMATIONType _FORMATIONType;
    MODULEType _MODULEType;
    oModule _oModule;
    
    /** Creates a new instance of JPanelTabbedModule */
    public JPanelTabbedModule(MODULEType nodemodule,FORMATIONType nodeformation,oModule composant,IOASIF o) {
        super();
        _FORMATIONType = nodeformation;
        _MODULEType = nodemodule;
        _oModule = composant;
        
        jTabbedPaneModule  = new JTabbedPaneModule(_MODULEType,_FORMATIONType,_oModule,o);
        add(jTabbedPaneModule, java.awt.BorderLayout.CENTER);
    }
    
    /**
     *Rend actif , inactif les champs
     *
     */
    public void refreshGlobalPropriete(){
        jTabbedPaneModule.refreshGlobalPropriete();
    }
    
}
