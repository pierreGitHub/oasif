/*
 * JTabbedPaneSequence.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 11 juillet 2005, 11:04
 */

package Ctrl.Proprietes.Sequence;

import Ctrl.planning.oSequence;
import Gui.IOASIF;
import Gui.JTabbedPane.JPanelLeafTabbedPane;
import Gui.JTabbedPane.JTabbedPaneGen;
import OngletsProprietes.Sequence.SequenceOngletDescriptif;
import data.oasif.FORMATIONType;
import data.oasif.SEQUENCEType;
import javax.swing.JScrollPane;

/**
 *
 *JTABBEDPANE pour les onglets "SEQUENCE"
 *
 * @author Pierre
 */
public class JTabbedPaneSequence extends JTabbedPaneGen {
    
    JPanelLeafTabbedPane jPanelDescriptif;
    FORMATIONType _FORMATIONType ;
    SEQUENCEType _SEQUENCEType ;
    oSequence _oSequence;
    IOASIF oasif;
    
    /** Creates a new instance of JTabbedPaneSequence */
    public JTabbedPaneSequence(SEQUENCEType nodesequence,FORMATIONType nodeformation,oSequence composant,IOASIF o) {
           super();
        _FORMATIONType = nodeformation;
        _SEQUENCEType = nodesequence;   
        _oSequence = composant;
        oasif = o ;
        initComponents();
        // Titre des differents onglets
        String titreDescriptif = "Descriptif";
     
         // Ajoute les onglets au TabbedPane
        JScrollPane scrollpaneDescriptif = new JScrollPane();
        scrollpaneDescriptif.setViewportView(jPanelDescriptif);
        scrollpaneDescriptif.getVerticalScrollBar().setUnitIncrement(40);
        scrollpaneDescriptif.getHorizontalScrollBar().setUnitIncrement(40);
        addTab(titreDescriptif,scrollpaneDescriptif);
        
    }
    
     private void initComponents(){
           // Differents onglets du JTabbedPane
       jPanelDescriptif = new SequenceOngletDescriptif(_SEQUENCEType,_FORMATIONType,_oSequence,oasif);
     
    
        
        
    }
     
       /**
     *Rend actif , inactif les champs
     *
     */
    public void refreshGlobalPropriete(){
        jPanelDescriptif.refreshGlobalPropriete();
        
    }
    
}
