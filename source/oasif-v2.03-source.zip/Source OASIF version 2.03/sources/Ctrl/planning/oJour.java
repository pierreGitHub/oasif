/*
 * oJour.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 *
 * Objet oJour, container d'activit� pour un jour
 *
 * Created on 20 septembre 2005, 11:58
 */

package Ctrl.planning;

import Ctrl.planning.grille.IGridConstraint;
import java.awt.*;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
/**
 *
 * @author  njl
 */
public class oJour extends oComposant {
    
    // Pour que cet objet puisse redimentionner ou repositionner le planning en arri�re plan,
    // il faut ajouter les flags : PluginMngr.EAST_RESIZEABLE | PluginMngr.MOVEABLE | PluginMngr.MOVEABLE_TO_ROOT | PluginMngr.SOUTH_RESIZEABLE
    // dans les constructeurs.
    //
    // Le JPlanning (JJour) est d�j� cabl� pour effectuer les modifications de d�but et de taille
    // du planning.
    
    
    void _new(Rectangle r) {
        initGridBounds(r);
        setColor(new Color(255,255,255));
    }
    /**
     * Cr�ation d'un Jour par defaut
     */
    public oJour() {
        super(null,PluginMngr.FOCUSABLE, 2);
        _new(new Rectangle(1,1,29,12));
        
    }
    /**
     * Cr�ation d'un Jour
     *
     * @param g type IGridConstraint. L'interface de gestion des contraintes
     * @param r type Rectangle. Le rectangle de coordonn�s dans la grille (base 1) relatif � son parent
     */
    public oJour(IGridConstraint g, Rectangle r) {
        super(g,PluginMngr.FOCUSABLE,2);
        _new(r);
    }
    
    /**
     * Cr�ation d'un Jour
     *
     * @param b type long. Les comportements du composant
     * @param r type Rectangle. Le rectangle de coordonn�s dans la grille (base 1) relatif � son parent
     */
    public oJour(Rectangle r, long b) {
        super(null,b,2);
        _new(r);
    }
    
    /**
     * Clonage du Jour et de ses activit�s
     *
     * @param o type oModule. Le Jour de r�f�rence � dupliquer
     */
    public oJour(oJour o) {
        super(o);
        cloneActivites(o);
    }
    /**
     * Clonage du jour et de ses activit�s
     */
    public oJour clone() {
        return new oJour(this);
    }
    
    
    protected void cloneActivites(oJour o) {
        
        Iterator    it=o.getActivites().iterator();
        oActivite   a;
        while (it.hasNext()) {
            a=(oActivite)it.next();
            add(new oActivite(a));
        }
        
    }
    /**
     * Demande les activit�s du Jour
     *
     *  @return type ArrayList. La liste des activit�s (vide si aucune)
     */
    public ArrayList getActivites() {
        return getComposants(oActivite.class);
    }
    
}