/*
 * oIcon.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 13 octobre 2005, 15:02
 */

package Ctrl.planning;

import Ctrl.planning.grille.IGridConstraint;
import java.awt.*;
import java.awt.Composite;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.ImageIcon;

/**
 *
 * @author nicolas.lavoillotte
 */
public class oIcon extends oComposant {
    ImageIcon   _icon=new ImageIcon();
    int         _iconId;
     /**
      * Cr�ation d'une icon Activit�
      *
      * @param iconResource type string. Le nom de la ressource � charger
      * @param id type int. L'identifiant � associer.
      * @param x type int. Coordonn�e d'initialisation x base 1
      * @param y type int. Coordonn�e d'initialisation y base 1
      */
    public oIcon(String iconResource, int id, int x, int y) {
        super(null,0,0);
        _iconId=id;
        setBorderStyle(null);
        setRollOverBorderStyle(null);
        setAlphaComposite(null);
        setBehavior(0);

        
        _icon=new ImageIcon(getClass().getResource(iconResource));
        // Identifiant
        setUserID(id);
        
        initGridBounds(x, y, 1,1);
        
    }
    
    
    /**
     * Clonage d'une icon
     *
     * @param o type oIcon. L'icon de r�f�rence � dupliquer
     */
    public oIcon(oIcon o) {
        super(o);
    }
    
    protected void draw(Graphics g, int x, int y,Rectangle clip) {
        Graphics2D g2 = (Graphics2D)g;

        Rectangle   r=new Rectangle(x,y,_icon.getIconWidth(),_icon.getIconHeight());
        if (clip==null || clip.intersects(r)) 
            _icon.paintIcon(this, g2,x,y);
        
    }
    public void paintComponent(Graphics g) {
        draw(g, 0, 0,g.getClipBounds());
    }
    /**
     * Clonage d'une icon
     */
    public oIcon clone() {
        return new oIcon(this);
    }
    
    /** Clique (sans bouger) du composant*/
    public void componentClicked(PluginEvent e) {
        // L'�v�nement souris de base
        MouseEvent source=e.pluginAdapter.getModifierKey().getMouseEvent();
        // son point de clique
        Point p=source.getPoint();
        
        // translat� dans l'espace parent
        p.x+=getBounds().x;
        p.y+=getBounds().y;
        
        // Nouvelle �v�nment souris
        MouseEvent m=new MouseEvent(getParent(),source.getID(),source.getWhen(),source.getModifiers(),p.x,p.y,1,false);
        e.pluginAdapter.getModifierKey().setMouseEvent(m);
        
        // Transmission
        ((oComposant)getParent()).componentClicked(e);
    }
    
}
