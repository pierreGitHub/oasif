/*
 * PlanningPrinter.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 *
 * Created on 1 f�vrier 2006, 17:43
 */

package Ctrl.planning;

import Gui.JComposant;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Paper;
import java.awt.print.Printable;
import javax.print.attribute.standard.MediaSize;


/**
 *
 * @author nicolas.lavoillotte
 */
public class PlanningPrinter extends PlanningExporter implements Pageable, Printable {
    
    PageFormat          _pageFormat;
    int                 _pageCountX,_pageCountY, _pageCount;
    boolean             _bFitToPage;
    String              _title;
    
    void _init(boolean fitToPage) {
        _bFitToPage=fitToPage;
        Paper       A4=new Paper();
        A4.setSize(MediaSize.ISO.A4.getX(MediaSize.INCH)*72, MediaSize.ISO.A4.getY(MediaSize.INCH)*72);
        // Page en portait par defaut
        _pageFormat=new PageFormat();
        _pageFormat.setPaper(A4);
        
    }
    public PlanningPrinter() {
        _init(true);
    }
    
    /**
     * Instanciation du printer
     *
     * @param jc type JComposant. Un planning.
     * @param fitToPage type boolean. TRUE pour imprimer dans une une page, FALSE sur plusieurs pages
     */
    public PlanningPrinter(JComposant jc, boolean fitToPage) {
        super();
        
        _init(fitToPage);
        setTitle("");
        setPlanning(jc);
        
    }
    public void setPlanning(JComposant jc) {
        super.setPlanning(jc);
        // Choix d'une orientation adapt�e
        if (getWidth()<getHeight())
            _pageFormat.setOrientation(PageFormat.PORTRAIT);
        else
            _pageFormat.setOrientation(PageFormat.LANDSCAPE);
        fitToPage(_bFitToPage);
    }
    
    public void setTitle(String title) {
        _title=title;
    }
    /**
     * S�lection d'un format de mise en page.
     *
     * @param pf type PageFormat. Le format de page � utiliser.
     */
    public void setPageFormat(PageFormat pf) {
        _pageFormat=pf;
    }
    
    
    /**
     * S�lectionne l'ajustement � une page.
     *
     * @param fit type boolean. True pour ajuster � une page, false si non.
     */
    public void fitToPage(boolean fit) {
        
        _bFitToPage=fit;
        
        // Recalcule
        int x=(int)(getWidth()/_pageFormat.getImageableWidth());
        int y=(int)(getHeight()/_pageFormat.getImageableHeight());
        if (_bFitToPage)
            x=y=0;
        setPageCountXY(x+1,y+1);
        
    }
    /**
     *Renvoie le nombre de page total pour imprimer le planning.
     *
     * @return type int. Le nombre de pages
     */
    public int getNumberOfPages() {
        
        return _pageCount;
    }
    /**
     *Renvoie le nombre de page horizontale.
     *
     * @return type int. Le nombre de pages
     */
    public int getNumberOfPageX() {
        
        return _pageCountX;
    }
    /**
     *Renvoie le nombre de page total verticale.
     *
     * @return type int. Le nombre de pages
     */
    public int getNumberOfPageY() {
        
        return _pageCountY;
    }
    
    /**
     * Fixe le nombre de page horizontalement et verticalement.
     *
     * @param x type int. Le nombre de page horizontale. base 1
     * @param y type int. Le nombre de page verticale. base 1
     */
    public void setPageCountXY(int x, int y) {
        _pageCountX=Math.max(x-1,0);
        _pageCountY=Math.max(y-1,0);
        
        _pageCount=((_pageCountX+1)*(_pageCountY+1));
    }
    /**
     * Renvoie le format de page pour une poge donn�e.
     *
     * @param param type int. Le no de la page demand�e.
     * @return type PageFormat. Le format de page correspondant.
     */
    public PageFormat getPageFormat(int param) throws IndexOutOfBoundsException {
        return _pageFormat;
    }
    
    /**
     * Demande l'interface d'impression pour une page donn�e.
     *
     * @param param type int. Le no de la page demand�e.
     * @return type Printable. L'interface d'impression.
     */
    public Printable getPrintable(int param) throws IndexOutOfBoundsException {
        return this;
    }
    
    /**
     * Impression d'une page.
     *
     * @param g type Graphics. Le graphics de sortie.
     * @param pageFormat type PageFormat. Le format de page pour l'impression.
     * @param pageIndex type int. Le no de page base 0.
     *
     * @return type int. NO_SUCH_PAGE si plus de page, PAGE_EXISTS si non
     */
    double              dY,dX,ratio;
    public int print(java.awt.Graphics g, java.awt.print.PageFormat pageFormat, int pageIndex) throws java.awt.print.PrinterException {
        
        int                 n,x,y;
        Graphics2D          g2d = (Graphics2D)g;
        Rectangle           clip=null;
        Color               old;
        
        if (pageIndex>_pageCount)
            return NO_SUCH_PAGE;
        else {
            
            ratio=(double)((double)(getWidth())/getHeight());
            
            
            // 1ere translation : Les marges de base
            g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
            
            int y2 = g2d.getFontMetrics().getHeight();	//	leading + ascent + descent
            
            // Titre une seule fois (multi page ou non)
            if (pageIndex==0)
                g2d.drawString(_title, 0, y2);
            
            // Pied de page
            if (_pageCount>1)
                g2d.drawString("page "+(pageIndex+1),0,(int)(_pageFormat.getImageableHeight()+y2));
            
            // Seconde translation (cummul� avec la 1�re) 2 lignes de libre en haut
            g2d.translate(0, 2*y2);
            
            
            // Sur une ou plusieurs page
            dX=_pageFormat.getImageableWidth()*(_pageCountX+1)/getWidth();
            dY=((_pageFormat.getImageableHeight()*(_pageCountY+1))-2*y2)/getHeight(); // 2 lignes de libre en bas
            
            // R�duction sans perte de proportion
            // ratio = Math.min(Math.min(dX, dY), 1.0);
            // g2d.scale(ratio,ratio)
            g2d.scale(dX,dY);
            
            x=y=0;
            
            // Sur plusieurs pages ?
            //
            // calcule le clipping suivant le no de page
            if (!_bFitToPage) {
                clip=pageIndexToClip(pageIndex,0,2*y2);
                
                // translation de l'origine
                g2d.translate(-clip.x,-clip.y);
            }
            
            // Impression du planniung complet
            exportTo(g,x,y,clip);
            
            
            return PAGE_EXISTS;
        }
        
    }
    
    /**
     *
     * Calcule du rectangle d'impression suivant un no de page.
     *
     * @param pageIndex type int. Le no de page base 0.
     * @param ww type int. La marge en largeur � conserver.
     * @param hh type int. La marge en hauteur � conserver.
     * @return type Rectangle. Le rectangle d'impression.
     */
    protected Rectangle pageIndexToClip(int pageIndex, int ww, int hh) {
        Rectangle.Double    r2DAll=new Rectangle.Double();
        
        int                 x,y;
        
        //
        // Les pages d'index sont num�rot�s de 0 � _pageCount-1
        //
        // convertit la page d'index en no de page du "planning d�coup�".
        //
        // no de ligne = page/total page par ligne
        // no de colonne = reste de la division pr�c�dente
        //
        y=pageIndex/(_pageCountX+1);
        x=pageIndex % (_pageCountX+1);
        
        // Rectangle d'impression pour la page d'index donn�e
        r2DAll.setRect((_pageFormat.getImageableWidth()-ww)*x/dX,
                (_pageFormat.getImageableHeight()-hh)*y/dY,
                (_pageFormat.getImageableWidth()-ww)/dX,
                (_pageFormat.getImageableHeight()-hh)/dY);
        
        
        
        
        return r2DAll.getBounds();
    }
}