/*
 * oModule.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Objet oModule, container de oSequence ou oActivite
 *
 * Created on 25 novembre 2004, 10:53
 */

package Ctrl.planning;

import Ctrl.planning.grille.IGridConstraint;
import java.awt.*;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
/**
 *
 * @author  lolo, njl
 */
public class oModule extends oComposant {
    
    Color _colorModule,_colorEdit;
    void _initColor() {
        _colorModule=new java.awt.Color(153,153,204);
        _colorEdit=java.awt.Color.WHITE;
    }
    void _new(Rectangle r) {
        initGridBounds(r);
        _initColor();
        setColor(_colorModule);
    }
    /**
     * Cr�ation d'un module par defaut
     */
    public oModule() {
        super(null,PluginMngr.FOCUSABLE | PluginMngr.DOCKABLE | PluginMngr.MOVEABLE | PluginMngr.EAST_RESIZEABLE | PluginMngr.SOUTH_RESIZEABLE,2);
        _new(new Rectangle(1,1,29,4));
        
    }
    /**
     * Cr�ation d'un module
     *
     * @param g type IGridConstraint. L'interface de gestion des contraintes
     * @param r type Rectangle. Le rectangle de coordonn�s dans la grille (base 1) relatif � son parent
     */
    public oModule(IGridConstraint g, Rectangle r) {
        super(g,PluginMngr.FOCUSABLE | PluginMngr.DOCKABLE | PluginMngr.MOVEABLE | PluginMngr.EAST_RESIZEABLE | PluginMngr.SOUTH_RESIZEABLE,2);
        _new(r);
    }
    
    /**
     * Cr�ation d'un module
     *
     * @param b type long. Les comportements du composant
     * @param r type Rectangle. Le rectangle de coordonn�s dans la grille (base 1) relatif � son parent
     */
    public oModule(Rectangle r, long b) {
        super(null,b,2);
        _new(r);
    }
    
    /**
     * Clonage du module est de ses sequences
     *
     * @param o type oModule. Le module de r�f�rence � dupliquer
     */
    public oModule(oModule o) {
        super(o);
        _initColor();
        cloneSequences(o);
        cloneActivites(o);
    }
    
    /**
     * D�sactivation des comportements : d�pla�able, changement de taille avant �dition du module
     */
    public void editModule() {
        long    lFlgs=getBehavior();
        lFlgs &= ~PluginMngr.MOVEABLE;
        //lFlgs &= ~PluginMngr.FULL_RESIZEABLE;
        setColor(_colorEdit);
        setBehavior(lFlgs);
    }
    
    /**
     * R�activation des comportements : d�pla�able, changement de taille apr�s �dition du module
     */
    public void releaseModule() {
        long    lFlgs=getBehavior();
        lFlgs |= PluginMngr.MOVEABLE;
        lFlgs |= PluginMngr.SOUTH_RESIZEABLE | PluginMngr.EAST_RESIZEABLE;
        setColor(_colorModule);
        setBehavior(lFlgs);
    }
    /**
     * Clonage du module est de ses sequences
     */
    public oModule clone() {
        return new oModule(this);
    }
    protected void cloneSequences(oModule o) {
        
        Iterator    it=o.getSequences().iterator();
        oSequence   s;
        while (it.hasNext()) {
            s=(oSequence)it.next();
            add(new oSequence(s));
        }
    }
    protected void cloneActivites(oModule o) {
        
        Iterator    it=o.getActivites().iterator();
        oActivite   a;
        while (it.hasNext()) {
            a=(oActivite)it.next();
            add(new oActivite(a));
        }
        
    }
    /**
     * Demande les sequences du module.
     *
     *  @return type ArrayList. La liste des s�quences (vide si aucune s�quence)
     */
    public ArrayList<Component> getSequences() {
        
        return getComposants(oSequence.class);
    }
    
    /**
     * Demande seulement les activit�s du module
     *
     * @return type ArrayList. La liste des activit�s (vide si aucune activit�)
     */
    public ArrayList<Component> getActivites() {
        return getComposants(oActivite.class);
    }
    
    /**
     * Demande toutes les activit�s du module
     *
     * @return type ArrayList. La liste des activit�s (vide si aucune activit�)
     */
    public ArrayList<Component> getAllActivites() {
        ArrayList<Component> lActivites=getAllComposants(oComposant.class);
        oComposant  child;
        int         i=0;
        
        while (i<lActivites.size()) {
            child=(oComposant)lActivites.get(i);
            
            if (!(child instanceof oActivite))
                lActivites.remove(i);
            else
                i++;
        }
        return lActivites;
    }
    
    
    
    public void componentMoved(ComponentEvent c) {
        
        super.componentMoved(c);
        oActivite       activite;
        Iterator lActivites=getAllActivites().iterator();
        while (lActivites.hasNext()) {
            activite=(oActivite)lActivites.next();
            activite.updateIconPosition();
        }
        
        
    }
    
}