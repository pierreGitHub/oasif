/*
 * IComponentEvent.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 6 juin 2005, 17:53
 */

package Ctrl.planning;

import java.awt.Point;
import java.awt.Rectangle;


/**
 *
 * @author n.lavoillotte
 */
public interface IComponentEvent {
    
    /**
     * Un composant vient de bouger.
     * @param o type oComposant. Le composant.
     * @param grid type Point. Les coordonn�es en grille base 1 du composant.
     */
    public void componentMoved(oComposant o, Point grid);
    
    /**
     * Un composant vient de bouger.
     * @param o type oComposant. Le composant.
     * @param grid type Rectangle. Les dimensions en grille base 1 du composant.
     */
    public void componentResized(oComposant o, Rectangle grid);
    /**
     * Le composant vient d'�tre s�lectionn�/d�sselectionn�.
     * @param o type {@link oComposant}. Le composant s�lectionn�.
     * @param s type boolean. True le composant est s�lectionn�, false d�sselectionn�.
     */
    public void componentSelected(oComposant o,boolean s);
    
    /**
     * Le composant vient d'�tre cliqu�.
     * @param o type {@link oComposant}. Le composant cliqu�.
     * @param m type PluginMng.Modifier. L'�tat des touches de contr�le.
     */
    public void componentClicked(oComposant o, PluginMngr.ModifierKey m);
    
    
    /**
     * Le composant � r��u un entr�e clavier : tant que la touche est enfonc�e
     * @param o type {@link oComposant}. Le composant s�lectionn�.
     * @param k type int. Le code de touche
     * @param m type PluginMng.Modifier. L'�tat des touches de contr�le.
     */
    public void keyTyped(oComposant o, int k, PluginMngr.ModifierKey m );
    /**
     * Le composant � r��u un entr�e clavier : touche enfonc�e
     * @param o type {@link oComposant}. Le composant s�lectionn�.
     * @param k type int. Le code de touche
     * @param m type PluginMng.Modifier. L'�tat des touches de contr�le.
     */
    public void keyReleased(oComposant o, int k, PluginMngr.ModifierKey m );
    /**
     * Le composant � r��u un entr�e clavier : touche relach�e
     * @param o type {@link oComposant}. Le composant s�lectionn�.
     * @param k type int. Le code de touche
     * @param m type PluginMng.Modifier. L'�tat des touches de contr�le.
     */
    public void keyPressed(oComposant o, int k, PluginMngr.ModifierKey m );
}
