/*
 * IGridEevent.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Created on 28 septembre 2005, 13:30
 */

package Ctrl.planning.grille;

/**
 * Interface de sortie des �v�nements souris de la grille
 *
 * @author nicolas.lavoillotte
 */
public interface IGridEvent {

    /**  Evenements souris sur la cellule */
    
    public void celluleClicked(Cellules.CelluleEvent e);
    
    public void celluleEntered(Cellules.CelluleEvent e);
    
    public void celluleExited(Cellules.CelluleEvent e);
}
