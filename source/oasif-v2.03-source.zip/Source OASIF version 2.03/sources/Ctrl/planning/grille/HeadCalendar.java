/*
 * HeadCalendar.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Created on 26 mai 2005, 09:22
 *
 * Mise � jour : 20/09/2005 - ajout des heures/demies heures
 */

package Ctrl.planning.grille;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;
import java.awt.font.TextMeasurer;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.text.AttributedString;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * Gestion de l'ent�te des calendriers. Cette classe est charg�e d'afficher les ent�tes d'un calendrier de type
 * JCalendar.
 *
 * L'ent�te est orient�e verticalement ou horizontalement en fonction du calendrier de r�f�rence. L'orientation du texte peut �tre chang�
 * en s�lectionnant une g�ometrie d'affichage oppos� � la g�ometrie g�n�rale du planning
 *
 * Cette classe sert de base aux classes d�riv�es : {@link HeadYears}, {@link HeadMonths}, {@link HeadDays}, {@link HeadHours}, {@link HeadMinutes}
 * <pre>
 *
 * Les m�thodes � impl�menter dans ses classes sont :
 *
 *      initCalendar()                  // Appel� une fois avant instalation du calendrier d'en�te par setCalendar
 *
 *      getHeaderCondition()          // Appel� pour chaque cellule du calendrioer de r�f�rence
 *
 *      addCalendar()                   // Appel� pour faire avance le calendrier d'un pas *
 *      getCelluleObject()              // Appel� � chaque fois que la methode getHeaderCondition() renvoie 'vrai'
 *
 *
 * Les variables modifiables dans les classe d�riv�es :
 *      _flags                          // Type d'ent�te
 *      _wSize                          // La taille cumul�e des cellules de r�f�rence
 *      _celluleHeight                  // Hauteur d'une cellule ligne/colonne
 *      _celluleWidth                   // Largeur d'une cellule ligne/colonne
 *      _calendar                       // Copie du calendrier de r�f�rence � faire avancer
 *      _color
 *      _backColor                      // Couleur 1er et second plan de la celulle en cours de l'ent�te
 *
 * La m�thode setCalendar de cette classe sert de fonction principale pour d�marrer et cr�er 
 * des cellules d'ent�te call�e graphiquement sur les cellules de r�f�rence du calendrier. Elle 
 * effectue la proc�dure suivante :
 *
 * setCalendar(GridCalendar jc) {
 *
 *      Initialisaton avec initCalendar(jc)
 *
 *      dimensionnement du tableau de cellule
 *
 *      pour toutes les cellules du calendrier jc
 *
 *          si getHeaderCondition(cellule de r�f�rence, dimension de la cellule de r�f�rence,pas fini) est vrai
 *              pour la cellule en cours de l'ent�te
 *                  fixe l'objet  avec getCelluleObject
 *                  fixe les couleurs  avec _color, et _backColor
 *                  fixe la taille avec _wSize
 *          fin si
 *
 *          cummule la taille des cellules de r�f�rence dans _wSize
 *          
 *          avance le calendrier avec addCalendar()
 *
 *      fin    
 *
 *      s'il reste des cellulles d'ent�te � initialiser
 *          getHeaderCondition(cellule de r�f�rence, dimension de la cellule de r�f�rence,fin) est vrai
 *          pour la cellule en cours de l'ent�te
 *              fixe l'objet  avec getCelluleObject
 *              fixe les couleurs  avec _color, et _backColor
 *              fixe la taille avec _wSize
 *      fin si
 *      r�ajuste le nombre de cellule d'ent�te � sa taille minimale.
 *
 * </pre>
 * @author n.lavoillotte
 */
public class HeadCalendar extends CellulesCalendar  {
    
    /** Geometrie des cellules*/
    int             _geometryHeader=0;           
    /** Geometrie du texte dans les cellules */
    int             _geometryText=0;
    Font            _font=new Font("verdana",Font.BOLD, 12);
    
    /** Taille cumul�e des cellule de r�f�rence du calendrier*/
    protected   int   _wSize;
    /** Couleur de la cellule */
    protected   Color   _color,_backcolor;
    
    Dimension _dimCel=new Dimension();      // Dimension d'affichage des cellules
      
    void _drawCelluleDefault(Graphics g, int x, int y,Cellule aCel, int i) {
        // Le text
        String      txtCell=(String)aCel.getUserObject();
        if (txtCell!=null) {
            
            Graphics2D          g2=(Graphics2D)g;
            float               fx,fy;
            AffineTransform     oldAt=null;
            Font                oldFont=g2.getFont();
            g2.setFont(_font);
            FontRenderContext   frc=g2.getFontRenderContext();
            
            
            Rectangle2D     r2;
            Rectangle       celBounds=getCelluleBounds(i);
            Dimension       celDim=getCelluleDimension(i,_dimCel);
            
            boolean         cond=false;
            int             limit=txtCell.length()+1;
            String          aTxt=null;
            
            // Calcul la longueur du text � afficher en fonction de la place
            // disponible
            do {
                
                limit--;
                r2=_font.getStringBounds(txtCell,0, limit, frc);
                
                if (_geometryText==Cellules.VERTICAL)
                    cond=(r2.getWidth()>(double)celBounds.width);
                else
                    cond=(r2.getWidth()>(double)celBounds.height);
                
            } while (cond && limit>0);
            
            // S'il y a de place ?
            if (limit>0) {
                if (limit<txtCell.length())
                    if (limit-2>0)
                        aTxt=txtCell.substring(0,limit-2)+"...";
                    else
                        aTxt=null;
                else
                    aTxt=txtCell;
            }
            // S'il y a un text � afficher
            if (aTxt != null ) {
                g2.setColor(Color.WHITE);
                
                if (_geometryText==Cellules.VERTICAL) {
                    // Centr� dans la cellule
                    fx=(celDim.width/2.0f)-(float)r2.getCenterX();
                    fy=(celDim.height/2.0f)-(float)r2.getCenterY();
                    if (r2.getHeight()<=celDim.height && r2.getWidth()<=celDim.width)
                        g2.drawString(aTxt,(float)(x+fx),(float)(y+fy));
                } else {
                    // clockwise 90 degrees
                    AffineTransform at = new AffineTransform();
                    oldAt=g2.getTransform();
                    
                    
                    // Centr� dans la cellule
                    fx=(celDim.width/2.0f)-(float)r2.getCenterY();
                    fy=(celDim.height/2.0f)+(float)r2.getCenterX();
                    
                    // La translation = la position du draw(string)
                    at.setToTranslation((float)(x+fx),(float)(y+fy));
                    // applique la transforme
                    g2.transform(at);
                    
                    // La rotation
                    at.setToRotation(-Math.PI/2.0);
                    // Applique la transforme
                    g2.transform(at);
                    
                    // La translation �tant faite, �crit en 0,0
                    g2.drawString(aTxt,0.0f,0.0f);
                }
                
                if (oldAt!=null)
                    g2.setTransform(oldAt);
                if (oldFont!=null)
                    g2.setFont(oldFont);
            }
        }
    }

    /**
     * Cr�ation d'une instance
     *
     * @param jc type JCalendar le calendrier de r�f�rence pour le callage.
     * @param c type Color. Couleur de l'ent�te.
     * @param f type long. Type d'ent�te pour la classe d�riv�e
     */
    public HeadCalendar(GridCalendar jc, Color c, long f) {
        // Cr�ation d'une cellule de base
        super();
        setOptions(f);
        setColor(c);
        
        setGeometryText(jc.getGeometry());
        setLineCount(1);// Nombre de cellules virtuelles       
       
        
        // Initialisation
        setCalendar(jc);
     }
    /**
     * Cr�ation d'une instance
     *
     * @param jc type JCalendar le calendrier de r�f�rence pour le callage.
     * @param c type Color. Couleur de l'ent�te.
     * @param f type long. Type d'ent�te pour la classe d�riv�e
     * @param geoTxt type int. La geometry d'affichage du texte d'ent�te : Cellules.VERTICAL, Cellules.HORIZONTAL
     */
    public HeadCalendar(GridCalendar jc, Color c, long f, int geoTxt) {
        // Cr�ation d'une cellule de base
        super();
        _flags=f;
        setColor(c);
        
        setGeometryText(geoTxt);
        //setCelluleSize(sizeCel);
//        _celluleHeight=jc.virtualHeigh();
//        _celluleWidth =jc.virtualWidth();
        setLineCount(1);// Nombre de cellules virtuelles       
        
        // Initialisation
        setCalendar(jc);
    }    
    
    
    
    
    /**
     * Renvoie la g�om�trie en cours du texte.
     *
     * @return type int. VERTICAL, HORIZONTAL.
     */
    public int getGeometryText() {
        return _geometryText;
    }
    /**
     * S�lection de la geom�trie du texte.
     *
     * @param geoText type int : Cellule.COLUMS, CELLULE.HORIZONTAL.
     */
    public void setGeometryText(int geoTxt) {
        _geometryText=geoTxt;
    }

    /**
     * S�lection du nombre de ligne/colonne totale
     *
     * @param celluleCounte type int. Total cellule virtuelle.
     */
    public void setLineCount(int celluleCount) {
        _celluleCount=celluleCount;
    }
    
    
    /**
     * Dessine une cellule. Methode surcharg�e, appel� par Cellule.draw()
     *
     * @param g type Graphics. Le contexte
     * @param x type int. Coordonn� x de dessin.
     * @param y type int. Coordonn� y de dessin.
     * @param w type int. Largeur de la cellule (zoom�).
     * @param h type int. Hauteur de la cellule (zoom�).
     * @param i type int. Le no de la cellule base 0.
     */
    public void drawCellule(Graphics g, int x, int y,int w, int h, int i) {
        super.drawCellule(g, x, y, w,h, i);
        
        // Dessin de base des cellules par defaut
        _drawCelluleDefault(g, x, y, getCellule(i),i);
        
    }    
    
    
    /**
     * Renvoie la condition de changement de c�llules
     *
     * @param cel type Cellules.cellule. La cellule du planning de r�f�rence courante
     * @param celDim type Dimension. La dimension de la cellule.
     * @param finish type boolean. True pour le dernier appel, false si non.
     * @return type boolean. True/false
     */
    public boolean getHeaderCondition(Cellules.Cellule cel, Dimension celDim, boolean finish) {
        return true;
    }
    
    /**
     * L'objet � associer � la cellule.
     *
     * @return type String. La date format�e.
     */
    public Object getCelluleObjet() {
        return null;
    }
    
    /**
     * Fait avancer d'un pas le calendrier
     *
     */
    public void addCalendar() { 
        _calendar.add(Calendar.DAY_OF_YEAR,+1);
    }    
  
    /**
     * Pr�initialisation avant installation de l'ent�te
     *
     * @param jc type GridCalendar. Le caldenrier de r�f�rence (celui pass� � setCalendar())
     */
    public void initCalendar(GridCalendar jc) {
        _flags=jc.getOptions();

        _calendar=(Calendar)jc.getCalendar().clone();
        _geometryHeader=jc.getGeometry();
        // Le gap de la grille de r�f�rence (zoom�) ...
        // ... devient le gap (zoom 1), de l'ent�te
        setGap(jc.getGap()); 
         //
        // Les dimension de l'ent�te, suivent les dimensions du calendrier de r�f�rence
        //
        // Elle peuvent �tre ajust�e dans la classe d�riv�e.
        _celluleHeight=Math.round(jc.getVirtualHeight());
        _celluleWidth =Math.round(jc.getVirtualWidth());
        
    }
    /**
     * Selection d'une grille calendrier de r�f�rence pour construire l'ent�te
     *
     * @param jc type {@link GridCalendar}. La grille calendrier de r�f�rence.
     */
    public void setCalendar(GridCalendar jc) {
        // Le calendrier du planning en r�f�rence
        initCalendar(jc);
        
        int                 i,iWM;
        
        Cellules.Cellule    cel;
        Dimension           celDim=null;
        int                 nCount=jc.count();   // Nombre de cellules de r�f�rence
        
        
        // Le gap de la grille de r�f�rence (zoom�) ...
        int                 gap=jc.getGap();
        
        boolean             cond;

       

        // M�me nombre de c�llules que la r�f�rence pour simplifier
        // l'initialisation ; la taille exacte sera
        // r�-ajust�e en final
        Cellules.Cellule    cCells[]=null;
        cCells=newTable(nCount,new Cellule(),jc.getGeometry());
        
        _wSize=iWM=i=0;
        cond=false;
        _backcolor=null;
        
        do {
            // Une cellule de la grille de r�f�rence
            cel=jc.getCellule(i);
            celDim=jc.getCelluleDimension(i,_dimCel);
            
            // La condition de changement de cellule
            cond=getHeaderCondition(cel,celDim,false);
            
            //
            // Si changement de semaine/mois/ann�e
            if (cond && iWM<nCount) {
                
                //zone texte : date format�e
                cCells[iWM].setUserObject(getCelluleObjet());
                
                
                if (_geometryHeader==Cellules.VERTICAL)
                    cCells[iWM].setSize(_wSize-gap,_celluleHeight);
                else
                    cCells[iWM].setSize(_celluleWidth,_wSize-gap);
                
                cCells[iWM].setColor(_color);
                cCells[iWM].setBackColor(_backcolor);
                
                iWM++;
                cond=false;
                //
                // Red�marre � 0 la taille des cellules
                //
                _wSize=0;
                _backcolor=null;
            }
            
            
            if (_geometryHeader==Cellules.VERTICAL)
                // cumule les cellules
                _wSize+=(celDim.width+gap);
            else
                _wSize+=(celDim.height+gap);
            
            // Etape suivante
            addCalendar();
            
            i++;
        } while (i<nCount);
        
        // Termine tableau
        // Si changement de semaine/mois/ann�e
        //... dans la limite du tabeau
        if (iWM<nCount) {
            
            getHeaderCondition(cel,celDim,true);
            
            // L'objet associ� � la cellule
            cCells[iWM].setUserObject(getCelluleObjet());
            
            if (_geometryHeader==Cellules.VERTICAL)
                cCells[iWM].setSize(_wSize-gap,_celluleHeight);
            else
                cCells[iWM].setSize(_celluleWidth,_wSize-gap);
            
            cCells[iWM].setColor(_color);
            cCells[iWM++].setBackColor(_backcolor);
        }
        // R�ajuste la taille au nombre exacte de mois, semaine, ann�e
        resizeTable(iWM,cCells);        
        
    }
    
    /**
     * Affecte la couleur des cellules de l'ent�te.
     *
     * @param c type Color. La couleur des cellules.
     */
    public void setColor(Color c) {
        _color=c;
    }
    
}
