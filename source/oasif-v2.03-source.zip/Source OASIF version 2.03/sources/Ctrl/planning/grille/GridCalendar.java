/*
 * JCalendar.java
 *
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 4 mai 2005, 16:40
 */

package Ctrl.planning.grille;

import Ctrl.planning.PluginMngr;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Calendar;
import java.util.Date;



/**
 * <pre>
 * Cette classe d�riv�e de CellulesCalendar, permet de cr�er des grilles calendriers.
 * 
 * La grille peut �tre verticale ou horizontale. Les cellules qui la compose repr�sentent des colonnes quand la grille
 * est verticale, et des de lignes quand la grille est horizontale.
 *
 * Pour d�finir une grille il faut :
 *
 *      La geometry : VERTICAL, HORIZONTAL
 *      Le nombre de cellules (nombre de collonne ou nombre de lignes)
 *      La taille (verticale ou horizontal) de l'espace d'extention des cellules
 *      La taille d'une cellule (largeur/hauteur)
 *      voire : {@link GridCalendar#initCalendar}
 *
 * </pre>
 *
 * @author n.lavoillotte
 */
public class GridCalendar extends CellulesCalendar  {
    
    
    int             _model;
    int             _calendarUnite=1;
    
    /** Model de calendrier type jour */
    public static final int GRID_DAYS=1;
    /** Model de calendrier type heures */
    public static final int GRID_TIMES=2; 
    
    /**
     * Cr�ation d'une instance de calendrier type GRID_DAYS
     */
    public GridCalendar() {
        super();
        _model=GRID_DAYS;
    }
    
    /**
     * Cr�ation d'une instance de calendrier
     *
     * @param model type int. Le type de calendrier : GRID_DAYS / GRID_TIMES
     * @param unite type int. L'unit� de progression du calendrier (jours/minutes)
     */
    public GridCalendar(int model, int unite) {
        super();
        setCalendarUnite(unite);
        _model=model;
    }
    /**
     * Renvoie le calendrier en cours.
     *
     * @return type Calendar. Le calendrier en cours.
     */
    public Calendar getCalendar() {
        return _calendar;
    }
    
    /**
     * Renvoie la date de courrante de d�but du calendrier.
     * @return type Date. La date d�but du calendrier.
     */
    public Date getTime() {
        return _calendar.getTime();
    }
    /**
     * Renvoie le model en cours : GRID_DAYS,GRID_TIME 
     */
    public int getModel() {
        return _model;
    }
   
    /**
     * Fixe l'unit� utilis� pour faire avancer le calendrier.
     *
     * @param unite type int. L'unit� (jours ou minutes)
     **/
    public void setCalendarUnite(int unite) {    
        _calendarUnite=unite;
    }
    /**
     * Renvoie l'unit� utilis� pour faire avancer le calendrier.
     *
     * @return type int. L'unit�.
     */
    public int getCalendarUnite() {
        return _calendarUnite;
    }
    /**
     * Changement de calenrier. La dur�e, la taille et le nombre de ligne virtuelle
     * restent inchang�s.
     *
     * @param model type int. Le type de calendrier : GRID_DAYS / GRID_TIMES
     * @param cal type Calendar. Le nouveau calendrier de d�but.
     */
    public void setCalendar(Calendar cal) {
        initCalendar(cal,getGeometry(),count(),lineCount(),virtualHeigh(),virtualWidth());
    }
    /**
     *
     * Changement de calenrier. 
     *
     * @param cal type Calendar. Le calendrier associ�.
     * @param geo type int. La geometry : VERTICAL, HORIZONTAL
     * @param n type int le nombre de cellules.
     * @param l type int. La taille (verticale/horizontal) de l'espace d'extention des cellules
     * @param h type int. La hauteur virtuelle d'une cellule.
     * @param w type int. La largeur virtuelle d'une cellule.
     */
    public void setCalendar(Calendar cal, int geo, int n, int l, int h, int w) {
         initCalendar(cal,geo,n,l,h,w);
    }    
    /**
     *
     * Initialisation du calendrier.
     *
     * @param cal type Calendar. Le calendrier associ�.
     * @param geo type int. La geometry : VERTICAL, HORIZONTAL
     * @param n type int le nombre de cellules : (lignes ou colonnes).
     * @param l type int. La taille (verticale/horizontal) de l'espace d'extention des cellules : largeur ou hauteur qui est d�pendante de la g�om�trie.
     * @param h type int. La hauteur virtuelle d'une cellule.
     * @param w type int. La largeur virtuelle d'une cellule.
     *
     * <pre>
     * La taille totale des cellules = l * h (ou l * w suivant la geom�trie)
     *
     * <B>Pour une g�om�trie VERTICALE</B>
     *     n = nombre de cellule
     *     l = nombre de ligne virtuelles
     *
     *     la taile d'une cellules :
     *          largeur : w,
     *          hauteur :(l*h)
     *
     * <B>Pour une g�om�trie HORIZONTALE</B>
     *     n = nombre de cellule
     *     l = nombre de colonnes virtuelles
     *
     *     la taile d'une cellules :
     *          largeur :(l*w)
     *          hauteur : w
     * </pre>
     */
    public void initCalendar(Calendar cal, int geo, int n, int l, int h, int w) {
        
        int totalSize;
        
        _celluleHeight=h;        // Taille d'une cellule : largeur/hauteur
        _celluleWidth=w;         // Taille d'une cellule : hauteur/largeur
        
        _celluleCount=l;         // Nombre de cellules virtuelles
        _calendar=cal; 
        
        // R�servation des cellules 15x20 par defaut
        Cellules.Cellule cels[]=newTable(n,new Cellules.Cellule(15,20,Color.WHITE),geo);
       
        Calendar    today=Calendar.getInstance();
        Date        actualDate=_calendar.getTime();
        
        
        
        int         i,nMax=cels.length;
        
        if (_geometry==Cellules.VERTICAL)
            totalSize=l*h;       // Taille totale des cellules
        else
            totalSize=l*w;       // Taille totale des cellules
            
        // Couleur commune de fond
        setBackColor(new Color(204,204,204));
        for (i=0;i<nMax;i++) {
            
            cels[i].setColor(Color.WHITE);
            
            if (_geometry==Cellules.VERTICAL) {
                cels[i].setWidth(w);
                cels[i].setHeight(totalSize);
            }
            else {
                cels[i].setHeight(w);
                cels[i].setWidth(totalSize);
            }
        }
        
    }    
    
    
    
}
