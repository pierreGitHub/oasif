/*
 * GridHoursOfDay.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 22 septembre 2005, 10:12
 */

package Ctrl.planning.grille;

import java.awt.Color;
import java.util.Calendar;
import java.util.Date;

/**
 *
 *  Cette classe d�riv�e de GridCalendar, est charg�e de la gestion d'un planning :
 *      - Heure du jour.
 *
 * Il est possible de d�couper une heure au maximum de 60 minutes.
 * voir : {@link  GridHoursOfDay#setCalendar(Calendar, int, int, int, int, int) }
 *
 * @author nicolas.lavoillotte
 */
public class GridHoursOfDay extends GridCalendar {
    long            _flags=0;
    /** 
     * Creates a new instance of GridDays 
     *
     * @param cal type Calendar. Le calendrier associ�.
     * @param flgs type long. Flags de constructions
     * @param geo type int. La geometry : VERTICAL, HORIZONTAL
     * @param len type int. Le nombre de jours.
     * @param total type int. Le nombre de lignes.
     * @param h type int. La hauteur virtuelle d'une cellule.
     * @param w type int. La largeur virtuelle d'une cellule.
     * @param s type int. Le pas d'avance du calendrier.
     */
    public GridHoursOfDay(Calendar cal, long flgs, int geo, int len, int total, int h, int w,int s) {
        super(GridCalendar.GRID_TIMES, s);
        _flags=flgs;
        setCalendar(cal,geo,len,total,h, w);
    }
    
    public void setCalendar(Calendar cal) {
        setCalendar(cal,getGeometry(),count(),lineCount(),virtualHeigh(),virtualWidth());
    }
    /**
     *
     * Initialisation du calendrier.
     *
     * @param cal type Calendar. Le calendrier associ�.
     * @param geo type int. La geometry : VERTICAL, HORIZONTAL
     * @param len type int. Le nombre d'heure ou de minutes pour 24H
     * @param total type int. Le nombre de lignes.
     * @param h type int. La hauteur virtuelle d'une cellule.
     * @param w type int. La largeur virtuelle d'une cellule.
     *
     * <pre>
     * Le nombre d'heure ou de minute doit correspondre au plus
     * � 24 heures, soit un multiple de 1440 minutes (24 h)
     *
     * Le pas est calcul� de la mani�re suivante :
     *      len = nombre de ligne souhait�es
     *      pas = 1440/len 
     *
     * ex : len = 48, soit 30 minutes/lignes
     *      len = 96, soit 15 minutes/lignes
     *
     * </pre>
     */
    public void setCalendar(Calendar cal, int geo, int len, int total, int h, int w) {
        
        Cellules.Cellule aCel;
        Date        actualDate;
         
        int         i,nMax;
        int         aStep;
        int         toMinute=Calendar.getInstance().get(Calendar.HOUR_OF_DAY)*60+Calendar.getInstance().get(Calendar.MINUTE),
                    calendarUnite;
        Color       aColor;
        boolean     done=false;
        // R�servation cellules
        initCalendar(cal,geo,len,total,h,w);
        nMax=count();
        
        // Pas
        //calendarUnite=1440/nMax;//60/Math.max(1,(nMax/24));
        
        actualDate=getCalendar().getTime();
        
        for (i=0;i<nMax;i++) {
            // Une cellule
            aCel=getCellule(i);
            
            // Une �tape
            aStep=getCalendar().get(Calendar.HOUR_OF_DAY)*60+getCalendar().get(Calendar.MINUTE);
                        
            // Fixe la couleur de l'heure en cours au plus pr�s
            if (aStep>=toMinute && !done) {
                aColor=new Color(231,157,70);
                done=true;
            }
            else
                aColor=aCel.getColor();

            aCel.setColor(aColor);
            
            // �tape suivante
            getCalendar().add(Calendar.MINUTE,getCalendarUnite());
            
        }
        // Restaure date courrante
        getCalendar().setTime(actualDate);
    }      
}
