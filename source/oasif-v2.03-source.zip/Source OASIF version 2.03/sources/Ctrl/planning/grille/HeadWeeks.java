/*
 * HeadWeeks.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Created on 12 octobre 2005, 18:28
 */

package Ctrl.planning.grille;

import java.awt.Color;
import java.awt.Dimension;
import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 * Cette classe d�riv�e de {@link HeadCalendar} sert � construire une ent�te repr�sensant 
 * les semaines du calendrier de r�f�rence
 *
 * @author nicolas.lavoillotte
 */
public class HeadWeeks extends HeadCalendar {
    
    SimpleDateFormat    _dateFmt;
    int                 _oldWeek;
    Object              _obj; 
    /**
     * Cr�ation d'une instance
     *
     * @param jc type JCalendar le calendrier de r�f�rence pour le callage.
     */
    public HeadWeeks(GridCalendar jc) {
        super(jc,new Color(84,92,175),jc.getOptions());
        _obj=null;
    }
 
    
    void _init() {
        if ((_flags & GridDaysOfYear.GDOY_HEAD_WEEK)!=0)
            _dateFmt=new SimpleDateFormat("dd/MM/yy");// En toute lettres
        else
            _dateFmt=new SimpleDateFormat("w");    // En chiffre
        _oldWeek=_calendar.get(Calendar.WEEK_OF_YEAR);
        _obj=null;        
        if (getGeometry()==VERTICAL)
            _celluleHeight=20;
        else
            _celluleWidth=20;
    }
 
    
    /**
     * Renvoie la condition de changement de c�llules
     *
     * @param cel type Cellules.cellule. La cellule du planning de r�f�rence courante
     * @param celDim type Dimension. La dimension de la cellule.
     * @param finish type boolean. True pour le dernier appel, false si non.
     * @return type boolean. True/false
     */
    public boolean getHeaderCondition(Cellules.Cellule cel, Dimension celDim,boolean finish) {
        // Changement de semaine le lundi
        boolean cond;
        
        // En fin, avance jusqu'au lundi suivant pour que 
        // la semaine soit dat�e sur le lundi et non sur le dernier jour !
        do {
            cond=(_calendar.get(Calendar.DAY_OF_WEEK)==Calendar.MONDAY && _calendar.get(Calendar.WEEK_OF_YEAR)!=_oldWeek);
            if (finish && !cond)
                addCalendar();
            
        } while(finish && !cond);
        
        if (cond) {
            String      _head;
            _oldWeek=_calendar.get(Calendar.WEEK_OF_YEAR);

            // Recule de 7 jour pour ce caler sur la semaine �coul�e et non sur celle
            // en cours
            _calendar.add(Calendar.DAY_OF_YEAR, -7);
            if (_firstCall) {
               _head="Semaine du ";
               _firstCall=false;
            }
            else
                _head="";
            // texte de la semaine �coul�e !!
            _obj=(_head+_dateFmt.format(_calendar.getTime()));
            _calendar.add(Calendar.DAY_OF_YEAR, 7);

        }

        return cond;
    
    }
    
    /**
     * L'objet � associer � la cellule.
     *
     * @return type String. La date format�e.
     */
    public Object getCelluleObjet() {
        
        //zone texte : le dernier text format� avant changement d'�tape
        return _obj;   
        
    }
    
    /**
     * Fait avancer d'un pas le calendrier
     *
     */
    public void addCalendar() {
        // Le texte de la cellule avant l'avance du calendrier
        // 
        // Pour la derni�re semaine, c'est la date du dernier jour de la semaine qui est renvoy�e.
        // et non la date de d�but. ce n'est pas un bug c'est un fonctionement normal.
        _obj=_dateFmt.format(_calendar.getTime());
        super.addCalendar();
    }    
    boolean     _firstCall=false;
    
    /**
     * Pr�initialisation avant installation de l'ent�te
     *
     * @param jc type GridCalendar. Le caldenrier de r�f�rence (celui pass� � setCalendar())
     */
    public void initCalendar(GridCalendar jc) {
        super.initCalendar(jc);
        _init();
        _firstCall=true;
    }    
    
}
