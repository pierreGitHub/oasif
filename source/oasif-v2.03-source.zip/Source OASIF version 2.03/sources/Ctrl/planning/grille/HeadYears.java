/*
 * HeadYears.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Created on 12 octobre 2005, 16:54
 */

package Ctrl.planning.grille;

import java.awt.Color;
import java.awt.Dimension;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Cette classe d�riv�e de {@link HeadCalendar} sert � construire une ent�te repr�sensant 
 * les ann�es du calendrier de r�f�rence
 *
 * @author nicolas.lavoillotte
 */
public class HeadYears extends HeadCalendar {
    
    SimpleDateFormat    _dateFmt;
    int                 _oldYear;
    Object              _obj;     
     
    
    /**
     * Cr�ation d'une instance
     *
     * @param jc type JCalendar le calendrier de r�f�rence pour le callage.
     */
    public HeadYears(GridCalendar jc) {
        super(jc,new Color(255,153,102),0);
        _obj=null;
    }
    
    
    void _init() {
        _dateFmt=new SimpleDateFormat("yyyy");
        _oldYear=_calendar.get(Calendar.YEAR);
        if (getGeometry()==VERTICAL)
            _celluleHeight=20;
        else
            _celluleWidth=20;
    }
 
    
    /**
     * Renvoie la condition de changement de c�llules
     *
     * @param cel type Cellules.cellule. La cellule du planning de r�f�rence courante
     * @param celDim type Dimension. La dimension de la cellule.
     * @param finish type boolean. True pour le dernier appel, false si non.
     * @return type boolean. True/false
     */
    public boolean getHeaderCondition(Cellules.Cellule cel, Dimension celDim, boolean finish) {
       // Changement d'ann�e
       boolean cond=(_calendar.get(Calendar.YEAR)!=_oldYear);
       if (cond)
            _oldYear=_calendar.get(Calendar.YEAR);
       
       return cond;
    
    }
    
    /**
     * L'objet � associer � la cellule.
     *
     * @return type String. La date format�e.
     */
    public Object getCelluleObjet() {
        
        //zone texte : le dernier text format� avant changement d'�tape
        return _obj;   
        
    }
    
    /**
     * Fait avancer d'un pas le calendrier
     *
     */
    public void addCalendar() {
        // Le texte de la cellule avant l'avance du calendrier
        _obj=_dateFmt.format(_calendar.getTime());
        super.addCalendar();
    }    
        
    /**
     * Pr�initialisation avant installation de l'ent�te
     *
     * @param jc type GridCalendar. Le caldenrier de r�f�rence (celui pass� � setCalendar())
     */
    public void initCalendar(GridCalendar jc) {
        super.initCalendar(jc);
         _init();
    }
}
