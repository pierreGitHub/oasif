/*
 * JPlugin.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Created on 13 avril 2005, 09:59
 */

package Ctrl.planning;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.ComponentListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;



/**
 *
 * Gestionnaire de composants depla�able et enfichable les uns dans les autres.
 * <pre>
 *      Les composants sont d�riv�s de JComponent. Ils impl�mentent l'interface IPluginListener
 * pour recevoir les �v�nements du pr�sent manager.
 *
 *      Le manager est attach� � un Container qui sera le parent racine de tous les composants.
 *      C'est le manger qui ajoute les composants : addComponent(). Si un listener type undoablelistener
 *      lui est fourni, il lui transmetra ses actions pour �tre d�faites et refaites.
 *
 *      Chaque composant doit fournire :
 *          - une s�rie de comportement (MOVEABLE, DOCKABLE, ...) qui d�criera son fonctionnement
 *          - un niveau interne : 0 �tant le plus bas, n le plus haut. ce niveau servira � imbriquer
 *          les composants les uns dans les autres.
 *
 *
 * </pre>
 *
 * @author n.lavoillotte
 */
public class PluginMngr  {
    /**
     * Cette classe est charg� de mettre � jour l'�tat des touches de contr�le du clavier.
     *
     */
    public class ModifierKey {
        boolean _bShiftDown,_bCtrlDown,_bAltDown,_bAltGrDown,_bPopup;
        MouseEvent          _mouseEvent;
        public ModifierKey() {
            _mouseEvent=null;
            _bShiftDown=_bCtrlDown=_bAltDown=_bAltGrDown=false;
        }
        /**
         * Mise � jour de l'�tat des touches de contr�le
         *
         * @param keyEvent typ KeyEvent. Ev�nement clavier.
         */
        public void setModifierKey(KeyEvent keyEvent) {
            _bShiftDown=keyEvent.isShiftDown();
            _bCtrlDown =keyEvent.isControlDown();
            _bAltDown  =keyEvent.isAltDown();
            _bAltGrDown=keyEvent.isAltGraphDown();
            _bPopup    =false;
        }
        public void setMouseEvent(MouseEvent e) {
            _bPopup=e.isPopupTrigger();
            _mouseEvent=e;
            
            _bShiftDown=e.isShiftDown();
            _bCtrlDown =e.isControlDown();
            _bAltDown  =e.isAltDown();
            _bAltGrDown=e.isAltGraphDown();
        }
        public MouseEvent getMouseEvent() {
            return _mouseEvent;
        }
        
        /**
         * Renvoie l'�tat de la touche
         * majuscule
         * @return type booelan.
         */
        public boolean isShiftDown() {
            return _bShiftDown;
        }
        /**
         * Renvoie l'�tat de la touche
         * contr�le
         * @return type booelan.
         */
        public boolean isControlDown() {
            return _bCtrlDown;
        }
        /**
         * Renvoie l'�tat de la touche
         * alt
         * @return type booelan.
         */
        public boolean isAltDown() {
            return _bAltDown;
        }
        /**
         * Renvoie l'�tat de la touche
         * altGr
         * @return type booelan.
         */
        public boolean isAltGr() {
            return _bAltGrDown;
        }
        
        /**
         * Renvoie l'�tat du d�clancheur de memnu popup
         * @return type boolean.
         */
        public boolean isPopupTrigger() {
            return _bPopup;
        }
        
        /**
         * Renvoie l'�tat du bouton.
         * @return type boolean. True si le bouton 1 est enfonc�.
         */
        public boolean isButton1() {
            boolean res=false;
            if (_mouseEvent!=null)
                res=(_mouseEvent.getButton()==MouseEvent.BUTTON1);
            return res;
        }
        /**
         * Renvoie l'�tat du bouton.
         * @return type boolean. True si le bouton 2 est enfonc�.
         */
        public boolean isButton2() {
            boolean res=false;
            if (_mouseEvent!=null)
                res=(_mouseEvent.getButton()==MouseEvent.BUTTON2);
            return res;
        }
        /**
         * Renvoie l'�tat du bouton.
         * @return type boolean. True si le bouton 3 est enfonc�.
         */
        public boolean isButton3() {
            boolean res=false;
            if (_mouseEvent!=null)
                res=(_mouseEvent.getButton()==MouseEvent.BUTTON3);
            return res;
        }
        
    }
    
    int         _xMouseDown=0,
            _yMouseDown=0,
            _xOld=0,
            _yOld=0,
            _wOld=0,
            _hOld=0;
    
    Container   _parentRoot=null,
            _PluginComponentHote=null;               // le composant qui accueillera le sous composant.
    
    Color       _colorGhost=Color.LIGHT_GRAY,
            _colorFocus=Color.BLACK;
    
    
    
    boolean _bDragging=false,_bGhost=false;
    UndoableEditListener    _undoListener=null;
    KeyListener             _keyListener=null;
    ModifierKey             _modifierKey=new ModifierKey();
    
    Cursor _eastCursor=new Cursor(Cursor.E_RESIZE_CURSOR);
    Cursor _westCursor=new Cursor(Cursor.W_RESIZE_CURSOR);
    Cursor _northCursor=new Cursor(Cursor.N_RESIZE_CURSOR);
    Cursor _southCursor=new Cursor(Cursor.S_RESIZE_CURSOR);
    Cursor _moveCursor=new Cursor(Cursor.MOVE_CURSOR);
    Cursor _defaultCursor=new Cursor(Cursor.DEFAULT_CURSOR);
    
    
    
    /** Le composant est d�pla�able */
    public static long MOVEABLE=1;
    /** Le composant est enfichable dans un autre */
    public static long DOCKABLE=2;
    /** Le composant re�oit des evts souris de survolle (NC) */
    public static long ROLLOVERABLE=4;
    /** Le composant est s�lectionnable et re�oit des evts clavier */
    public static long FOCUSABLE=8;
    /** Le composant est d�pla�able sur la racine du container */
    public static long MOVEABLE_TO_ROOT=16;
    
    /** Le composant est retaillable par l'est*/
    public static long EAST_RESIZEABLE=128;
    /** Le composant est retaillable par le nord*/
    public static long NORTH_RESIZEABLE=256;
    /** Le composant est retaillable par le sud*/
    public static long SOUTH_RESIZEABLE=512;
    /** Le composant est retaillable par l'ouest*/
    public static long WEST_RESIZEABLE=1024;
    /** Le composant est retaillable globalement */
    public static long FULL_RESIZEABLE = EAST_RESIZEABLE | NORTH_RESIZEABLE | SOUTH_RESIZEABLE | WEST_RESIZEABLE;
    static Point  _rtos=new Point();
    public static void convertRectangleToScreen(Rectangle settingBounds, Component c) {
        _rtos.setLocation(settingBounds.x,settingBounds.y);
        SwingUtilities.convertPointToScreen(_rtos, c);
        settingBounds.x=_rtos.x;
        settingBounds.y=_rtos.y;
    }
    public static void convertRectangleFromScreen(Rectangle settingBounds, Component c) {
        _rtos.setLocation(settingBounds.x,settingBounds.y);
        SwingUtilities.convertPointFromScreen(_rtos, c);
        settingBounds.x=_rtos.x;
        settingBounds.y=_rtos.y;
    }
    PUndoableAction _actionRoot=null;
    PUndoableAction _lastAction=null;
    
    JComponent _getJComponent(MouseEvent evt) {
        JComponent  c=null;
        
        if (evt.getComponent() instanceof JComponent)
            c=(JComponent)evt.getComponent();
        return c;
    }
    JComponent _getJComponent(KeyEvent evt) {
        JComponent  c=null;
        
        if (evt.getComponent() instanceof JComponent)
            c=(JComponent)evt.getComponent();
        return c;
    }
    
    
    /**
     * S�lection du curseur suivant la zone survoll�e
     **/
    void _selectCursorArea(JComponent c, java.awt.event.MouseEvent evt) {
        Rectangle er = new Rectangle(c.getBounds().width-5,0,5,c.getBounds().height);
        Rectangle sr = new Rectangle(0,c.getBounds().height-5,c.getBounds().width,5);
        Rectangle nr = new Rectangle(0,0,c.getBounds().width,5);
        Rectangle or = new Rectangle(0,0,5,c.getBounds().height);
        boolean   s=isSelected(c);
        
        int     x,y;
        
        x=evt.getX();y=evt.getY();
        // Est
        if (s && er.contains(x,y) && isBehavior(c,EAST_RESIZEABLE) ){
            c.setCursor(_eastCursor);
        }
        // Sud
        else if (s && sr.contains(x,y) && isBehavior(c,SOUTH_RESIZEABLE)) {
            c.setCursor(_southCursor);
        }
        // Nord
        else if (s && nr.contains(x,y) && isBehavior(c,NORTH_RESIZEABLE)) {
            c.setCursor(_northCursor);
        }
        // Ouest
        else if (s && or.contains(x,y) && isBehavior(c,WEST_RESIZEABLE)) {
            c.setCursor(_westCursor);
        }
        // D�placement possible ?
        else if (s && isBehavior(c,MOVEABLE)) {
            c.setCursor(_moveCursor);
        } else
            c.setCursor(_defaultCursor);
        
    }
    
    /**
     * Dess�lection de tous les composant r�cursivement
     */
    void _unSelectAllTop(Container p) {
        
        // Dess�lection des autres composants
        for (int i=0;i<p.getComponentCount();i++){
            Component c=p.getComponent(i);
            
            if ( c instanceof JComponent ) {
                JComponent o = (JComponent)c;
                // S'il est s�lection�
                if (isSelected(o))
                    select(o,false);
                
                // Les suivants
                _unSelectAllTop(o);
            }
            
        }
        
    }
    /**
     *
     * D�placement d'un composant dans son parent ou dans le panel, � la recherche d'un h�te d'acceuil
     *
     */
    
    void _dragTo(JComponent c, MouseEvent evt) {
        int          x=evt.getX();
        int          y=evt.getY();
        Rectangle    rParent,r=new Rectangle();
        
        setDraggingMode(true);
        
        // Recherche un composant h�te enfant, depuis le parenrRacine
        Point p=SwingUtilities.convertPoint(c,x,y,_parentRoot);
        Component o=findComponentAt(c,_parentRoot,p.x,p.y);
        
        if (o!=null && o instanceof JComponent) {
            // Futur position du ghost
            r.setBounds(x-_xMouseDown,y-_yMouseDown,c.getWidth(),c.getHeight());
            // Info sur l'acceuil d'un composant enfant
            // Envoie : componentAdding
            if (!_Docking((JComponent)o,c,r)) {
                // Le composant n'est pas accept�, utilie le parent courrant du composant;
                // R�initialise la position du ghost sur l'ancienne position accept�e
                o=c.getParent();
                r.setBounds(_xOld,_yOld,_wOld,_hOld);
            }
            
        }
        
        // Dans tous les cas c'est le jPanel qui sera utilis� si la souris est dans
        // son rectangle et que le flag : MOVEABLE_TO_ROOT est d�fini pour ce composant.
        if (o==null && isBehavior(c,MOVEABLE_TO_ROOT)) {
            // Dans l'espace du grand-parent de parentRacine, compare la position de la souris avec le
            // rectangle enfant : parentRacine.
            p=SwingUtilities.convertPoint(c,x,y,_parentRoot.getParent());
            if (_parentRoot.getBounds().contains(p)) {
                o=_parentRoot;
            }
        }
        
        // Nouveau composant hote
        _PluginComponentHote=(Container)o;
        
        if (r.isEmpty()) {
            // Nouvelle position
            x-=_xMouseDown;
            y-=_yMouseDown;
            
            r.setBounds(_xOld=x,_yOld=y,_wOld=c.getWidth(),_hOld=c.getHeight());
        }
        // Info sur le changement de position/taille
        // Envoie : componentMoving
        if (_Moving(c,r)) {
            _xOld=r.x;
            _yOld=r.y;
//                            // Ajustement 'bas' apr�s correction (�vite de changer la hauteur des deux c�t�s � la fois)
//                r.setSize(_wOld,_hOld=c.getHeight()+(-r.y));
            
            _wOld=r.width;
            _hOld=r.height;
        }
//        // Info sur le changement de position/taille
//        // Envoie : componentResizing
//        if (_Resizing(c,r)) {
//            _wOld=r.width;
//            _hOld=r.height;
//        }
        
        paintGhost(c,_xOld,_yOld,_wOld,_hOld);
        
    }
    MouseMotionListener _mouseMotionListener;
    //
    MouseListener       _mouseListener;
    
    void _new(Container p, UndoableEditListener l) {
        
        setUndoableEditListener(l);
        setParentRoot(p);
        
        _mouseMotionListener=new MouseMotionListener() {
            
            public void mouseMoved(MouseEvent evt) {
                JComponent  c=_getJComponent(evt);
                _modifierKey.setMouseEvent(evt);
                if (c!= null && c.isEnabled())
                    moveComposant(c,evt);
            }
            
            public void mouseDragged(MouseEvent evt) {
                JComponent  c=_getJComponent(evt);
                _modifierKey.setMouseEvent(evt);
                if (c!= null && c.isEnabled())
                    _dragComposant(c,evt);
            }
        };
        
        _mouseListener=new MouseListener(){
            public void mouseClicked(MouseEvent evt){
                JComponent  c=_getJComponent(evt);
                _modifierKey.setMouseEvent(evt);
                if (c!= null && c.isEnabled())
                    clickComposant(c,evt);
            }
            public void mousePressed(MouseEvent evt){
                
                JComponent  c=_getJComponent(evt);
                _modifierKey.setMouseEvent(evt);
                if (c!= null && c.isEnabled())
                    pressedComposant(c,evt);
            }
            public void mouseReleased(MouseEvent evt){
                JComponent  c=_getJComponent(evt);
                _modifierKey.setMouseEvent(evt);
                if (c!= null && c.isEnabled())
                    releasedComposant(c,evt);
            }
            public void mouseEntered(MouseEvent evt){
                JComponent  c=_getJComponent(evt);
                _modifierKey.setMouseEvent(evt);
                if (c!= null && c.isEnabled())
                    enteredComposant(c,evt);
            }
            public void mouseExited(MouseEvent evt){
                JComponent  c=_getJComponent(evt);
                _modifierKey.setMouseEvent(evt);
                if (c!= null && c.isEnabled())
                    exitedComposant(c,evt);
            }
        };
        
        _keyListener=new KeyAdapter() {
            public void keyPressed(KeyEvent evt) {
                _modifierKey.setModifierKey(evt);
                JComponent  c=_getJComponent(evt);
                if (c!= null && c.isEnabled())
                    keypressedComposant(c,evt);
            }
            
            public void keyReleased(KeyEvent evt) {
                _modifierKey.setModifierKey(evt);
                
                JComponent  c=_getJComponent(evt);
                if (c!= null && c.isEnabled())
                    keyreleasedComposant(c,evt);
            }
            
            public void keyTyped(KeyEvent evt) {
            }
        };
        
        
    }
    
    
    /**
     * Instanciation du manager
     *
     * @param p type Container. Le container racine.
     */
    public PluginMngr(Container p) {
        _new(p,null);
    }
    
    /**
     * Instanciation du manager
     *
     * @param p type Container. Le container racine.
     * @param l type UndoableEditListener. L'interface qui g�rera la liste des actions : undo, redo.
     */
    public PluginMngr(Container p, UndoableEditListener l) {
        _new(p,l);
    }
    
    static String   s_iLevel        =new String("_iLevel"),
            s_lBehavior     =new String("_lBehavior"),
            s_bSelected     =new String("_bSelected");
    
    
    /**
     *
     * Recherche d'un composant situ� sous la souris par la position pass�e
     * en param�tre. La position est celle de la souris dans le container r. Elle est translat�e
     * dans les rep�res des sous-composants.
     * La recherche se fait r�cursivement en descandant au plus bas puis en remontant � l'inverse de l'ordre d'affichage (Z order)
     * pour trouver en 1er les composants de premier plan
     *
     * @param c type JComponent. Le composant de d�part (_parentRoot pour chercher dans tous les sous-composants depuis l'oigine)
     * @param r type Container. Le container qui contient le composant c.
     * @param x type int. La position x de la souris dans le container r.
     * @param y type int. La position y de la souris dans le container r.
     * @return o type Component. Le 1er composant trouv� null si aucun
     **/
    protected Component findComponentAt(JComponent c, Container r, int x, int y) {
        
        int             count=r.getComponentCount();
        Component       o=null,child;
        int             i;
        
        
        for (i=count-1;i>=0 && o==null;i--) {
            child=r.getComponent(i);
            
            // Descente dans le sous-composant
            if (child instanceof Container) {
                
                // Translation dans le rep�re enfant
                Point  p=SwingUtilities.convertPoint(r,x,y,child);
                o=findComponentAt(c,(Container)child, p.x,p.y);
            }
            
            // En remontant, teste si la souris est dans le rectangle du composant � l'exception
            // du composant courant
            if (o==null && child instanceof JComponent) {
                //System.out.println("child "+child);
                if (child.getBounds().contains(x,y) && child!=c)
                    o=(JComponent)child;
                
            }
        }
        
        return o;
    }
    /**
     * Recherche un rectangle d'intersection avec un autre composant fr�re de
     * niveau �gale au composant c.
     *
     * @param c type JComponent. Le composant de d�part.
     * @param p type Container. Le parent du composant c.
     * @param p type Container. Le container qui contient le composant c.
     * @param rBounds type Rectangle. Rectangle dans l'espace du container p, � intersect� avec un autre composant.
     * @return type boolean. True : il y a une intersection, rBounds contient le rectangle d'intersection. false : aucune. rBounds est un rectangle vide.
     */
    boolean findIntersectionComponent(JComponent c, Container   p, Rectangle rBounds) {
        
        Component   cChild=null;
        Rectangle   rIntersect=new Rectangle();
        int         i,count=p.getComponentCount();
        int         level=getLevel(c);
        
        for (i=0;i<count && rIntersect.isEmpty();i++) {
            cChild=null;
            if (p.getComponent(i) instanceof oComposant)
                cChild=p.getComponent(i);
            
            if (cChild !=null && cChild instanceof JComponent) {
                
                // Diff�rent du composant de base et de meme niveau ?
                if (cChild!=c && getLevel((JComponent)cChild)==level)  {
                    rIntersect=cChild.getBounds().intersection(rBounds);
                    //if (!rIntersect.isEmpty()) System.out.println("rIntersect ="+rIntersect);
                }
            }
            
        }
        rBounds.setBounds(rIntersect);
        return !rBounds.isEmpty();
    }
    /**
     * Insatllation/suppression de fonctionnements du composant.
     *
     * @param s type long. L'un des styles de comportements.
     * @param b type boolean. True installe le comportement, false le retire.
     */
    public void setBehavior(JComponent c, long s,boolean b) {
        Long _lBehavior=(Long)c.getClientProperty(s_lBehavior);
        
        if (b)
            _lBehavior|=s;
        else
            _lBehavior&=~s;
        
        c.putClientProperty(s_lBehavior, _lBehavior);
    }
    /**
     * Fonctionnement g�n�ral du compoosant.
     *
     * @param c type JComponent. Le composant � modigfier.
     * @param l type long. Les styles des comportement � s�lectionner
     */
    public void setBehavior(JComponent c, long l) {
        Long _lBehavior=(Long)c.getClientProperty(s_lBehavior);
        
        _lBehavior=l;
        c.putClientProperty(s_lBehavior,_lBehavior);
    }
    /**
     * S�lection du niveau du composant.
     *
     * @param l type int. Le niveau d'imbrication du composant. [0..n]
     */
    public void setLevel(JComponent c, int l) {
        Integer _iLevel=(Integer)c.getClientProperty(s_iLevel);
        
        _iLevel=l;
        c.putClientProperty(s_iLevel, _iLevel);
    }
    
    /**
     * Connection avec le gestionnaire undo/redo
     * @param l type UndoableEditListener. L'�couteur undo/redo
     */
    public void setUndoableEditListener(UndoableEditListener l) {
        _undoListener=l;
    }
    
    /**
     * Renvoie le niveau actuel du composant. [0..n]
     *
     */
    public int getLevel(JComponent c) {
        Integer _iLevel=(Integer)c.getClientProperty(s_iLevel);
        
        return _iLevel;
    }
    /**
     * S�lection du mode "d�placement de composant"
     *
     * @param s type boolean. Selectionne (true) ou dess�lectionne (false) le composant
     */
    protected void setDraggingMode(boolean b) {
        _bDragging=b;
    }
    
    
    /*
     * Renvoie l'�tat du mode "d�placement de composant"
     *
     * @return type boolean.
     */
    protected boolean isDraggingMode() {
        return _bDragging;
    }
    
    /**
     *
     * Renvoie si un ou des comportements sont actifs
     *
     * @param c type JComponent. Le composant enfant concern�.
     * @param s type long. Le comoortement test�.
     * @param type boolean. True le comportement est actif, false il ne l'est pas.
     */
    public boolean isBehavior(JComponent c, long s) {
        
        long _lBehavior=((Long)c.getClientProperty(s_lBehavior)).longValue();
        return ((_lBehavior & s)!=0);
    }
    
    /*
     * Renvoie l'�tat du fantome du composant.
     *
     * @return type boolean.
     */
    protected boolean hasGhost() {
        return _bGhost;
    }
    
    /**
     * Affichage d'un fant�me du composant courant � la position pass�e dans l'espace du composant,
     * et translat� dans l'espace du parent racine.
     */
    protected void paintGhost(JComponent c, int x, int y, int w, int h) {
        _bGhost^=true;
        
        Point p=SwingUtilities.convertPoint(c,x,y,_parentRoot);
        
        Graphics2D g2 = (Graphics2D)_parentRoot.getGraphics();
        g2.setXORMode(_colorGhost);
        g2.drawRect(p.x,p.y,w,h);
    }
    
    /**
     * Affichage d'un cadre pour marquer la s�lection.
     * Cette methode static peut �tre appel� par les composants enfant pour dessiner
     * la s�lection.
     *
     * @param g type Graphics. Le graphics d'affichage.
     * @param c type JComponent. Le composant concern�.
     */
    static float _dash1[] = {10.0f};
    static BasicStroke _dashed = new BasicStroke(1.0f,
            BasicStroke.CAP_ROUND ,
            BasicStroke.JOIN_ROUND,
            10.0f, _dash1, 0.0f);
    static RoundRectangle2D.Double _roundDashed=new RoundRectangle2D.Double();
    
    public static void paintSelection(Graphics g, JComponent c) {
        Graphics2D g2 = (Graphics2D)g;
        Color oldColor=g2.getColor();
        Stroke oldStroke=g2.getStroke();
        g2.setStroke(_dashed);
        
        g2.setColor(Color.GRAY);
        _roundDashed.setRoundRect(3, 3, c.getWidth()-6,c.getHeight()-6, 12,12);
        g2.draw(_roundDashed);
        //g2.drawRect(3,3,c.getWidth()-6,c.getHeight()-6);
        g2.setColor(oldColor);
        g2.setStroke(oldStroke);
    }
    
    /**
     * Initialise une liste de composants enfants en une seule fois. Les composants doivent �tre hierarchiquement
     * pla��.
     *
     * @param parent type Container. Le parent d'acceuil. si null, c'est _parentRoot qui est utilis�.
     * @param t type IPluginListener[]. Le tableau de composants � initialiser.
     */
    public void initComponent(IPluginListener[] t) {
        int     i;
        
        for (i=0;i<t.length;i++)
            initComponent(t[i]);
    }
    /**
     * Initialise un composant enfant.
     *
     * @param child type IPluginListener. Le composants � initialiser.
     */
    public void initComponent(IPluginListener child) {
        initComponent(child.getComponent(), child.getBehavior(), child.getLevel());
    }
    /**
     * Initialise un composant enfant.
     *
     * @param c type JComponent. Le composant � ajouter qui impl�mente l'interface {@link IPluginListener}.
     * @b type long. Les comportements du composant.
     * @l type int. Le niveau d'imbrication du composant. [0..n]
     */
    public void initComponent(JComponent c, long b, int l) {
        initClientProperties(c, b,l);
        addListeners(c);
    }
    /**
     * Reset d'un composant avant d'�tre retir� de son parent.
     * @param c type JComponent. Le composant � r�seter.
     */
    public void resetComponent(JComponent c) {
        // avant suppression !!
        resetClientProperties(c);
        // Suppression des listeners
        resetListeners(c);
    }
    
    /**
     * Ajoute un composant au panel en cours
     * @param parent type Container. Le container parent du composant c. si null, c'est _parentRoot qui est utilis�.
     * @param c type JComponent. Le composant � ajouter qui impl�mente l'interface {@link IPluginListener}.
     * @b type long. Les comportements du composant.
     * @l type int. Le niveau d'imbrication du composant. [0..n]
     **/
    public void addComponent(Container parent, JComponent c, long b, int l) {
        
        // Le parent n'est pas pr�cis�, utilise le parent racine.
        if (parent==null)
            parent=_parentRoot;
        
        // Pr�pare le composant
        initComponent(c, b,l);
        
        resetAllSelectionProperty(c);
        
        // Plus utilis� depuis le 14/06/05. L'action (undo/redo) est cr�e dan l'application principale
        // et non plus ici
        //        PActionAddComponent    actionAdd=new PActionAddComponent(parent,c,this);
        //        // Undo redo
        //        if (_undoListener != null)
        //            _undoListener.undoableEditHappened(new UndoableEditEvent(this,actionAdd));
        parent.add(c);
        
        parent.repaint();
        
        // Info sur le composant ajout�
        // envoie : componentAdded
        if (parent instanceof JComponent)
            _Docked((JComponent)parent,c);
        
        
    }
    
    /**
     * Ajoute un composant au container parent.
     * @param parent type Container. Le parent d'acceuil.
     * @param c type IPluginListener. Le composant � ajouter
     */
    public void addComponent(Container parent, IPluginListener c) {
        addComponent(parent,c.getComponent(),c.getBehavior(),c.getLevel());
    }
    
    /**
     * Ajoute un composant au container racine.
     * @param c type IPluginListener. Le composant � ajouter
     */
    public void addComponent(IPluginListener c) {
        addComponent(null,c.getComponent(),c.getBehavior(),c.getLevel());
    }
    /**
     * Demande le parent racine de tous les composants.
     *
     * @return type Container. La racine de tous les composants.
     */
    public Container getParentRoot() {
        return _parentRoot;
    }
    
    /**
     * Renvoie la classe d'information li�e au touche de contr�le.
     *
     * @return type ModifierKey. L'�tat actuels des touches maj, ctrl, alt ...
     */
    public ModifierKey getModifierKey() {
        return _modifierKey;
    }
    /**
     * Affectation de la racine du manager
     * @param p type Container. La nouvell racine du manager
     */
    public void setParentRoot(Container p) {
        _parentRoot=p;
    }
    /**
     * Suppression d'un composant. Le composant c est retir� de la liste des composants
     * du container parent.
     *
     * @param c type JComponent. Le composant � retirer
     */
    public void removeComponent(JComponent c) {
        removeComponent(null,c);
    }
    
    
    
    /**
     * Reset une liste de composants enfants en une seule fois. Les composants doivent �tre hierarchiquement
     * pla��.
     *
     * @param parent type Container. Le parent d'acceuil. si null, c'est _parentRoot qui est utilis�.
     * @param t type IPluginListener[]. Le tableau de composants � retirer.
     */
    public void resetComponent(IPluginListener[] t) {
        int     i;
        
        for (i=0;i<t.length;i++)
            resetComponent(t[i].getComponent());
    }
    
    /**
     * Suppression d'un composant. Le composant c est retir� de la liste des composants
     * du container parent, ces propri�t�s et ces listeners sont supprim�s
     *
     * @param parent type Container. Le container parent.
     * @param c type JComponent. Le composant � retirer
     */
    public void removeComponent(Container parent, JComponent c) {
        // Le parent n'est pas pr�cis�, utilise le parent racine.
        if (parent==null)
            parent=_parentRoot;
        
        // Plus utilis� depuis le 14/06/05. L'action (undo/redo) est cr�e dan l'application principale
        // et non plus ici
        //        PActionRemoveComponent    actionRemove=new PActionRemoveComponent(parent,c,this);
        //        // Envoie : componentAdded
        //        if (_undoListener != null)
        //            _undoListener.undoableEditHappened(new UndoableEditEvent(this,actionRemove));
        resetComponent(c);
        parent.remove(c);
        
        parent.repaint();
        
        //System.out.println("pm :"+parent);
    }
    /**
     * Supprime tous les �couteurs en cours.
     *
     * @param c type JComponent. Le compoonsant � r�initialiser.
     */
    protected void resetListeners(JComponent c) {
        c.removeMouseListener(_mouseListener);
        c.removeMouseMotionListener(_mouseMotionListener);
        c.removeKeyListener(_keyListener);
    }
    
    /**
     * Ajout des �couteurs de gestion.
     *
     *
     * @param c type JComponent. Le compoonsant � �couter.
     */
    protected void addListeners(JComponent c) {
        resetListeners(c);
        /**
         * Point de d�part principal des diff�rents �v�nements li�s au d�placament de la souris
         *
         *  mouseMoved
         *  mouseDragged
         *
         */
        c.addMouseMotionListener(_mouseMotionListener);
        
        
        /**
         * Point de d�part principal des diff�rents �v�nements li�s � la souris
         *  mouseClicked (pressed and released)
         *
         *  mousePressed
         *  mouseReleased
         *  mouseEntered
         *  mouseExited
         */
        c.addMouseListener(_mouseListener);
        
        // Si focusable pour les entr�es clavier ?
        if (isBehavior(c,FOCUSABLE)) {
            c.addKeyListener(_keyListener);
            c.setFocusable(true);
        }
    }
    
    /**
     * Effacement des propri�t�s du composants.
     *
     * @param c type JComponent. Le composant � nettoyer.
     */
    public static void resetClientProperties(JComponent c) {
        
        // Supression des propri�t�s
        c.putClientProperty(s_iLevel, null);
        c.putClientProperty(s_lBehavior, null);
        c.putClientProperty(s_bSelected, null);
    }
    /**
     * Effacement de la propri�t� "Selection" de tous les sous compsant
     *
     * @param c type JComponent. La racine des composants � nettoyer.
     */
    public void resetAllSelectionProperty(JComponent c) {
        for (int n=0;n<c.getComponentCount();n++) {
            if (c.getComponent(n) instanceof JComponent)
                resetAllSelectionProperty((JComponent)c.getComponent(n));
            
            c.putClientProperty(s_bSelected, new Boolean(false));
        }
    }

    /**
     * Initialisation d'un composant avant ajout. Cr�ation des propri�t�s de gestion.
     * @b type long. Les comportements du composant.
     * @l type int. Le niveau d'imbrication du composant. [0..n]
     */
    public static void initClientProperties(JComponent c, long b, int l) {
        // Cr�ation des propri�t�s
        c.putClientProperty(s_iLevel, new Integer(l));
        c.putClientProperty(s_lBehavior, new Long(b));
        c.putClientProperty(s_bSelected, new Boolean(false));
        
    }
    
    /**
     * Ajoute une action � la liste des actions undoable. S'il ni a pas d'action en cours,
     * une action racine est cr�e.
     *
     * @param a type {@link JPUndoableAction}. L'action � ajouter.
     *
     */
    public void addUndoableAction(PUndoableAction a) {
        
        if (_actionRoot==null) {
            _actionRoot=a;
            _lastAction=null;
        }
        
        addLastUndoableAction(a);//_actionRoot.addLink(a);
        
    }
    /**
     * Ajoute une action � la derni�re action ajout� par la m�thode {@link addUndoableAction(PUndoableAction a)}
     *
     * @param a type {@link JPUndoableAction}. L'action � ajouter. elle devient la derni�re action de la liste.
     */
    public void addLastUndoableAction(PUndoableAction a) {
        if (_lastAction!=null)
            _lastAction.addLink(a);
        _lastAction=a;
        
    }
    /**
     * Supprime tous les liens entre les actions, et r�initialise l'action racine � null
     */
    public void resetUndoableActions() {
        PUndoableAction    r=_actionRoot;
        while (r!=null) {
            r.dieLink();
            r=r._link;
        }
        _lastAction=_actionRoot=null;
    }
    /**
     *
     * Transment la liste des actions (action racine) au gestionnaire g�n�ral undo/redo
     * et r�initialise l'action racine � null.
     *
     */
    protected void sendUndoAbleActions() {
        if (_undoListener != null && _actionRoot!=null)
            _undoListener.undoableEditHappened(new UndoableEditEvent(this,_actionRoot));
        _actionRoot=null;
    }
    
    
    /**
     * D�placement de souris dans le composant avec changement de curseur en fonction des zones survoll�es.
     *
     * dans les rectangles Est,sud,nord,ouest du composant
     *
     */
    protected void moveComposant(JComponent  c, MouseEvent evt){

        // S�lection du curseur suivant la zonne survol�e
        _selectCursorArea(c,evt);
        
    }
    
    /**
     *
     * D�placement de la souris dans le composant avec le bouton enfonc�
     *
     */
    void _dragComposant(JComponent  c, MouseEvent evt) {
        int          x=evt.getX();
        int          y=evt.getY();
        
        
        //
        Rectangle   r=new Rectangle();
        
        // Ancienne position
        if (hasGhost())
            paintGhost(c,_xOld,_yOld,_wOld,_hOld);
        
        // En fonction du curseur, d�termine l'action � effectuer
        if (c.getCursor().getType()==Cursor.E_RESIZE_CURSOR) {
            r.setBounds(_xOld=0,_yOld=0,_wOld=x,_hOld=c.getHeight());
            // Info sur le changement de position/taille
            // Envoie : componentResizing
            if (_Resizing(c,r)) {
                _wOld=r.width;
                _hOld=r.height;
            }
            // Nouvelle position
            paintGhost(c, _xOld,_yOld,_wOld,_hOld);
        } else if(c.getCursor().getType()==Cursor.S_RESIZE_CURSOR) {
            r.setBounds(_xOld=0,_yOld=0,_wOld=c.getWidth(),_hOld=y);
            if (_Resizing(c,r)) {
                _wOld=r.width;
                _hOld=r.height;
            }
            // Nouvelle position
            paintGhost(c, _xOld,_yOld,_wOld,_hOld);
        } else if(c.getCursor().getType()==Cursor.N_RESIZE_CURSOR) {
            r.setBounds(_xOld=0,_yOld=y,_wOld=c.getWidth(),_hOld=c.getHeight()+(-y));
            // Info sur le changement de position/taille
            // Envoie : componentMoving
            if (_Moving(c,r)) {
                _xOld=r.x;
                _yOld=r.y;
                // Ajustement 'bas' apr�s correction (�vite de changer la hauteur des deux c�t�s � la fois)
                r.setSize(_wOld,_hOld=c.getHeight()+(-r.y));
            }
            // Info sur le changement de position/taille
            // Envoie : componentResizing
            if (_Resizing(c,r)) {
                _wOld=r.width;
                _hOld=r.height;
            }
            // Nouvelle position
            paintGhost(c, _xOld,_yOld,_wOld,_hOld);
        } else if(c.getCursor().getType()==Cursor.W_RESIZE_CURSOR) {
            r.setBounds(_xOld=x,_yOld=0,_wOld=c.getWidth()+(-x),_hOld=c.getHeight());
            // Info sur le changement de position/taille
            // Envoie : componentMoving
            if (_Moving(c,r)) {
                _xOld=r.x;
                _yOld=r.y;
                // Ajustement 'droit' apr�s correction (�vite de changer la largeur des deux c�t�s � la fois)
                r.setSize(_wOld=c.getWidth()+(-r.x),_hOld);
            }
            // Info sur le changement de position/taille
            // Envoie : componentResizing
            if (_Resizing(c,r)) {
                _wOld=r.width;
                _hOld=r.height;
            }
            // Nouvelle position
            paintGhost(c, _xOld,_yOld,_wOld,_hOld);
        } else if (c.getCursor().getType()==Cursor.MOVE_CURSOR) {
            _dragTo(c, evt);
        }
        
        
    }
    
    /**
     *
     * Int�rogation du composant : accueil d'un autre composant dont le niveau est inf�rieur au niveau courant.
     *
     * @param c type JComponent. Le composant source qui acceuillera le composant toDock
     * @param toDock type JComponent. Le composant � acceuillir
     * @param rDock type Rectangle. Le rectangle du ghost correspondant au composant toDock dans l'espace racine
     * @return type boolean. True le composant est accept�, false il est rejet�.
     */
    boolean _Docking(JComponent c, JComponent toDock, Rectangle rDock) {
        boolean bRes=false;
        
        if (isBehavior(toDock,DOCKABLE)) {
            PluginEvent p=new PluginEvent(c,PluginEvent.COMPONENT_ADDING,this,toDock,rDock);
            firePluginEvent(p);
            bRes=(p.addingComponent!=null);
        }
        return bRes;
    }
    
    void _Docked(JComponent c,JComponent toDock) {
        
        PluginEvent p=new PluginEvent(c,PluginEvent.COMPONENT_ADDED,this,toDock);
        firePluginEvent(p);
        
    }
    /**
     *
     * Int�rogation du composant : La taille est en train de changer, elle peut �tre modifi�e avant
     * d'�tre appliqu�e. Les coordonn�es sont relatifs au parent du composant.
     *
     * @param r type Rectangle. Nouvelle taille du composant.
     * @return type boolean. True le rectangle � chang�, false il est rest� tel quel.
     */
    boolean _Resizing(JComponent c, Rectangle r) {
        return firePluginEvent(new PluginEvent(c,PluginEvent.COMPONENT_RESIZING,this,r))>0;
    }
    
    
    /**
     *
     * Int�rogation du composant : La position est en train de changer, elle peut �tre modifi�e avant
     * d'�tre appliqu�e. Les coordonn�es sont relatifs au parent du composant.
     *
     * @param r type Rectangle. Coordonn�s de la nouvelle position du composant.
     * @return type boolean. True le rectangle � chang�, false il est rest� tel quel.
     */
    boolean _Moving(JComponent c, Rectangle r) {
        return firePluginEvent(new PluginEvent(c,PluginEvent.COMPONENT_MOVING,this,r))>0;
    }
    
    /**
     *
     * Information : la souris est entr�e dans le composant
     *
     * @param c type JComponent. Le composant concern�.
     */
    boolean _Entered(JComponent c) {
        return firePluginEvent(new PluginEvent(c,PluginEvent.COMPONENT_ENTERED,this))>0;
    }
    
    /**
     *
     * Information : la souris est sortie dans le composant
     *
     * @param c type JComponent. Le composant concern�.
     */
    boolean _Exited(JComponent c) {
        return firePluginEvent(new PluginEvent(c,PluginEvent.COMPONENT_EXITED,this))>0;
    }
    
    /**
     * S�lection/d�s�lection du composant (dessin du "focus")
     *
     * @param s type boolean. Selectionne (true) ou dess�lectionne (false) le composant
     */
    protected void select(JComponent c, boolean s) {
        PluginEvent e=new PluginEvent(c,PluginEvent.COMPONENT_SELECTED,this);
        e.selectComponent=s;
        
        Boolean _bSelected=(Boolean)c.getClientProperty(s_bSelected);
        _bSelected=s;
        
        c.putClientProperty(s_bSelected, _bSelected);
        
        firePluginEvent(e);
        
        //
        // Fait Gagner le focus pour les entr�s clavier
        if (s && isBehavior(c,FOCUSABLE))
            c.requestFocusInWindow();
    }
    /*
     * Renvoie l'�tat de s�lection du composant.
     *
     * @param c type JComponent. Le composant enfant concern�.
     * @return type boolean.
     */
    public static boolean isSelected(JComponent c) {
        
        Boolean _bSelected=(Boolean)c.getClientProperty(s_bSelected);
        return (_bSelected != null ? _bSelected:false);
        
    }
    
    /**
     *
     * D�clencheur d'�v�nement PluginEvent pour tous les listeners : IPluginListener impl�ment�s.
     *
     * @param e type {@link PluginEvent}. L'�v�nement � envoyer aux listeners.
     * @return type Int. Le nombre de listeners appel�s. [0..n]
     */
    protected int firePluginEvent(PluginEvent e) {
        
        ComponentListener[] l=e.getComponent().getComponentListeners();
        
        int                 n=0;
        for (int i=0;i< l.length;i++) {
            
            // Recherche du listener
            if (l[i]  instanceof IPluginListener) {
                
                switch (e.getID()) {
                    case PluginEvent.COMPONENT_MOVING :
                        ((IPluginListener)l[i]).componentMoving(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_RESIZING :
                        ((IPluginListener)l[i]).componentResizing(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_ADDING :
                        ((IPluginListener)l[i]).componentAdding(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_ADDED :
                        ((IPluginListener)l[i]).componentAdded(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_ENTERED :
                        ((IPluginListener)l[i]).componentEntered(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_EXITED :
                        ((IPluginListener)l[i]).componentExited(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_SELECTED :
                        ((IPluginListener)l[i]).componentSelected(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_CLICKED :
                        ((IPluginListener)l[i]).componentClicked(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_KEYRELEASED:
                        ((IPluginListener)l[i]).componentKeyReleased(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_KEYPRESSED:
                        ((IPluginListener)l[i]).componentKeyPressed(e);
                        n++;
                        break;
                    case PluginEvent.COMPONENT_KEYTYPED:
                        ((IPluginListener)l[i]).componentKeyTyped(e);
                        n++;
                        break;
                }
            }
        }
        return n;
    }
    
    /**
     *
     * Clique (mouse down + mouse up)d'un composant c sans bouger
     *
     */
    protected void clickComposant(JComponent c, MouseEvent evt) {
        PluginEvent e=new PluginEvent(c,PluginEvent.COMPONENT_CLICKED,this);
        // Dess�lection des autres composants
        _unSelectAllTop(_parentRoot);        // S�lection du composant courant
        select(c,true);
        firePluginEvent(e);
        
    }
    
    protected void enteredComposant(JComponent c, MouseEvent evt){
        if (!isDraggingMode() && !hasGhost())
            _Entered(c);
    }
    
    protected void exitedComposant(JComponent c, MouseEvent evt){
        
        if (!isDraggingMode() && !hasGhost())
            _Exited(c);
    }
    
    /**
     * Le bouton de la souris vient d'�tre relach�, ajoute le composant en cours
     * a la liste des composants de l'h�te destinataire.
     * Modifie la position et la taille du composant si besoin est.
     *
     */
    protected void releasedComposant(JComponent c, MouseEvent evt) {
        boolean     bChange=false;
        //System.out.println("_PluginComponentHote "+_PluginComponentHote);
        if (hasGhost())
            paintGhost(c,_xOld,_yOld,_wOld,_hOld);
        
        if (_PluginComponentHote!=null) {
            
            boolean     bDocked=false;
            if (!isSelected(c))
                _Exited(c);
            
            
            // Rectangle parent pour la de mise � jour
            Rectangle   rp=c.getBounds(),r=new Rectangle();
            
            // Nouvelle position et taille du composant d�plac�
            r.x     =_xOld+c.getX();
            r.y     =_yOld+c.getY();
            r.width =_wOld;
            r.height=_hOld;
            
            // Si changement de place, de taille, met � jour la zone parente
            if (!c.getBounds().equals(r)) {
                bChange=true;
                c.getParent().repaint(rp.x,rp.y,rp.width,rp.height);
                
                
                
                // Ajoute le composant courant chez l'hote trouv�
                if (c.getParent()!=_PluginComponentHote && isDraggingMode()) {
                    
                    // Nouvelle position du composant d�plac�
                    Point       o=new Point(r.x,r.y);
                    // Translation des coordonn�s vers le composant cible
                    Point       p=SwingUtilities.convertPoint(c.getParent(),o,_PluginComponentHote);
                    r.x=p.x;
                    r.y=p.y;
                    
                    // Ex�cute et ajoute l'action : moveComponent
                    addUndoableAction(new PActionMoveComponent(_PluginComponentHote,c));
                    bDocked=true;
                }
                
                
                // Ex�cute et ajoute l'action : setBounds
                // poste : componentMoved dans la queue des �v�nements (qui sera
                // interpr�t� apr�s l'ev�nement componentAdded !!)
                addUndoableAction(new PActionSetBounds(c,r));
                
                // Info sur le composant ajout�
                // envoie : componentAdded
                if (bDocked && _PluginComponentHote instanceof JComponent)
                    _Docked((JComponent)_PluginComponentHote,(JComponent)c);
                
                // Transmet les actions au manager de undo/redo
                sendUndoAbleActions();
                
            }
        }
        
        
        _PluginComponentHote=null;
        setDraggingMode(false);
        
        // click sur le composant (seulement si changement de place)
        //
        // Cette �mulation � �t� supprim� depuis la version 224 (Tortois SVN)
        // elle emp�chait le d�placament de l'objet oFormation dans le planning JFormation
//        if (bChange)
//            clickComposant(c,evt);
        
        
    }
    
    
    /**
     * Le bouton de la souris vien d'�tre enfonc�
     *
     */
    protected void pressedComposant(JComponent c, MouseEvent evt){
        // Dess�lection des autres composants
        //_unSelectAllTop(_parentRoot);
        
        // Garde une trace de la position du clique souris dans le composant courant
        _xMouseDown=evt.getX();
        _yMouseDown=evt.getY();
        
        // Taille et position pr�c�dente = taille et position courante
        _xOld=0;_yOld=0;
        _wOld=c.getWidth();_hOld=c.getHeight();
        
        //select(c,true);
        
        // Misea � jour du curseur
        _selectCursorArea(c,evt);
        
        _PluginComponentHote=c.getParent();
        
    }
    /**
     *
     * Une touche du clavier vient d'�tre enfonc�
     *
     * @param c type JComponent. Le composant concern�
     * @param evt type KeyEvent. L'�v�nement clavier.
     */
    protected void keypressedComposant(JComponent c, KeyEvent evt) {
        PluginEvent e=new PluginEvent(c,PluginEvent.COMPONENT_KEYPRESSED,this,evt.getKeyCode());
        firePluginEvent(e);
        
    }
    /**
     *
     * Une touche du clavier vient d'�tre relach�
     *
     * @param c type JComponent. Le composant concern�
     * @param evt type KeyEvent. L'�v�nement clavier.
     */
    protected void keyreleasedComposant(JComponent c, KeyEvent evt) {
        PluginEvent e=new PluginEvent(c,PluginEvent.COMPONENT_KEYRELEASED,this,evt.getKeyCode());
        firePluginEvent(e);
        
    }
    
}
