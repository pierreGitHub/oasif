/*
 * IPluginListener.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 15 avril 2005, 08:56
 */

package Ctrl.planning;

import java.awt.Component;
import java.awt.event.ComponentListener;
import javax.swing.JComponent;

/**
 *
 * Cet interface d�riv� de {@link ComponentListener}, �tend le �v�nements li�s au d�placement et changement de taille du composant.
 * 
 * @author n.lavoillotte
 */
public interface IPluginListener extends ComponentListener {
    /**
     * La souris est entr�e dans le composant
     * @param e type {@link PluginEvent}. L'�venemnt li� au comosant.
     */
    public void componentEntered(PluginEvent e);
    
    /**
     * La souris est sortie du composant
     * @param e type {@link PluginEvent}. L'�venemnt li� au composant.
     */
    public void componentExited(PluginEvent e);
    
    /**
     * Le composant est en cours de d�placement. Ses coordonn�es de position et de taille peuvent �tre chang�
     * avant d'�tre appliqu�.
     *
     * Le champ settingBounds de l'�v�nement PlugingEvent est public et modifiable.
     *
     * @param e type {@link PluginEvent}. L'�venemnt li� au composant.
     */
    public void componentMoving(PluginEvent e);
    
   /**
     * Le composant est en cours de changement de taille. Ses coordonn�es de position et de taille peuvent �tre chang�
     * avant d'�tre appliqu�.
     *
     * Le champ settingBounds de l'�v�nement PlugingEvent est public et modifiable.
     *
     * @param e type {@link PluginEvent}. L'�venemnt li� au composant.
     */
    public void componentResizing(PluginEvent e); 
    
    /**
     * Le composant va acceuillir un nouveau composant. 
     *
     * Le champ addingComponent de l'�v�nement PluginEvent est public. Il d�signe le composant qui sera ajout� au composant courant.
     */
    public void componentAdding(PluginEvent e);
    
   /**
     * Le composant vient d'acceuillir un nouveau composant. 
     *
     * Le champ addingComponent de l'�v�nement PluginEvent est public. Il d�signe le composant qui � �t� ajout� au composant courant.
     */
    public void componentAdded(PluginEvent e);
    
    /**
     * Le composant vient d'�tre s�lectionn�
     *
     * Le champ selectComponent de l'�v�nement PluginEvent donne l'�tat de s�lection du composant.
     */
    public void componentSelected(PluginEvent e);

    /**
     * Le composant vient d'�tre cliqu� (mouse down + mouse up) sans bouger
     *
     * Le champ selectComponent de l'�v�nement PluginEvent donne l'�tat de s�lection du composant.
     */
    public void componentClicked(PluginEvent e);
    
    /**
     * Le composant vient de recevoir une entr�e clavier
     *
     */
    public void componentKeyTyped(PluginEvent e);
    /**
     * Le composant vient de recevoir une entr�e clavier
     *
     */
    public void componentKeyReleased(PluginEvent e);
    /**
     * Le composant vient de recevoir une entr�e clavier
     *
     */
    public void componentKeyPressed(PluginEvent e);
    
   
    /**
     * Renvoie les flags de comportement du composant
     */
    public long getBehavior();
    
    /**
     * Renvoie le niveau du composant
     */
    public int getLevel();
    
    /**
     * Renvoie l'objet JComponent 
     */
    public JComponent getComponent();
}
