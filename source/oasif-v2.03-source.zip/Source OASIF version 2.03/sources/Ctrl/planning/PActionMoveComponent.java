/*
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
*/

package Ctrl.planning;

import java.awt.Container;
import java.awt.Rectangle;
import javax.swing.JComponent;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

/**
 *
 * @author n.lavoillotte
 */
public class PActionMoveComponent extends PUndoableAction {
    Container   _pHote,_parent;
    JComponent  _comp;
    
    
    
    void _doAction() {
        
        _parent.remove(_comp);
        _parent.repaint();
        _pHote.add(_comp);
    }
    
    /** instancie l'action */
    public PActionMoveComponent(Container p, JComponent c) {
        _pHote=p;
        _comp=c;
        _parent=c.getParent();
        
        _doAction();
        
    }
    
    
    public void die() {
        _comp=null;
        _pHote=null;
        dieLink();
    }
    
    
    
    // Redo by setting the button state as it was initially.
    public void redo() throws CannotRedoException {
        super.redo();
        
        _doAction();
        redoLink();
        
        _pHote.repaint();
    }
    
    // Undo by setting the button state to the opposite value.
    public void undo() throws CannotUndoException {
        super.undo();
        
        _pHote.remove(_comp);
        _pHote.repaint();
        _parent.add(_comp);
        
        undoLink();
        
    }
}
