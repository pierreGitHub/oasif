/*
 * oFormation.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Objet oFormation, container de oModule
 *
 * Created on 25 novembre 2004, 10:53
 */

package Ctrl.planning;

import Ctrl.planning.grille.IGridConstraint;
import java.awt.*;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
/**
 *
 * njl
 */
public class oFormation extends oComposant {
    
   void _new(Rectangle r) {
        initGridBounds(r);
        setColor(Color.WHITE);
    }
    
   /**
     * Cr�ation d'une formation par defaut
    */
    public oFormation() {
        super(null,PluginMngr.FOCUSABLE | PluginMngr.EAST_RESIZEABLE | PluginMngr.MOVEABLE | PluginMngr.MOVEABLE_TO_ROOT | PluginMngr.SOUTH_RESIZEABLE,3);
        _new(new Rectangle(1,1,30,65));        
    }
    
    /**
     * Cr�ation d'une formation
     *
     * @param g type IGridConstraint. L'interface de gestion des contraintes
     * @param r type Rectangle. Le rectangle de coordonn�s dans la grille (base 1) relatif � son parent
     */
    public oFormation(IGridConstraint g, Rectangle r) {
        super(g,PluginMngr.FOCUSABLE | PluginMngr.EAST_RESIZEABLE | PluginMngr.MOVEABLE | PluginMngr.MOVEABLE_TO_ROOT | PluginMngr.SOUTH_RESIZEABLE,3);
        _new(r);
    }
    /**
     * Clonage d'une formation
     * 
     * @param o type oFormation. La formation de r�f�rence � dupliquer
     */
    public oFormation(oFormation o) {
        super(o);
        cloneModules(o);        
    }
    
    /**
     * Clonage des modules de la formation
     *
     * @param o type oFormation. La formation de r�f�rence � copier.
     */
    protected void cloneModules(oFormation o) {
        
        Iterator    it=o.getModules().iterator();
        oModule     m;
        while (it.hasNext()) {
            m=(oModule)it.next(); 
            add(new oModule(m));
        } 
    }

    /**
     * Demande les modules de la formation.
     *
     *  @return type ArrayList. La liste des modules (vide si aucun module)
     */
    public ArrayList<Component> getModules() {
        return getComposants(oModule.class);
    }
    
}