/*
 * RenderTree.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 23 mai 2005, 09:18
 */

package Ctrl.ArbreFormation;




import Gui.Font.FontGui;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;


/**
 * Classe h�rit� de DefaultTreeCellRenderer {@link DefaultTreeCellRenderer} qui s'occupe du rendu visuel du Jtree
 *
 *
 * @author Pierre
 */
public class RenderTree extends DefaultTreeCellRenderer {
    private DefaultTreeCellRenderer DefaultRenderer = new DefaultTreeCellRenderer();
    /** Creates a new instance of RenderTree */
    public RenderTree() {
        super();
        
    }
    
    public Component getTreeCellRendererComponent(
            JTree tree,
            Object value,
            boolean sel,
            boolean expanded,
            boolean leaf,
            int row,
            boolean foc) {
        Icon imagerep = new ImageIcon(getClass().getResource("/ressources/static/dossier.png"));
        
        DefaultRenderer.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, foc);
        DefaultRenderer.setPreferredSize(new Dimension(300,18));
        
        
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
        
        NoeudUserObject userobject = null;
        
        if (!node.isRoot()){
            userobject = (NoeudUserObject) node.getUserObject();
            DefaultRenderer.setToolTipText(userobject.getLabel());
        }
        
        // Partie graphique du JTREE
        Color gris = new Color(204,204,204);
        Color jaune = new Color(255,201,102);
        DefaultRenderer.setBackgroundSelectionColor(gris);
        DefaultRenderer.setFont(new FontGui(FontGui.PLAIN,10));
        Color bleunuit = new Color(0,51,102);
        DefaultRenderer.setTextNonSelectionColor(bleunuit);
        DefaultRenderer.setTextSelectionColor(bleunuit);
        
        // Niveau du noeud
        int depth = node.getLevel();
        
        switch (depth) {
            // Niveau ROOT (Formation(s) ouverte(s):)
            case 0 :
                
                
                
                break;
                // Niveau FORMATION
            case 1 :
                
                
                DefaultRenderer.setIcon(userobject.getIcon());
                
                
                break;
                // Niveau MODULE
            case 2 :
                
                
                DefaultRenderer.setIcon(userobject.getIcon());
                
                
                
                break;
                
                
                
            default :
                
                break;
        }
        
        return DefaultRenderer;
    }
    
    
}
