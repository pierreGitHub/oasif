/*
 * JGrid.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Cette classe d�riv�e de JComponent sert de container parent au grile type GridDaysOfYear, GridHoursOfDay
 *
 * Created on 6 mai 2005, 11:49
 */

package Ctrl.planning.grille;

import Ctrl.planning.IComponentEvent;
import Ctrl.planning.PluginMngr;
import Ctrl.planning.PluginMngr.ModifierKey;
import Ctrl.planning.grille.IGridEvent;
import Ctrl.planning.oComposant;
import Ctrl.planning.oFrise;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import javax.swing.JComponent;
import javax.swing.event.MouseInputAdapter;

/**
 * Cette classe est charg�e de la visualisation des objets de type {@link Cellules}. Elle impl�mente l'interface {@link IGridConstraint} pour
 * r�pondre au convertion de coordonn�s grille <--> pixels
 * Elle impl�mente l'interface mouseInputAdapter pour r�pondre au message souris au travers de l'interface IGridEvent
 *
 *
 * @author n.lavoillotte
 */
public class JGrid extends JComponent implements IComponentEvent {
    
    Dimension           _area=new Dimension(0,0);
    Cellules            _grille;
    IGridConstraint     _gridConstraint;
    PluginMngr          _pluginMngr=null;
    IGridEvent          _gridEventListener;

    // Initialise la largeur, hauteur total de la grille
    void _new(Cellules cells, IGridEvent listener) {
        _grille=cells;
        _gridEventListener=listener;
        setBackground(Color.RED);
        // Mise en route de la gestion des tooltip par un appel vide
        setToolTipText("");
        
        //
        // Gestion des contraintes
        // Interface IGridConstraint
        //
        //
        // Contraintes
        // Ajustement taille et position
        //
        _gridConstraint=new GridAdapter(this,_grille) {};
        
        
    }
    /**
     * Creation d'une instance de grille
     */
    public JGrid() {
        _new(new Cellules(),null);
    }
    
    public JGrid(Cellules grid) {
        _new(grid,null);
    }
    public JGrid(Cellules grid,IGridEvent listener) {
        _new(grid,null);
    }
    
    /**
     * Renvoie l'objet Grille en cours.
     *
     * @return type Cellules.
     */
    public Cellules getGrid() {
        return _grille;
    }
    
    public void reset() {
        _gridConstraint=null;
        _pluginMngr=null;
    }
    /**
     * Surcharge de la m�thode de base pour renvoyer le text correspondant � la cellule
     */
    public String getToolTipText(MouseEvent e) {
        String      ret=null;
        Point       p=e.getPoint();
        int         n;
        
        // La ligne et la colonne 1
        int c1=_grille.xToColumn(p.x);
        int l1=_grille.yToLine(p.y);
        
        //System.out.println("c1 "+c1+" l1 "+l1);
        if (_grille.getGeometry()==Cellules.VERTICAL)
            n=c1;
        else
            n=l1;
        
        if (n>-1 && n<_grille.count()) {
            Cellules.Cellule aCel=_grille.getCellule(n);
            if (aCel!=null && aCel.getUserObject() instanceof String)
                ret=(String)aCel.getUserObject();
            
        }
        return ret;
    }
    /** Renvoie la largeur total de la grille */
    public int getWidth() {
        return _grille.getWidth();
    }
    /** Renvoie la hauteur total de la grille */
    public int getHeight() {
        return _grille.getHeight();
    }
    /** Renvoie le nombre total de colonnes/lignes */
    public int count() {
        return _grille.count();
    }
    /**
     * Renvoie la taille r�ele de la grille sans tenir compte du facteur de zoom
     * @return type Dimension. La dimension.
     */
    public Dimension getRealDimension() {
        return _grille.getRealDimension();
    }
    
    /**
     * Renvoie le nombre total de ligne virtuelles de la grilles.
     * quel que soit la geometrie.
     *
     * @return type int. Le total des lignes virtuelles.
     */
    public int lineCount() {
        return _grille.lineCount();
    }
    
    /**
     * Renvoie le mod�le g�om�trique utilis�.
     * @return type int. VERTICAL, HORIZONTAL
     */
    public int getGeometry() {
        return _grille.getGeometry();
    }
    /**
     * Selection du facteur de zoom
     *
     * @param f type float. Le facteur de zoom � appliquer au cellules
     * @param repaint type boolean. True pour repindre la fen�tre, false si non
     */
    public void setZoom(float f, boolean repaint) {
        _grille.setZoom(f);
        if (repaint)
            repaint();
    }
 
    /**
     * Renvoie les options de la grille.
     *
     * @return type long. Les options en cours.
     */
    public long getOptions() {
        return _grille.getOptions();
    }
    
    /**
     * Affecte les options de la grille en cours.
     *
     * @param f type long. Les options de la grille
     * @parama repaint type boolean. True pour repindre la fen�tre, false si non
     */
    public void setOptions(long f, boolean repaint) {
        _grille.setOptions(f);
        if (repaint)
            repaint();
        
    }
    /**
     * Renvoie le facteur zoom courant
     *
     * @return type float. La facteur de zoom en cours
     */
    public float getZoom() {
        return _grille.getZoom();
    }
    public IGridConstraint getGridConstraint() {
        return _gridConstraint;
    }
    
    
    public Dimension printComponent(Graphics g, int x, int y, Rectangle clip) {
        Dimension       gridSize=new Dimension(_grille.getWidth(),_grille.getHeight());
        
        _grille.draw(g, x, y,clip);

        return gridSize;
    }
    
    public void paintComponent(Graphics g) {
        
        Rectangle clip=g.getClipBounds();
        _grille.draw(g, 0, 0, clip);
        
        _area.width=_grille.getWidth();
        _area.height=_grille.getHeight();
        
        setPreferredSize(_area);
        revalidate();
        
    }
    
    /**
     * D�finission du gestionnaire de sortie d'�v�nement souris.
     *
     * @param m type IGridEvent. Le gestionnaire qui impl�mente l'interface IGridEvent.
     */
    public void setGridEventListener(IGridEvent m) {
        _gridEventListener=m;
    }

    public void componentClicked(Ctrl.planning.oComposant o, ModifierKey m) {
            int cn;

            // S'il y a un �couteur de d�fini ?
            if (_gridEventListener!=null) {
                Point       p=null;
                if (m.getMouseEvent()!=null)
                    p=m.getMouseEvent().getPoint();                
                // Convertion clique -> grille
                cn=_grille.pointToCellule(p);
                _gridEventListener.celluleClicked(new Cellules.CelluleEvent(cn,_grille)); 
            }
    }

    public void componentMoved(oComposant o, java.awt.Point grid) {
    }

    public void componentResized(oComposant o, Rectangle grid) {
    }

    public void componentSelected(oComposant o, boolean s) {
    }

    public void keyTyped(oComposant o, int k, ModifierKey m) {
    }

    public void keyPressed(oComposant o, int k, ModifierKey m) {
    }

    public void keyReleased(oComposant o, int k, ModifierKey m) {
    }

    
    
   
    
    
}
