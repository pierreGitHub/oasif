/*
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 */
package Ctrl.planning.grille;

import Ctrl.planning.PluginMngr;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Calendar;
import java.util.Date;



/**
 * Cette classe d�riv�e de Cellule sert de classe de base aux classes : {@link HeadCalendar}, {@link GridCalendar}. Elle est charg�e
 * de la gestion des dimmensions, de la position et des convertion des coordon�es lignes/grilles.
 * Les deux dimensions : _celluleHeight et _siseCellule, d�finissent le nombre de pixels en hauteur/largeur d'une cellule. Si la g�om�trie
 * est VERTICAL : 
 * @author n.lavoillotte
 */
public class CellulesCalendar extends Cellules  {
    /** Copie du calendrier de r�f�rence � faire avancer*/
    protected Calendar  _calendar;
    
    int             _celluleHeight,       // Largeur ou hauteur d'une cellule
                    _celluleWidth;       // Hauteur ou largeur d'une cellule    
    int             _celluleCount;
    
    /**
     * Transforme une hauteur relative de pixel en nombre relatif de lignes
     *
     * @param l type int. La ligne base 0 de d�part.
     * @param h type int. La hauteur en pixels relative � la ligne 0
     * @return type int. Le nombre de ligne correspondantes
     */
    public int heightToLines(int l, int h) {
        
        if (_geometry==HORIZONTAL)
            return super.heightToLines(l, h);

        // taille d'une ligne au zoom en cours
        float   lz=getVirtualHeight();
        // Hauteur estim�e
        int     height=getHeight();
        
        if (l<0) l=0;
        if (l>_celluleCount) l=_celluleCount-1;
        
        // Valeur de d�part
        int     y=0;
        
        // Dans la limite de la hauteur en mode non �tendu
        if (h>getHeight() && !isExtendedMode())
            h=getHeight();
        
        // Nombre de ligne relatives � la ligne de base
        return Math.round(h/lz);
        
    }
    /**
     * Transforme une hauteur relative de lignes en nombre relatif de pixels.
     *
     * @param l type int. La ligne base 0 de d�part pour d�marrer le calcule. (ligne � pas variable)
     * @param h type int. La hauteur en pixels relative � la ligne 0 � convertir
     * @return type int. Le nombre de pixels correspondants
     */
    public int linesToHeight(int l, int h) {
        
        if (_geometry==HORIZONTAL)
            return super.linesToHeight(l, h);
        
        // taille d'une ligne au zoom en cours
        float     lz=getVirtualHeight();
        
        if (l<0) l=0;
        if (l>_table.length) l=_table.length-1;
        
        // Dans la limite de la hauteur en mode non �tendu
        if (h+l > _celluleCount && !isExtendedMode())
            h=_celluleCount-l;
        
        // nombre de lignes correspondantes
        return Math.round(h*lz);
    }
    
    /**
     * Transforme une ligne en un pixel y qui correspond au pixel haut de la cellule.
     *
     * @param l type int. La ligne base 0.
     * @return type int. Le pixel haut de la ligne correspondante.
     */
    public int lineToY(int l) {
        
        if (_geometry==HORIZONTAL)
            return super.lineToY(l);
        
        // taille d'une ligne au zoom en cours
        float     lz=getVirtualHeight();
        
        // Dans la limite de la hauteur en mode non �tendu
        if (l>_celluleCount && !isExtendedMode())
            l=_celluleCount-1;
        
        return Math.round(l*lz);
    }
    /**
     * Transforme un pixel y en ligne
     *
     * @param y type int. Un pixel.
     * @return type int. La ligne base 0 correspondante au pixel y.
     */
    public int yToLine(int y) {
        
        if (_geometry==HORIZONTAL)
            return super.yToLine(y);
        
        // taille d'une ligne au zoom en cours
        float lz=Math.max(1.0f,getVirtualHeight());
        // Hauteur estim�e
        int     height=getHeight();
        
        // Dans la limite de la hauteur en mode non �tendu
        if (y>height && !isExtendedMode())
            y=height;
        
        // Dans la limite des coordon�s grille en mode non �tendu
        if (y<0 && !isExtendedMode())
            y=0;
        int l=Math.round(y/lz);
        
        // Dans la limite de la hauteur en mode non �tendu
        if (l>=_celluleCount && !isExtendedMode())
            l=_celluleCount-1;
        
        return l;
        
    }
    
    /**
     * Dessine l'inter cellule. Les finsq de semaine, les mois, sont de couleurs diff�rentes
     *
     * @param g type Graphics. Le contexte
     * @param x type int. Coordonn� x de dessin.
     * @param y type int. Coordonn� y de dessin.
     * @param w type int. Largeur du gap.
     * @param h type int. Hauteur du gap.
     * @param i type int. Le no de la cellule base 0.
     */
    public void drawGap(Graphics g, int x, int y, int w, int h, int i) {
        Color   bkColor=getCellule(i).getBackColor();
        if (bkColor!=null) {
            g.setColor(bkColor);
            g.fillRect(x,y,w,h);
        } else
            super.drawGap(g, x, y,w,h, i);
    }
    
    /**
     * Renvoie la hauteur totale des cellules
     */
    public int getHeight() {
        if (_geometry==HORIZONTAL)
            return super.getHeight();
        else
            // taille d'une ligne au zoom en cours
            return Math.round((_celluleCount*getVirtualHeight()));
    }

    /**
     * Demande la dimension d'une cellule
     *
     * @param i type int. La cellule souhait�.
     * @return type Dimension. Taille de la cellule.
     * @throws GridException
     */

    public Dimension getCelluleDimension(int i, Dimension d) {
        super.getCelluleDimension(i,d);
        // taille d'une ligne au zoom en cours
        int     lz=Math.round(getVirtualHeight());
        
        if (_geometry==HORIZONTAL)
            d.width=Math.round(getVirtualWidth());//lz;
        else
            d.height=Math.round(getVirtualHeight());//lz;
        
        return d;
    }
    /**
     * Demande la hauteur d'une cellule, en tenant compte du facteur de zoom.
     *
     * @param i type int. La cellule souhait�.
     * @return type int. La hauteur totale de la cellule VERTICALE, ou la hauteur de base d'une cellule.
     * @throws {@link GridException}.
     */
    public int getCelluleHeight(int i) {
        int lz;
        
        if (_geometry==HORIZONTAL)
            // Hauteur de base
            lz=super.getCelluleHeight(i);//Math.round(getVirtualHeight());
        else
            // Hauteur total
            lz=getHeight();
        return lz;
    }
    /**
     * Demande la Largeur d'une cellule, en tenant compte du facteur de zoom.
     *
     * @param i type int. La cellule souhait�.
     * @return type int. La Largeur totale de la cellule HORIZONTALE, ou la largeur de base d'une cellule. 
     * @throws {@link GridException}.
     */
    public int getCelluleWidth(int i) {
        int lz;
        
        if (_geometry==HORIZONTAL)
            // Largeur totale
            lz=getWidth();//Math.round(getVirtualHeight());
        else
            // Largeur de base
            lz=super.getCelluleWidth(i);
        return lz;
    }
    
    /**
     * Renvoie la largeur totale des cellules
     */
    public int getWidth() {
        if (_geometry==HORIZONTAL)
            // taille d'une ligne au zoom en cours
            return Math.round((_celluleCount*getVirtualWidth()));
        else
            return super.getWidth();
    }
    
    /**
     * Renvoie la largeur native en pixels d'une cellule.
     *
     * @return type int. La largeur d'une ligne/colonne.
     */
    public int virtualHeigh() {
        return _celluleHeight;
    }
    /**
     * Renvoie la hauteur native en pixels d'une cellule.
     *
     * @return type int. La hauteur d'une ligne/colonne.
     */
    public int virtualWidth() {
        return _celluleWidth;
    }
    /**
     * Renvoie le nombre total de ligne.
     *
     * @return type int. Le nombre total de lignes/colonnes virtuelles. {@link Cellules#count()}
     */
    public int lineCount() {
        return _celluleCount;
    }
    
    /**
     * Renvoie la hauteur d'une cellule en utilisant le facteur de zoom.
     *
     * @return type float. La hauteur d'une ligne/colonne zoom�e.
     */
    public float getVirtualHeight() {
        return _celluleHeight*getZoom();
    }
    /**
     * Renvoie la largeur d'une cellule en utilisant le facteur de zoom.
     *
     * @return type float. La largeur d'une ligne/colonne zoom�e.
     */
    public float getVirtualWidth() {
        return _celluleWidth*getZoom();
    }

}
