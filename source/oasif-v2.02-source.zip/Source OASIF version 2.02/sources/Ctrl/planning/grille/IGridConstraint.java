/*
 * IGrille.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Created on 11 mai 2005, 16:46
 */

package Ctrl.planning.grille;

import java.awt.Rectangle;

/**
 * Interface de gestion des contraintes de positionnement et de taille des composants graphiques.
 *
 * @author n.lavoillotte
 */
public interface IGridConstraint {

    /**
     * Ajuste la position du composant.
     */
    void adjustGridPosition(Rectangle settingBounds, int w, int h);
    /**
     * Ajuste la largeur et la hauteur du composant.
     */
    void adjustGridSize(Rectangle settingBounds, int c1, int l1);
    
    
    /**
     * Convertit des coordonn�es grille en pixels �cran.
     */
    void gridToBounds(Rectangle r);
    
    /**
     * Convertit des coordonn�es pixels �cran en coordonn�es grille.
     */
    void boundsToGrid(Rectangle r);
}
