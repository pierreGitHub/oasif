/*
 * PluginEvevent.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 15 avril 2005, 09:00
 */

package Ctrl.planning;

import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.ComponentEvent;

/**
 * Extention d'�v�nement pour le changement de position de taille et d'ajout de composant pendant
 * l'action de la souris.
 *
 * @author n.lavoillotte
 */
public class PluginEvent extends ComponentEvent {
    /** Le composant est en cours de d�placement */
    public static final int COMPONENT_MOVING = COMPONENT_LAST+1;
    /** Le composant est en cours de changement de taille */
    public static final int COMPONENT_RESIZING = COMPONENT_LAST+2;
    public static final int COMPONENT_ENTERED = COMPONENT_LAST+3;
    public static final int COMPONENT_EXITED = COMPONENT_LAST+4;
    /** Le composant va acceuillir un nouvel �l�ment */
    public static final int COMPONENT_ADDING = COMPONENT_LAST+5;
    /** Le composant vient d'�tre acceuili par un hote*/
    public static final int COMPONENT_ADDED = COMPONENT_LAST+6;
    /** Le composant vient d'�tre s�lectionn�/d�selectionn� */
    public static final int COMPONENT_SELECTED = COMPONENT_LAST+7;
    /** Le composant vient d'�tre cliqu� (mouse down + mouse up sans bouger) */
    public static final int COMPONENT_CLICKED = COMPONENT_LAST+8;
    /** Le composant vient de recevoir une entr�e clavier : touche enfonc� */
    public static final int COMPONENT_KEYPRESSED = COMPONENT_LAST+9;
    /** Le composant vient de recevoir une entr�e clavier : touche relach� */
    public static final int COMPONENT_KEYRELEASED = COMPONENT_LAST+10;
    /** Le composant vient de recevoir une entr�e clavier ; tant que enfonc� */
    public static final int COMPONENT_KEYTYPED = COMPONENT_LAST+11;
    
    
    
    /**
     * Rectangle public d'acc�s pour actualiser les positions et taille du composant durant
     * le resizing et le moving.
     */
    public Rectangle        settingBounds;
    /**
     * Composant public d'acc�s � ajouter au composant courant :
     * En retour : null pour refuser, non null pour accepter le composant
     */
    public Component        addingComponent;
    /**
     * Booleen public d'acc�s � modifier pour renvoyer l'�tat de s�lection du composant
     */
    public boolean          selectComponent;
    /**
     * Le code de touche correspondant � l'�v�nement clavier
     */
    public int              keyCode;
    /**
     * Composant public d'acc�s au gestionnaire de composants enfichables : {@link PluginMngr}
     */
    public PluginMngr               pluginAdapter;
    void _new(Component c, Rectangle r, PluginMngr j, int k) {
        addingComponent=c;
        settingBounds=r;
        pluginAdapter=j;
        selectComponent=false;
        keyCode=k;
    }
    /**
     * Cr�ation d'�v�nement.
     *
     * @param s type Component. Le composant source, emetteur de l'�v�nement.
     * @param id type int. Identifiant de l'�v�nement : {@link  COMPONENT_MOVING),  {@link  COMPONENT_RESIZING}, {@link  COMPONENT_ADDING}
     * @param j type JPlugin. Le manager.
     * @param k type int. Le code de touche frapp�.
     */
    public PluginEvent(Component s, int id, PluginMngr j, int k) {
        super(s,id);
        _new(null,null,j,k);
        
        
    }
    /**
     * Cr�ation d'�v�nement.
     *
     * @param s type Component. Le composant source, emetteur de l'�v�nement.
     * @param id type int. Identifiant de l'�v�nement : {@link  COMPONENT_MOVING),  {@link  COMPONENT_RESIZING}, {@link  COMPONENT_ADDING}
     * @param j type JPlugin. Le manager.
     */
    public PluginEvent(Component s, int id, PluginMngr j) {
        super(s,id);
        _new(null,null,j,0);
    }
    /**
     * Cr�ation d'�v�nement.
     *
     * @param s type Component. Le composant source, emetteur de l'�v�nement.
     * @param id type int. Identifiant de l'�v�nement : {@link  COMPONENT_MOVING),  {@link  COMPONENT_RESIZING}, {@link  COMPONENT_ADDING}
     * @param j type JPlugin. Le manager.
     * @param r type Rectangle. La position et taille du composant en cours de modification.
     */
    public PluginEvent(Component s, int id, PluginMngr j,Rectangle r) {
        super(s,id);
        _new(null,r,j,0);
    }
    
    /**
     * Cr�ation d'�v�nement.
     *
     * @param s type Component. Le composant source, emetteur de l'�v�nement.
     * @param id type int. Identifiant de l'�v�nement : {@link  COMPONENT_MOVING),  {@link  COMPONENT_RESIZING}, {@link  COMPONENT_ADDING}.
     * @param j type JPlugin. Le manager.
     * @param a type Component. Le composant qui sera ajout
     */
    public PluginEvent(Component s, int id, PluginMngr j, Component a) {
        super(s,id);
        _new(a,null,j,0);
    }
    /**
     * Cr�ation d'�v�nement.
     *
     * @param s type Component. Le composant source, emetteur de l'�v�nement.
     * @param id type int. Identifiant de l'�v�nement : {@link  COMPONENT_MOVING),  {@link  COMPONENT_RESIZING}, {@link  COMPONENT_ADDING}.
     * @param j type JPlugin. Le manager.
     * @param a type Component. Le composant qui sera ajout
     * @param r type Rectangle. La position et taille du composant en cours de modification.
     */
    public PluginEvent(Component s, int id, PluginMngr j, Component a, Rectangle r) {
        super(s,id);
        _new(a,r,j,0);
    }
    
}
