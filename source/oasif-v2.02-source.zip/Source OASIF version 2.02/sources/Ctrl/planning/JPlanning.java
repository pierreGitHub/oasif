/*
 * JPlanning.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 26 mai 2005, 09:11
 *
 * Mise � jour : 20/09/2005 - ajout de l'ent�te heure/demie heure
 */

package Ctrl.planning;

import Ctrl.planning.grille.Cellules.CelluleEvent;
import Ctrl.planning.grille.GridCalendar;
import Ctrl.planning.grille.GridDaysOfYear;
import Ctrl.planning.grille.GridHoursOfDay;
import Ctrl.planning.grille.HeadCalendar;
import Ctrl.planning.grille.HeadDays;
import Ctrl.planning.grille.HeadHours;
import Ctrl.planning.grille.HeadMinutes;
import Ctrl.planning.grille.HeadMonths;
import Ctrl.planning.grille.HeadYears;
import Ctrl.planning.grille.JGrid;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import Ctrl.planning.grille.*;
import javax.swing.event.UndoableEditListener;

/**
 * Cette classe est charg�e de pr�parer un JPanel, d'instancier les diff�rentes grilles (ent�tes) correspondantes au mod�le de planning,
 * et de mettre en place un planning.
 *
 * @author  n.lavoillotte
 */
public class JPlanning extends javax.swing.JPanel {
    JGrid           _gridDay;
    JGrid           _gridPlanning;
    JGrid           _gridMonth,_gridWeek, _gridYear,_gridHour,_gridMinutes;
    JPanel          _jHead;
    int             _geometry;
    BoxLayout       _headLayout;
    Insets          _insets;
    Date            _debGrid;
    
    /** Identificateur de l'objet ent�te ann�e */
    public static final int GRID_YEAR=1;
    /** Identificateur de l'objet ent�te mois */
    public static final int GRID_MONTH=2;
    /** Identificateur de l'objet ent�te semaine */
    public static final int GRID_WEEK=3;
    /** Identificateur de l'objet ent�te jour*/
    public static final int GRID_DAY=4;
    /** Identifiacteur le l'objet ent�te Heure */
    public static final int GRID_HOUR=5;
    /** Identificateur de l'objet ent�te demie heure */
    public static final int GRID_MINUTES=6;
    
    /** Identificateur de l'objet planning */
    public static final int GRID_PLANNING=10;
    
    /** Identificateur de l'objet ent�te ( voir {@link  #getDimension(int)) */
    public static final int GRID_HEAD=11;
   
    /** Orientation du planning Vertical */
    public static final int VERTICAL=Cellules.VERTICAL;
    
    /** Orientation du planning Horizontal */
    public static final int HORIZONTAL=Cellules.HORIZONTAL;
    
    /**
     * Ajustement de la taille du panel d'ent�tes
     */
    void _adjustHeadMaximumSize() {
        Dimension   dHead=_jHead.getMaximumSize();
        Dimension   dGrid=new Dimension();
        int         size=0;
        int         n=0;
        if (_geometry==Cellules.VERTICAL) {
            
            if (_gridYear!= null && _gridYear.isVisible()) {
                dGrid.setSize(32767,_gridYear.getHeight());
                size+=dGrid.height;
                _gridYear.setMaximumSize(dGrid);
                n++;
            }
            if (_gridMonth !=null && _gridMonth.isVisible()) {
                dGrid.setSize(32767,_gridMonth.getHeight());
                size+=dGrid.height;
                _gridMonth.setMaximumSize(dGrid);
                n++;
            }
            if (_gridWeek !=null && _gridWeek.isVisible()) {
                dGrid.setSize(32767,_gridWeek.getHeight());
                size+=dGrid.height;
                _gridWeek.setMaximumSize(dGrid);
                n++;
            }
            // Ajustable par les ic�nes
            if (_gridDay !=null && _gridDay.isVisible()) {
                dGrid.setSize(32767,32767);
                size+=_gridDay.getHeight();
                _gridDay.setMaximumSize(dGrid);
                n++;
            }
            
            
            if (_gridHour != null && _gridHour.isVisible()) {
                dGrid.setSize(32767,_gridHour.getHeight());
                size+=dGrid.height;
                _gridHour.setMaximumSize(dGrid);
                n++;
            }
            if (_gridMinutes != null && _gridMinutes.isVisible()) {
                dGrid.setSize(32767,_gridMinutes.getHeight());
                size+=dGrid.height;
                _gridMinutes.setMaximumSize(dGrid);
                n++;
            }
            
            dHead.setSize(dHead.width,size);
            
        } else {
            
            if (_gridYear !=null && _gridYear.isVisible()) {
                dGrid.setSize(_gridYear.getWidth(),32767);
                size+=dGrid.width;
                _gridYear.setMaximumSize(dGrid);
                n++;
            }
            if (_gridMonth !=null && _gridMonth.isVisible()) {
                dGrid.setSize(_gridMonth.getWidth(),32767);
                size+=dGrid.width;
                _gridMonth.setMaximumSize(dGrid);
                n++;
            }
            if (_gridWeek !=null && _gridWeek.isVisible()) {
                dGrid.setSize(_gridWeek.getWidth(),32767);
                size+=dGrid.width;
                _gridWeek.setMaximumSize(dGrid);
                n++;
            }
            
            // Ajustable par les ic�nes
            if (_gridDay !=null && _gridDay.isVisible()) {
                dGrid.setSize(32767,32767);
                size+=_gridDay.getWidth();
                _gridYear.setMaximumSize(dGrid);
                n++;
            }
            if (_gridHour != null && _gridHour.isVisible()) {
                dGrid.setSize(_gridHour.getWidth(),32767);
                size+=dGrid.width;
                _gridHour.setMaximumSize(dGrid);
                n++;
            }
            if (_gridMinutes != null && _gridMinutes.isVisible()) {
                dGrid.setSize(_gridMinutes.getWidth(),32767);
                size+=dGrid.width;
                _gridMinutes.setMaximumSize(dGrid);
                n++;
            }
            
            dHead.setSize(size,dHead.height);
            
        }
        
        _jHead.setMaximumSize(dHead);
        
        
    }
    
    /**
     * D�finition d'un nouveau mod�le
     *
     */
    void _newModel(String model,GridCalendar gridCal) {
        int         i;
        
        // Retire toutes les grilles d�j� ajout�es
        _jHead.removeAll();
        
        // Supprime toutes les grilles
        _gridYear=null;
        _gridMonth=null;
        _gridWeek=null;
        _gridDay=null;
        _gridHour=null;
        _gridMinutes=null;
        char    c;
        
        for (i=0;i<model.length();i++) {
            switch((c=model.charAt(i))) {
                
                case 'Y':
                    if (_gridYear==null) {
                        _gridYear =new JGrid(new HeadYears(gridCal));
                        _gridYear.getGrid().setInsets(0, 0, 1, 0);
                        _gridYear.getGrid().setBackColor(Color.white);
                        _jHead.add(_gridYear);
                    }
                    break;
                case 'M':
                    if (_gridMonth==null) {
                        _gridMonth=new JGrid(new HeadMonths(gridCal));
                        _gridMonth.getGrid().setInsets(0, 0, 1, 0);
                        _gridMonth.getGrid().setBackColor(Color.white);
                        _jHead.add(_gridMonth);
                    }
                    break;
                case 'W':
                    if (_gridWeek==null) {
                        _gridWeek =new JGrid(new HeadWeeks(gridCal));
                        _gridWeek.getGrid().setInsets(0, 0, 1, 0);
                        _gridWeek.getGrid().setBackColor(Color.white);
                        _jHead.add(_gridWeek);
                    }
                    break;
                case 'D':
                    if (_gridDay==null) {
                        _gridDay =new JGrid(new HeadDays(gridCal));
                        _jHead.add(_gridDay);
                    }
                    break;
                case 'H':
                    if (_gridHour==null) {
                        _gridHour=new JGrid(new HeadHours(gridCal));
                        _jHead.add(_gridHour);
                    }
                    
                    break;
                case 'm':
                    if (_gridMinutes==null) {
                        _gridMinutes=new JGrid(new HeadMinutes(gridCal));
                        _jHead.add(_gridMinutes);
                    }
            }
        }
        
        // Ajustement taille container
        _adjustHeadMaximumSize();
        
    }
    /**
     * Mise � jour d'une grille.
     *
     * @param iGrid type int. Le no de la grille � mettre � jour : GRID_YEAR, GRID_MONTH, GRID_DAY,...
     */
    public void updateHeaderGrid(int iGrid) {
        JGrid   aGrid=getJGrid(iGrid);
        
        if (aGrid != null && aGrid.getGrid() instanceof HeadCalendar) {
            ((HeadCalendar)aGrid.getGrid()).setCalendar((GridCalendar)_gridPlanning.getGrid());
            
            _adjustHeadMaximumSize();
            repaint();
        }
    }
    /**
     *
     * Mise � jour des grilles d'ent�te
     */
    public void updateHeaderGrids() {
        if (_gridMonth!=null)
            ((HeadCalendar)_gridMonth.getGrid()).setCalendar((GridCalendar)_gridPlanning.getGrid());
        if (_gridWeek!=null)
            ((HeadCalendar)_gridWeek.getGrid()).setCalendar((GridCalendar)_gridPlanning.getGrid());
        if (_gridYear!=null)
            ((HeadCalendar)_gridYear.getGrid()).setCalendar((GridCalendar)_gridPlanning.getGrid());
        if (_gridDay!=null)
            ((HeadCalendar)_gridDay.getGrid()).setCalendar((GridCalendar)_gridPlanning.getGrid());
        if (_gridHour!=null)
            ((HeadCalendar)_gridHour.getGrid()).setCalendar((GridCalendar)_gridPlanning.getGrid());
        if (_gridMinutes!=null)
            ((HeadCalendar)_gridMinutes.getGrid()).setCalendar((GridCalendar)_gridPlanning.getGrid());
        _adjustHeadMaximumSize();
        repaint();
    }
    
    /**
     * Initialise un calendrier absolu au lundi 1 janvier 0001
     * @return type Calendar. Le calendrier absolu
     */
    Calendar _initCal01_01_01() {
        Calendar    c=Calendar.getInstance();
        c.clear();
        c.set(1,Calendar.JANUARY,1,1,0,1);
        c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);
        c.set(Calendar.WEEK_OF_YEAR,1);
        c.set(Calendar.HOUR_OF_DAY,0);
        c.set(Calendar.MINUTE,0);
        c.set(Calendar.SECOND,1);
        
        return c;
    }
    /**
     * Fixe la dur�e la hauteur, la largeur, la taille d'une ligne du planning
     *
     * @param len type int. Le nombre de jours.
     * @param total type int. Le nombre de lignes.
     * @param hw type int. La taille d'une ligne/colonne en pixels
     * @param wh type int. La largeur/hauteur d'une colonne.
     */
    void _setDuration(int len, int total, int hw,  int wh) {
        Calendar        cal=Calendar.getInstance();
        GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
        
        // Calendrier absolu par defaut
        if (_debGrid==null)
            _debGrid=_initCal01_01_01().getTime();
        cal.setTime(_debGrid);
        
        // si changement de tailles ou de date ?
        if (len!=gridCal.count() ||
                total!=gridCal.lineCount() ||
                _debGrid.compareTo(gridCal.getTime())!=0 ||
                hw!=gridCal.virtualHeigh() ||
                wh!=gridCal.virtualWidth()) {
            
            
            gridCal.setCalendar(cal,_geometry,len,total,hw,wh);
            
            // Mise � jour des grilles
            updateHeaderGrids();
        }
    }
    
    
    /**
     * Effacement des grilles avant cr�ation de nouvelles
     */
    public void resetGrids() {
        
        if (_gridYear!=null)
            _gridYear.reset();
        if (_gridMonth!=null)
            _gridMonth.reset();
        if (_gridWeek!=null)
            _gridWeek.reset();
        if (_gridDay!=null)
            _gridDay.reset();
        if (_gridMinutes!=null)
            _gridMinutes.reset();
        if (_gridHour!=null)
            _gridHour.reset();
        
        if (_gridPlanning!=null)
            _gridPlanning.reset();
        
        _gridHour=null;
        _gridMinutes=null;
        _gridYear=null;
        _gridMonth=null;
        _gridWeek=null;
        _gridDay=null;
        
    }
    
    /**
     * Selection de l'ecouteur d'�v�nements d'une grille.
     *
     * @param iGrid type int. Le no de la grille �cout�. GRID_YEAR, GRID_MONTH, GRID_DAYS,...
     * @param listener type IGridEvent. L'ecouteur d'ev�nements "grille".
     */
    public void setGridEventListener(int iGrid, IGridEvent listener) {
        JGrid       aGrid=getJGrid(iGrid);
        if (aGrid!=null)
            aGrid.setGridEventListener(listener);
        
    }
    /**
     * S�lection d'un planning.
     *
     * @param model type String. Le modele d'ent�te et de planning voir {@link JPlanning#JPlanning(String, int, Date, int, int, int)}
     * @param flgs type long. Flags de constructions
     * @param type type int. G�om�trie VERTICAL/HORIZONTAL
     * @param deb type Date. La date de d�but. si null, fixe le calendrier au lundi : 01/01/0001
     * @param len type int. Le nombre de jours.
     * @param total type int. Le nombre de lignes.
     * @param h type int. La hauteur virtuelle d'une cellule.
     * @param w type int. La largeur virtuelle d'une cellule.
     * @param s type int. Le pas d'avance du calendrier.
     */
    public void setPlanning(String model, long flgs, int type, Date deb, int len, int total, int h, int w, int s) {
        String      pos0,pos1,pos3;
        int         i;
        
        
        
        // Calendrier absolu par defaut
        if (deb==null)
            deb=_initCal01_01_01().getTime();
        
        _debGrid=deb;
        
        Calendar        cal=Calendar.getInstance();
        cal.setTime(deb);
        int             geo;
        
        if (type==VERTICAL)
            geo=Cellules.VERTICAL;
        else
            geo=Cellules.HORIZONTAL;
        
        
        // Le planning principal
        GridCalendar    gridCal;
        
        // Calendrier 'temps'
        if (model.contains("H") || model.contains("h"))
            gridCal=(GridCalendar)new GridHoursOfDay(cal,flgs,geo,len,total,h,w, s);
        // Calendrier 'jour'
        else
            gridCal=(GridCalendar)new GridDaysOfYear(cal,flgs,geo,len,total,h,w, s);
        
        
        
        _gridPlanning  =new JGrid(gridCal);
        
        _geometry=gridCal.getGeometry();
        
        
        // Marge de s�partion avec le planning
        //_insets=new Insets(0, 0, 3, 0); // top, left, bottom right
        _insets.set(0, 0, 3, 0); // top, left, bottom right
        
        if (_geometry==Cellules.VERTICAL) {
            _headLayout=new BoxLayout(_jHead, BoxLayout.Y_AXIS);
            
            pos0=BorderLayout.NORTH;
            _insets.set(0, 0, 3, 0); // top, left, bottom right=new Insets(0, 0, 3, 0); // top, left, bottom right
        } else {
            _headLayout=new BoxLayout(_jHead, BoxLayout.X_AXIS);
            
            pos0=BorderLayout.WEST;
            _insets.set(0, 0, 0, 3); // top, left, bottom right=new Insets(0, 0, 0, 3); // top, left, bottom right
        }
        
        // Marge
        _jHead.setBorder(new EmptyBorder(_insets));
        // Couleur de la marge (arri�re plan)
        _jHead.setBackground(Color.LIGHT_GRAY);
        _jHead.setLayout(_headLayout);
        
        removeAll();
        
        // Les grilles attach�es
        setModel(model);
         // A gauche ou en haut
        add(_jHead,pos0);
        // Toujours au centre
        add(_gridPlanning,BorderLayout.CENTER);
       
        
        
    }
    
    /**
     * Selection d'un model d'ent�te
     *
     * @param model type String. Le model d'ent�tes.
     */
    public void setModel(String model) {
        _jHead.removeAll();
        _newModel(model,(GridCalendar)_gridPlanning.getGrid());
    }
    
    void _init() {
        
        // Container des ent�tes
        _jHead=new JPanel();
        
        // Marge de s�partion avec le planning
        _insets=new Insets(0, 0, 0, 0); // top, left, bottom right
        
    }
    /**
     * Cr�ation d'un planning de base (toutes les ent�tes)
     *
     */
    public JPlanning() {
        _init();
        initComponents();
    }
    
    /**
     * Cr�ation d'un planning avec ent�tes personnalis�es.
     * <<pre>
     *      Le model est d�finit par une s�rie de lettre d�finissant le choix d'ent�te, l'ordre, ...
     *
     *      Y       Ent�te ann�e
     *      M       Ent�te mois
     *      W       Ent�te semaine
     *      D       Ent�te jours
     *
     *      H       Ent�te heure
     *      m       Ent�te minutes
     *
     *      ex : new JPlanning("DYw",...) cr�era :
     *      une ent�te Date
     *      une ent�te Ann�e
     *      une ent�te no de semaine
     *
     * </pre>
     *
     * @param model type String. Le modele d'ent�te et de planning
     * @param type type int. VERTICAL, ou HORIZONTAL.
     * @param flgs type long. Flags de constructions
     * @param deb type Date. La date de d�but. si null, fixe le calendrier au lundi : 01/01/0001
     * @param len type int. Le nombre de jours.
     * @param total type int. Le nombre de lignes.
     * @param hw type int. La taille d'une ligne/colonne en pixels
     * @param wh type int. La largeur/hauteur d'un colonne.
     * @param s type int. Le pas d'avance du calendrier.
     */
    public JPlanning(String model, long flgs, int type, Date deb, int len, int total, int hw, int wh, int s) {
        _init();
        initComponents();
        setPlanning(model, flgs, type, deb, len, total, hw, wh, s);
    }
    
    /**
     * Demande l'un des composants JGrille du planning
     * @param type type int. L'un des composants : GRID_DAY,GRID_MONTH,GRID_WEEK
     * @return type JGrid. Le composant demand�, null si inconnu ou non d�fini.
     */
    public JGrid getJGrid(int type) {
        JGrid       grid=null;
        switch(type) {
            case GRID_YEAR:
                grid=_gridYear;
                break;
            case GRID_MONTH:
                grid=_gridMonth;
                break;
            case GRID_WEEK:
                grid=_gridWeek;
                break;
            case GRID_DAY:
                grid=_gridDay;
                break;
            case GRID_PLANNING:
                grid=_gridPlanning;
                break;
            case GRID_HOUR :
                grid=_gridHour;
                break;
            case GRID_MINUTES :
                grid=_gridMinutes;
                break;
        }
        return grid;
    }
    
    /**
     * Renvoie les pas d'incr�ments li�s � la diemsion de la formation.
     */
    public Dimension getScrollIncrements(Dimension dim) {
        JGrid               grille=getJGrid(JPlanning.GRID_PLANNING);
        if (dim==null)
            dim=new Dimension();
        
        if (grille.getGeometry()==Cellules.VERTICAL)
            dim.setSize(grille.getWidth()/grille.count(),grille.getHeight()/grille.lineCount());
        else
            dim.setSize(grille.getWidth()/grille.lineCount(),grille.getHeight()/grille.count());
        
        return dim;
    }
    /*
     * Montre ou cache les grilles
     *
     * @param type type int. L'un des composants : GRID_DAY,GRID_MONTH,GRID_WEEK
     * @param b type booelan. True pour montrer, false pour cacher
     */
    public void setVisible(int type, boolean b) {
        JGrid       grid=null;
        switch(type) {
            case GRID_YEAR:
                grid=_gridYear;
                break;
            case GRID_MONTH:
                grid=_gridMonth;
                break;
            case GRID_WEEK:
                grid=_gridWeek;
                break;
            case GRID_DAY:
                grid=_gridDay;
                break;
            case GRID_PLANNING:
                grid=_gridPlanning;
                break;
            case GRID_HOUR :
                grid=_gridHour;
                break;
            case GRID_MINUTES :
                grid=_gridMinutes;
                break;
                
        }
        if (grid!=null) {
            grid.setVisible(b);
            _adjustHeadMaximumSize();
        }
        
    }
    /**
     * Renvoie une instance sur la classe des options du planning en cours.
     *
     * @return type Jplanning.JPlanningOptions. La classe de gestion du planning.
     */
    public PlanningOptions getPlanningOptions() {
        return new PlanningOptions();
    }
    
    /**
     * Renvoie une instance sur le gestionnaire de grille
     *
     * @param iGrid type int. Le no de la grille � g�r�r
     * @param root type oComposant. Le composant racine de la grille. Null pas d'initialisation.
     */
    public GridTools getGridTools(int iGrid, oComposant root) {
        return new GridTools(this,iGrid,root);
    }
    
    /**
     *
     * @author nicolas.lavoillotte
     */
    public class GridTools {
        /**
         * Cette classe est charg�e de la gestion des composants enfants d'une grille
         *
         *
         * @author  n.lavoillotte
         */
        JPlanning               _jPlanning;
        int                     _grid;
        
        oComposant              _oComposantRoot;
        PluginMngr              _plugPlanningMngr;
        
        // La racine des composant et le manager d'objet dans la grille planning en cours
        void _setpluginmngr(oComposant r) {
            _oComposantRoot=r;
            if (_plugPlanningMngr==null)
                _plugPlanningMngr=new PluginMngr(_jPlanning.getJGrid(_grid));
            else
                _plugPlanningMngr.setParentRoot(_jPlanning.getJGrid(_grid));
            
        }
        
        void _init(JPlanning j, int iGrid, oComposant r) {
            _jPlanning=j;
            _grid=iGrid;
            
            if (r!=null)
                _setpluginmngr(r);
            else
                _plugPlanningMngr=null;
            _oComposantRoot=r;
            
            if (_plugPlanningMngr!=null) {
                IGridConstraint gridConstraint=((JGrid)_plugPlanningMngr.getParentRoot()).getGridConstraint();
                _oComposantRoot.setGridConstraint(gridConstraint);
                _plugPlanningMngr.addComponent(null, _oComposantRoot);
            }
            
            
            
        }
        /** Instanciation
         *
         * @param j type JPlanning . Le container g�n�ral
         * @param iGrid type int. Le no de la grille concern�
         */
        public GridTools(JPlanning j, int iGrid) {
            _init(j,iGrid,null);
        }
        /** Instanciation
         *
         * @param j type JPlanning . Le container g�n�ral
         * @param iGrid type int. Le no de la grille concern�
         */
        public GridTools(JPlanning j, int iGrid, oComposant r) {
            _init(j,iGrid,r);
        }
        
        /**
         * Renvoie le manager courant
         *
         * @return type PluginMngr. Le manager en cours du planning courrant.
         */
        public PluginMngr getPlugPlanningMngr() {
            return _plugPlanningMngr;
        }
        
        /**
         * Mise � jour de la taille et position des composants enfants. Apr�s changement de zoom, ou de calendrier
         */
        public void updateChilds() {
            
            oComposant     unComposant;
            
            Point       p=new Point();
            if (_oComposantRoot==null) {
                System.out.println("_oComposantRoot = null");
                return;
            }
            
            _oComposantRoot.setGridPosition(1,1);
            
            // Mise � jour des enfants
            Iterator   child=_oComposantRoot.getAllComposants(oComposant.class).iterator();
            while (child.hasNext()) {
                unComposant=(oComposant)child.next();
                
                // Actualisation taille et position
                unComposant.getGridPosition(p);
                unComposant.setGridPosition(p);
            }
            
        }
        
        /**
         * Renvoie l'objet oComposant s�lectionn�.
         *
         * @return type oComposant. L'objet ou null si aucun.
         */
        public oComposant getSelected() {
            PluginMngr     plugPlanningMngr=getPlugPlanningMngr();
            
            Iterator it=getAllComposants().iterator();
            oComposant  o=null;
            
            while (plugPlanningMngr!=null && it.hasNext()) {
                o=(oComposant)it.next();
                // Est il s�letctionn� ?
                if (plugPlanningMngr.isSelected(o))
                    break;
                else
                    o=null;
            }
            return o;
        }
        /**
         * Renvoie l'�tat des touches de contr�le du composant
         *
         * @return type {@link PluginMngr.ModifierKey}. L'�tat des touches de contr�le.
         */
        public PluginMngr.ModifierKey getModifierKey() {
            PluginMngr     plugPlanningMngr=getPlugPlanningMngr();
            
            if (plugPlanningMngr!=null)
                return plugPlanningMngr.getModifierKey();
            else
                return null;
            
        }
        
        /**
         * Renvoie la liste de tous les composants et sous-composants enfants de la racine courante
         * @return type ArrayList<Component>. Tous les enfants et petis-enfants.
         */
        public ArrayList<Component> getAllComposants() {
            return _oComposantRoot.getAllComposants(oComposant.class);
        }
        
        /**
         * Renvoie la liste de tous les composants et sous-composants enfants d'un type donn�.
         *
         * @param c type Class. La class de sous-composants souhait�s
         * @return type ArrayList<Component>. Tous les enfants et petis-enfants.
         */
        public ArrayList<Component> getAllComposants(Class c) {
            return _oComposantRoot.getAllComposants(c);
        }
        
        /**
         * Renvoie l'objet principal _oComposantRoot
         *
         * @return type oComposant.
         */
        public oComposant getRoot() {
            return _oComposantRoot;
        }
        
        /**
         * Cr�e un clone de tous les objets conteneu dans le compoosant racine.
         * seul le userObject n'est pas clon�
         * @return type oComposant. Le composant clon�.
         */
        public oComposant clone() {
            oComposant oc=new oComposant(_oComposantRoot);
            return oc;
        }
        
        /**
         * Ajoute un composant au composant racine en cours.
         *
         * @param child type oComposant. L'objet � ajouter.
         * @param childNotifyClicked type boolean. True : notifie d'un clique le composant ajout�.
         */
        public oComposant add(oComposant child, boolean childNotifyClicked) {
            return add(_oComposantRoot,child, childNotifyClicked);
        }
        /**
         * Ajoute un composant au composant racine en cours.
         *
         * @param parent type oComposant. L'h�te d'acceuil.
         * @param child type oComposant. L'objet � ajouter.
         * @param childNotifyClicked type boolean. True : notifie d'un clique le composant ajout�.
         * @return type oComposant. le composant child ajout�.
         */
        public oComposant add(oComposant parent, oComposant child, boolean childNotifyClicked) {
            PluginMngr     plugPlanningMngr=getPlugPlanningMngr();
            
            if (plugPlanningMngr!=null) {
                // L'interface de gestion des contraintes de la grille Planning
                IGridConstraint gridConstraint=((JGrid)plugPlanningMngr.getParentRoot()).getGridConstraint();
                
                // Installation de l'interface des contraintes
                child.setGridConstraint(gridConstraint);
                
                plugPlanningMngr.addComponent(parent, child);
                
                if (childNotifyClicked) {
                    //
                    // emulation du clique dans le composant ajout�
                    //
                    MouseEvent e = new MouseEvent(child,MouseEvent.MOUSE_CLICKED,new Date().getTime(),MouseEvent.BUTTON1_MASK,child.getX(),child.getY(),1,false);
                    child.dispatchEvent(e);
                }
                // Si cr�� par clonnage, initilaisation des sous objets
                if (child.isAclone())
                    _initSubComponent(child,child.getComponentEvent(),plugPlanningMngr, gridConstraint);
                
                
            }
            
            return child;
        }
        
        void _initSubComponent(oComposant c,IComponentEvent ce, PluginMngr plugPlanningMngr, IGridConstraint gridConstraint) {
            oComposant      o;
            for (int n=0; n<c.getComponentCount();n++) {
                if (c.getComponent(n) instanceof oComposant) {
                    o=(oComposant)c.getComponent(n);
                    
                    _initSubComponent(o,ce,plugPlanningMngr,gridConstraint);
                    o.setComponentEvent(ce);
                    plugPlanningMngr.initComponent(o, o.getBehavior(),o.getLevel());
                    o.setGridConstraint(gridConstraint);
                    
                }
            }
        }
        /**
         * Suppression d'un composant enfant. Restire l'�couteur de Contraintes.
         *
         * @param child type oComposant. Le composant � supprimer.
         * @param parentNotifyClicked type boolean. True notifie le parent par un clique de la suppression du composant child.
         */
        public void remove(oComposant child, boolean parentNotifyClicked) {
            PluginMngr     plugPlanningMngr=getPlugPlanningMngr();
            
            if (plugPlanningMngr!=null) {
                child.setGridConstraint(null);
                // Le parent racine (module, formation)
                if (_oComposantRoot!=child) {
                    Container   parent=child.getParent();
                    plugPlanningMngr.removeComponent(parent,child);
                    if (parentNotifyClicked) {
                        // emulation du clique chez le parent
                        MouseEvent e = new MouseEvent(parent,MouseEvent.MOUSE_CLICKED,new Date().getTime(),MouseEvent.BUTTON1_MASK,parent.getX(),parent.getY(),1,false);
                        parent.dispatchEvent(e);
                    }
                } else
                    // Le super parent (panel)
                    plugPlanningMngr.removeComponent(null,child);
                
            }
        }
        
        /**
         *
         * Reset d'un comosant enfant. Retire les �couteurs.
         * @param child type oComsant. Le composant enfant � reset�.
         */
        public void reset(oComposant child) {
            PluginMngr     plugPlanningMngr=getPlugPlanningMngr();
            
            if (plugPlanningMngr!=null) {
                child.setGridConstraint(null);
                plugPlanningMngr.resetComponent(child);
            }
            
        }
        /**
         * Initialise un composant en ajoutant l'�couteur des Conraintes
         *
         * @param child type oComposant. Le composant � initialiser
         */
        public void initComponent(oComposant child) {
            PluginMngr     plugPlanningMngr=getPlugPlanningMngr();
            
            if (plugPlanningMngr!=null) {
                IGridConstraint gridConstraint=((JGrid)plugPlanningMngr.getParentRoot()).getGridConstraint();
                
                // Installation de l'interface des contraintes
                child.setGridConstraint(gridConstraint);
                
                plugPlanningMngr.initComponent(child);
            }
            
        }
        /**
         * Initialise un tableau de composants.
         * @param t type oComposant[]. Le tableau de composants � initialiser.
         */
        public void initComponent(oComposant[] t) {
            int     i;
            
            for (i=0;i<t.length;i++)
                initComponent(t[i]);
            
        }
        /**
         * Reset d'un ensemble de composants enfant.
         *
         * @param t type oComposant[]. Le tableau des composants enfants � retirer.
         */
        public void removeComponent(oComposant[] t) {
            int     i;
            int     lRoot=_oComposantRoot.getLevel();
            
            for (i=0;i<t.length;i++) {
                if (lRoot-t[i].getLevel()>0)
                    reset(t[i]);
                else if (lRoot-t[i].getLevel()==1)
                    remove(t[i],false);
            }
            
        }
        /**
         * Instalation de l'interface de gestion de undo/redo
         * @param l type UndoableEditListener. L'interface de gestion undo/redo
         **/
        public void setUndoListener(UndoableEditListener l) {
            PluginMngr     plugPlanningMngr=getPlugPlanningMngr();
            
            if (plugPlanningMngr!=null)
                plugPlanningMngr.setUndoableEditListener(l);
        }
        /**
         * Retire tous les enfants depuis la racine du composant, y compris la racine
         */
        public void removeChildren() {
            
            oComposant    children[]=null;
            
            ArrayList<Component> lst=getAllComposants();
            if (lst.size()>0)
                //
                // Il faut passer par la m�thode toArray(Object[]) si non une exception java.lang.ClassCastException
                // sera l�v�e car le type des objets du tableau n'est pas de type IPluginListener.
                //
                children=lst.toArray((oComposant[])Array.newInstance(oComposant.class,lst.size()));
            
            if (children!=null)
                removeComponent(children);
            
            remove(_oComposantRoot,false);
            
            _oComposantRoot=null;
        }
        
        /**
         * Initialise la racine et les composants enfants
         *
         * @param r type oComposant. La nouvelle racine des composants.
         */
        public void initGridTools(oComposant r) {
            
            oComposant      children[]=null;
            
            
            // Mise � jour manager avec la nouvelle racine
            _setpluginmngr(r);
            
            PluginMngr     plugPlanningMngr=getPlugPlanningMngr();
            
            ArrayList<Component> lst=_oComposantRoot.getAllComposants(oComposant.class);
            if (lst.size()>0)
                //
                // Il faut passer par la m�thode toArray(Object[]) si non une exception java.lang.ClassCastException
                // sera l�v�e car le type des objets du tableau n'est pas de type IPluginListener.
                //
                children=lst.toArray((oComposant[])Array.newInstance(oComposant.class,lst.size()));
            
            if (children!=null)
                initComponent(children);
            
            // Ajoute le cont�naire principal "la racine"
            if (plugPlanningMngr!=null) {
                IGridConstraint gridConstraint=((JGrid)plugPlanningMngr.getParentRoot()).getGridConstraint();
                _oComposantRoot.setGridConstraint(gridConstraint);
                plugPlanningMngr.addComponent(null, _oComposantRoot);
            }
            
        }
        
        
    }
    
    public class PlanningOptions {
        /**
         * Cette classe est charg�e de la gestion des options du planning principale
         *
         *
         * @author  n.lavoillotte
         */
        
//        boolean _bupdateOptions=true;
//        public void setUpdateOptions(boolean u) {
//            _bupdateOptions=u;
//        }
        /**
         * Selection du facteur de zoom
         *
         * @param f type float. Le facteur de zoom � appliquer aux grilles
         */
        public void setZoom(float f) {
            
            _gridPlanning.setZoom(f,false);
            updateOptions();
        }
        
        
        
        /**
         * Renvoie le facteur zoom courant (grille principal : GRID_DAY)
         *
         * @return type float. La facteur de zoom en cours
         */
        public float getZoom() {
            return _gridPlanning.getZoom();
        }
        
        /**
         * Ajuste le planning horizontalement/verticalement pour qu'il tienne dans la largeur de la fen�tre
         * parente (container principal)
         */
        public void setPlanningToWindow() {
            // Dimension r�ele du planning en pixel pour un facteur de zoom = 1
            Dimension   dim=_gridPlanning.getRealDimension();
            
            float   fZ;
            
            if (_geometry==Cellules.VERTICAL)
                fZ=(float)((getParent().getWidth()-(_gridPlanning.count()*0.45f))/(float)dim.width);//-(_gridPlanning.count()*0.02f))/dim.width;
            else
                fZ=(float)((getParent().getHeight()-(_gridPlanning.count()*0.45f))/(float)dim.height);//-(_gridPlanning.count()*0.02f))/dim.height;
            _gridPlanning.setZoom(fZ,false);
            
            
            updateOptions();
        }
        /**
         * Convertion de colonnes en pixels
         *
         * @param type int. Le nombre de colonne � convertire.
         * @return type float. Le nombre de pixels correspondantes.
         */
        public float colToPixels(int n) {
            // Dimension r�ele du planning en pixel pour un facteur de zoom = 1
            Dimension   dim=_gridPlanning.getRealDimension();
            float       size;
            float       fZ;
            
            
            n=Math.max(1,n);
            
            if (_geometry==Cellules.VERTICAL) {
                size=(float)(dim.width/_gridPlanning.count())*n;
                fZ=(float)((getParent().getWidth())/size);//-(_gridPlanning.count()*0.02f))/dim.width;
            } else {
                size=(float)(dim.height/_gridPlanning.count())*n;
                fZ=(float)((getParent().getHeight())/size);//-(_gridPlanning.count()*0.02f))/dim.height;
            }
            return fZ;
            
        }
        /**
         * Ajuste le planning horizontalement/verticalement pour qu'il repr�sente n jours
         * dans la fen�tre parente (container principal)
         */
        public void setPlanningToNcol(int n) {
            
            float fZ=colToPixels(n);
            
            _gridPlanning.setZoom(fZ,false);
            updateOptions();
        }
        
        /**
         * Fixe la date de d�but de la formation, mise jour visuelle du planning
         *
         * @param deb type Date. La nouvelle date de d�but. si null, fixe le calendrier au lundi : 01/01/0001
         */
        public void setTime(Date deb) {
            Calendar        cal=Calendar.getInstance();
            GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
            
            // Calendrier absolu par defaut
            if (deb==null)
                deb=_initCal01_01_01().getTime();
            
            _debGrid=deb;
            
            cal.setTime(deb);
            gridCal.setCalendar(cal);
            
            // Mise � jour des grilles
            updateOptions();
        }
        /**
         * Change les options d'affichage du planning courant. voir {@link GridDaysOfYear}
         *
         * @param f type long. Les nouvelles options du planning
         */
        public void setOptions(long f) {
            
            GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
            long        old=gridCal.getOptions();
            gridCal.setOptions(f);
            
            // Si changement ?
            if (old!=f) {
                gridCal.setCalendar(gridCal.getCalendar());/*,
                        gridCal.getGeometry(),
                        gridCal.count(),
                        gridCal.lineCount(),
                        gridCal.virtualHeigh(),
                        gridCal.virtualWidth());*/
                
                // Mise � jour des grilles GridDaysOfYear
                updateOptions();
            }
        }
        
        /**
         * Changement visuelle. Otion multiple
         *
         * @param opt long. L'option choisi : GDOY_GAP_...
         * @param set type boolean. True s�lectionne l'option, false l'efface.
         *
         * public void setMultiOption(long opt, boolean set) {
         * GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
         * long            old=gridCal.getOptions();
         * gridCal.setMultiOptions(opt,set);
         *
         * // Si changement ?
         * if (old!=gridCal.getOptions()) {
         * gridCal.setCalendar(gridCal.getCalendar());
         *
         * // Mise � jour des grilles
         * updateOptions();
         * }
         *
         * }*/
        
        
        /**
         * Renvoie les options du planning courant.
         *
         * @return type long. Les options courantes
         */
        public long getOptions() {
            GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
            return gridCal.getOptions();
        }
        /**
         * Fixe la date de d�but du planning courant
         *
         * @param deb type int. Le nombre de jour en plus ou en moins par rapport au calendrier actuel
         */
        public void setTime(int deb) {
            if (deb==0) return;
            
            GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
            
            setTime(deb,gridCal.count(),gridCal.lineCount());
            
        }
        /**
         * Fixe la date de d�but, la dur�e et la hauteur du planning courant.
         *
         * @param deb type int. Le nombre de jour en plus ou moins para rapport au calendrier actuel.
         * @param len type int. La dur�e en nombre de jour.
         * @param height type int. Le nombre de ligne.
         */
        public void setTime(int deb, int len, int height) {
            if (deb==0) return;
            
            Calendar        cal=Calendar.getInstance();
            GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
            
            // Calendrier absolu par defaut
            if (_debGrid==null)
                _debGrid=_initCal01_01_01().getTime();
            
            cal.setTime(_debGrid);
            // ajoute ou retranche des jours
            //setTime(cal,deb);
            // ajoute ou retranche des jours
            cal.add(Calendar.DATE,deb);
            
            // nouvelle r�f�rence
            _debGrid=cal.getTime();
            
            _setDuration(len,height,gridCal.virtualHeigh(),gridCal.virtualWidth());
        }
        
        /**
         * Mise en place des jours f�ri�s et jours blancs sp�cifiques.
         *
         * @param lJf type Hashtable. La liste des jours f�ri�s sous la forme <Date>:<Integer : GDOY_WHITEDAYS | GDOY_HOLIDAYS>
         */
        public void setHolidays(Hashtable<Date,Integer> lJf) {
            if (_gridPlanning.getGrid() instanceof GridDaysOfYear) {
                
                
                GridDaysOfYear    gridDays=(GridDaysOfYear)_gridPlanning.getGrid();
                
                gridDays.setJoursferies(lJf);
                gridDays.setCalendar(gridDays.getCalendar());
                
                // Mise � jour des grilles
                updateOptions();
            }
        }
        
        /**
         * Fixe l'unit� utilis� pour faire avancer le calendrier.
         *
         * @param unite type int. L'unit� (jours ou minutes)
         **/
        public void setCalendarUnite(int unite) {
            if (_gridPlanning.getGrid() instanceof GridCalendar) {
                GridCalendar gc=((GridCalendar)_gridPlanning.getGrid());
                gc.setCalendarUnite(unite);
                gc.setCalendar(gc.getCalendar());
                
                // Mise � jour des grilles
                updateOptions();
            }
        }
        /**
         * Renvoie l'unit� utilis� pour faire avancer le calendrier.
         *
         * @return type int. L'unit�.
         */
        public int getCalendarUnite() {
            int res=0;
            if (_gridPlanning.getGrid() instanceof GridCalendar)
                res= ((GridCalendar)_gridPlanning.getGrid()).getCalendarUnite();
            return res;
        }
        
        
        /**
         * Renvoie la dimension du calendrier en nombre de lignes x colonnes
         *
         * @return type Dimension. Les dimensions du calendrier en unit� grille.
         */
        public Dimension getDuration() {
            GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
            
            return new Dimension(gridCal.count(),gridCal.lineCount());
            
        }
        /**
         * Renvoie la dimension d'une cellule en nombre de pixels
         *
         * @return type Diemension. width=largeur/hauteur, height=hauteur/largeur
         */
        public Dimension getCelluleSize() {
            GridCalendar    gridCal=((GridCalendar)_gridPlanning.getGrid());
            
            return new Dimension(gridCal.virtualHeigh(),gridCal.virtualWidth());
            
        }
        
        /**
         * Renvoie le type de g�omtrie utilis�.
         *
         * @return type int. VERTICAL ou HORIZONTAL
         */
        public int getGeometry() {
            return _geometry;
        }
        /**
         * Fixe la taille du calendrier en pr�cisant sa largeur et sa hauteur en unit� grille.
         *
         * @param len type int. Le nombre de jours.
         * @param total type int. Le nombre de lignes.
         * @param hw type int. La taille d'une ligne/colonne en pixels
         * @param wh type int. La largeur/hauteur d'un colonne.
         */
        public void setDuration(int len, int total, int hw, int wh) {
            _setDuration(len,total,hw,wh);
        }
        /**
         * Renvoie la date d�but du calendrier.
         *
         * @return type Date. La date de d�but.
         */
        public Date getTime() {
            return _debGrid;
        }
        
        void updateOptions() {
            //if (_bupdateOptions)
            updateHeaderGrids();
        }
    }

    /**
     * Renvoie la dimension d'un objet du planning
     *
     * @param type int. L'objet concern� : GRID_DAY, GRID_HOUR, ... GRID_HEAD
     * @return type Dimension. La largeur et la hauteur de l'ent�te
     */
    public Dimension getDimension(int type) {
        JGrid       aGrid;
        Dimension   headSize=new Dimension();
        
        
        // les grilles d'ent�tes
        if (type==GRID_HEAD) {
            int n;
            for (n=0;n<_jHead.getComponentCount();n++) {
                aGrid=(JGrid)(_jHead.getComponent(n));      

                if (_gridPlanning.getGeometry()==Cellules.HORIZONTAL) {
                    headSize.width+=aGrid.getWidth();
                    headSize.height=Math.max(headSize.height,aGrid.getHeight());
                }
                else {
                    headSize.height+=aGrid.getHeight();
                    headSize.width=Math.max(headSize.width,aGrid.getWidth());
                }
            }
        }
        else {
            // Une grille donn�e
            aGrid=getJGrid(type);
            if (aGrid!=null) {
                headSize.width=aGrid.getWidth();
                headSize.height=aGrid.getHeight();
            }
                
        }

        return headSize;
    }
    
    public Dimension printComponent(Graphics g, int x,int y, Rectangle clip) {
        int         n,xx=x,yy=y;
        Graphics2D  g2d = (Graphics2D)g;
        JGrid       aGrid;
        Dimension   headSize=new Dimension();
        
        // Impression des grilles d'ent�tes
        for (n=0;n<_jHead.getComponentCount();n++) {
            aGrid=(JGrid)(_jHead.getComponent(n));
            aGrid.printComponent(g, xx,yy, clip);            
            
            if (_gridPlanning.getGeometry()==Cellules.HORIZONTAL) {
                xx+=aGrid.getWidth();
                headSize.width=xx;
                headSize.height=Math.max(headSize.height,aGrid.getHeight());
            }
            else {
                yy+=aGrid.getHeight();
                headSize.height=yy;
                headSize.width=Math.max(headSize.width,aGrid.getWidth());
            }
            
         }
        
        // Impression de la grille du planning courant
        _gridPlanning.printComponent(g,xx,yy, clip);
        return headSize;
        
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {

        setLayout(new java.awt.BorderLayout(0, 1));

    }
    // </editor-fold>//GEN-END:initComponents
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
    
}
