/*
 * PActionSetBounds.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 2 mai 2005, 17:16
 */

package Ctrl.planning;

import java.awt.Rectangle;
import javax.swing.JComponent;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

/**
 *
 * @author n.lavoillotte
 */
public class PActionSetBounds extends PUndoableAction {
    JComponent  _comp;
    Rectangle   _newBounds,
                _oldBounds;

    
    /** Creates a new instance of JPluginActionBounds */
    public PActionSetBounds(JComponent c, Rectangle r) {
        _comp=c;
        _oldBounds=_comp.getBounds();
        _newBounds=r;
        _comp.setBounds(_newBounds);
    }

   
    
    public void die() {
        _comp=null;
        dieLink();
    }
    
    // Redo by setting the button state as it was initially.
    public void redo() throws CannotRedoException {
        super.redo();
        _comp.setBounds(_newBounds);
       redoLink();       
    }
    
    // Undo by setting the button state to the opposite value.
    public void undo() throws CannotUndoException {
        super.undo();
        
        _comp.setBounds(_oldBounds);
        undoLink();
    }
    
}
