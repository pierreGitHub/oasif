/*
 * ActionPrintPlanningJourofFormation.java
 *
 * Created on 27 mars 2006, 11:40
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ActionGui;

import Gui.FenetresInternes.JPrinterPlanningJourList;
import Gui.IOASIF;
import javax.swing.AbstractAction;

/**
 *
 *Action "Impression des planning journaliers de la formation"
 *
 * @author Pierre
 */
public class ActionPrintPlanningJourofFormation extends AbstractAction {
    IOASIF oasif;
    
    /** Creates a new instance of ActionPrintPlanningJourofFormation */
    public ActionPrintPlanningJourofFormation(IOASIF i) {
        oasif = i;
        
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        JPrinterPlanningJourList FramePrinter = new JPrinterPlanningJourList(oasif);
        FramePrinter.setVisible(true);
    }
    
}

