/*
 * ActionFiltreOutilsServicesOnFormation.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */

package ActionGui;

import Ctrl.planning.oModule;
import Gui.JBarreOutilsLocale;
import Gui.JComposant;
import data.XMLDoc.XMLUserObject;
import data.oasif.ACCOMPAGNEMENT_MODULEType;
import data.oasif.MODULEType;
import data.oasif.PROPRIETES_MODULEType;
import data.oasif.nOUTIL_SUBSTITUTIONType4;
import data.oasif.nTYPE_OUTILType3;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 *Action filtre "Outils & services" sur planning FORMATION
 *
 * @author Pierre
 */
public class ActionFiltreOutilsServicesOnFormation extends AbstractAction{
    long _IDOutil;
    ArrayList<Component> _listModule=new ArrayList<Component>();
    JComposant _planning;
    JBarreOutilsLocale _jBarreOutilsLocale;
    String _intitule;
    
    /** Creates a new instance of ActionFiltreOutilsServicesOnFormation */
    public ActionFiltreOutilsServicesOnFormation(JBarreOutilsLocale jBarreOutilsLocale,ArrayList<Component> listModule,long ID,JComposant planning,String intitule) {
    
        _IDOutil = ID;
        _listModule = listModule;
        _planning = planning;
        _jBarreOutilsLocale = jBarreOutilsLocale;
        _intitule = intitule;
    
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        _jBarreOutilsLocale.initFiltre();
        // Si non renseign�
        if (_IDOutil == -1){
            
        } else {
            Icon filtreSelected = new ImageIcon(getClass().getResource("/ressources/img/btnliste_map_sel.png"));
            _jBarreOutilsLocale.jButtonOutilsServices.setIcon(filtreSelected);
            _jBarreOutilsLocale.jButtonOutilsServices.setToolTipText(_intitule);
            for(int i=0;i<_listModule.size();i++) {
                oModule _oModulecourant =(oModule)_listModule.get(i);
                
                MODULEType NodeModule = (MODULEType)((XMLUserObject)_oModulecourant.getUserObject()).getXMLNode();
                PROPRIETES_MODULEType _PROPRIETES_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes(NodeModule);
                ACCOMPAGNEMENT_MODULEType _ACCOMPAGNEMENT_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement(_PROPRIETES_MODULEType);
                nTYPE_OUTILType3 _nTYPE_OUTILType3 = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_TypeOutil(_ACCOMPAGNEMENT_MODULEType);
                long IDOutil = _nTYPE_OUTILType3.getValue().getValue();
                nOUTIL_SUBSTITUTIONType4 _nOUTIL_SUBSTITUTIONType4 = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_OutilSubstitution(_ACCOMPAGNEMENT_MODULEType);
                long IDOutilSubstitution = _nOUTIL_SUBSTITUTIONType4.getValue().getValue();
                
                boolean exist =false;
                // Si l'outil est trouv� dans l'activit�
                
                if (_IDOutil == IDOutil)
                    exist = true;
                else if (_IDOutil == IDOutilSubstitution)
                    exist = true;
                
                if (!exist)
                {
                    _oModulecourant.setColor(new java.awt.Color(255,255,204));
                }
            }
        }
    }
    
}
