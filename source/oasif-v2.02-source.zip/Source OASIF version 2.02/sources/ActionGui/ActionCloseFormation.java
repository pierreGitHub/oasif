/*
 * ActionCloseFormation.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * Created on 21 juillet 2005, 16:22
 */

package ActionGui;

import Gui.IOASIF;
import javax.swing.AbstractAction;

/**
 * Action sur fermeture d'une formation
 *
 * @author Pierre
 */
public class ActionCloseFormation extends AbstractAction{
    IOASIF oasif;
    /** Creates a new instance of ActionCloseFormation */
    public ActionCloseFormation(IOASIF i) {
         oasif = i;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
       
        oasif.closeFormation();
    }
    
}
