/*
 * ActionFiltreOutilsServices.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 3 janvier 2006, 09:17
 */

package ActionGui;

import Ctrl.planning.oActivite;
import Gui.JBarreOutilsLocale;
import Gui.JComposant;
import data.XMLDoc.XMLUserObject;
import data.oasif.ACCOMPAGNEMENT_ACTIVITEType;
import data.oasif.ACTIVITEType;
import data.oasif.PRODUCTION_ACTIVITEType;
import data.oasif.PROPRIETES_ACTIVITESType;
import data.oasif.nOUTIL_ECHANGEType;
import data.oasif.nOUTIL_SUBSTITUTIONType;
import data.oasif.nOUTIL_SUBSTITUTIONType2;
import data.oasif.nTYPE_OUTILType;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 *Action Filtre "Outils Services" sur planning MODULE
 *
 * @author Pierre
 */
public class ActionFiltreOutilsServices extends AbstractAction {
    long _IDOutil;
    ArrayList<Component> _listActivite=new ArrayList<Component>();
    JComposant _planning;
    JBarreOutilsLocale _jBarreOutilsLocale;
    String _intitule;
    
    /** Creates a new instance of ActionFiltreOutilsServices */
    public ActionFiltreOutilsServices(JBarreOutilsLocale jBarreOutilsLocale,ArrayList<Component> listActivite,long ID,JComposant planning,String intitule) {
        
        _IDOutil = ID;
        _listActivite = listActivite;
        _planning = planning;
        _jBarreOutilsLocale = jBarreOutilsLocale;
        _intitule = intitule;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        _jBarreOutilsLocale.initFiltre();
        // Si non renseign�
        if (_IDOutil == -1){
            
        } else {
            Icon filtreSelected = new ImageIcon(getClass().getResource("/ressources/img/btnliste_map_sel.png"));
            _jBarreOutilsLocale.jButtonOutilsServices.setIcon(filtreSelected);
            _jBarreOutilsLocale.jButtonOutilsServices.setToolTipText(_intitule);
            for(int i=0;i<_listActivite.size();i++) {
                oActivite _oActivitecourant =(oActivite)_listActivite.get(i);
                
                ACTIVITEType NodeActivite = (ACTIVITEType)((XMLUserObject)_oActivitecourant.getUserObject()).getXMLNode();
                PROPRIETES_ACTIVITESType _PROPRIETES_ACTIVITESType = XMLTools.ActiviteXMLProprietes.get_Proprietes(NodeActivite);
                ACCOMPAGNEMENT_ACTIVITEType _ACCOMPAGNEMENT_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement(_PROPRIETES_ACTIVITESType);
                nTYPE_OUTILType _nTYPE_OUTILType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_TypeOutil(_ACCOMPAGNEMENT_ACTIVITEType);
                long IDOutil = _nTYPE_OUTILType.getValue().getValue();
                nOUTIL_SUBSTITUTIONType2 _nOUTIL_SUBSTITUTIONType2 = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_OutilSubstitution(_ACCOMPAGNEMENT_ACTIVITEType);
                long IDOutilSubstitution = _nOUTIL_SUBSTITUTIONType2.getValue().getValue();
                
                PRODUCTION_ACTIVITEType _PRODUCTION_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Production(_PROPRIETES_ACTIVITESType);
                nOUTIL_ECHANGEType _nOUTIL_ECHANGEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Production_OutilEchange(_PRODUCTION_ACTIVITEType);
                long IDOutil2 = _nOUTIL_ECHANGEType.getValue().getValue();
                nOUTIL_SUBSTITUTIONType _nOUTIL_SUBSTITUTIONType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Production_OutilSubstitution(_PRODUCTION_ACTIVITEType);
                long IDOutilSubstitution2 = _nOUTIL_SUBSTITUTIONType.getValue().getValue();
                
                boolean exist =false;
                // Si l'outil est trouv� dans l'activit�
                
                if (_IDOutil == IDOutil)
                    exist = true;
                else if (_IDOutil == IDOutilSubstitution)
                    exist = true;
                else if (_IDOutil == IDOutil2)
                    exist = true;
                else if (_IDOutil == IDOutilSubstitution2)
                    exist = true;
                
                
                if (!exist)
                    
                {
                    _oActivitecourant.setColor(new java.awt.Color(255,255,204));
                    _oActivitecourant.setAlphaComposite(0.55f);
                }
            }
        }
        
        
    }
}
