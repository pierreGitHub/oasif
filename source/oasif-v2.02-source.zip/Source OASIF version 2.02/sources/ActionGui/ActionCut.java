/*
 * ActionCut.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 23 janvier 2006, 11:39
 */

package ActionGui;

import Ctrl.planning.oComposant;
import Gui.IOASIF;
import javax.swing.AbstractAction;

/**
 *Action sur le menu "Edition --> Couper"
 * 
 * @author Pierre
 */
public class ActionCut extends AbstractAction {
    IOASIF _oasif;
    oComposant _oComposant;
    /** Creates a new instance of ActionCut */
    public ActionCut(oComposant o ,IOASIF oasif) {
         _oasif = oasif;
        _oComposant = o;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
         _oasif.cut(_oComposant);
    }
    
}
