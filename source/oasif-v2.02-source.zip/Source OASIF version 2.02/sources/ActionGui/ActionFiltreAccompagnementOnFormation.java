/*
 * ActionFiltreAccompagnementOnFormation.java
 *
 OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */

package ActionGui;

import Ctrl.planning.oModule;
import Gui.JBarreOutilsLocale;
import Gui.JComposant;
import data.XMLDoc.XMLUserObject;
import data.oasif.ACCOMPAGNEMENTS_GLOBAUXType3;
import data.oasif.ACCOMPAGNEMENT_GLOBALType3;
import data.oasif.ACCOMPAGNEMENT_MODULEType;
import data.oasif.MODULEType;
import data.oasif.PROPRIETES_MODULEType;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 *Action "Filtre Accomapagnement" sur planning FORMATION
 *
 * @author Pierre
 */
public class ActionFiltreAccompagnementOnFormation extends AbstractAction {
    long _IDNom;
    ArrayList<Component> _listModule=new ArrayList<Component>();
    JComposant _planning;
    JBarreOutilsLocale _jBarreOutilsLocale;
    String _intitule;
    
    
    /** Creates a new instance of ActionFiltreAccompagnementOnFormation */
    public ActionFiltreAccompagnementOnFormation(JBarreOutilsLocale jBarreOutilsLocale,ArrayList<Component> listModule,long ID,JComposant planning,String intitule) {
        _IDNom = ID;
        _listModule = listModule;
        _planning = planning;
        _jBarreOutilsLocale = jBarreOutilsLocale;
        _intitule = intitule;
        
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        _jBarreOutilsLocale.initFiltre();
        // Si non renseign� --> aucun filtre
        if (_IDNom == -1){
            
        } else {
            Icon filtreSelected = new ImageIcon(getClass().getResource("/ressources/img/btnliste_map_sel.png"));
            _jBarreOutilsLocale.jButtonAccompagnement.setIcon(filtreSelected);
            _jBarreOutilsLocale.jButtonAccompagnement.setToolTipText(_intitule);
            for(int i=0;i<_listModule.size();i++) {
                oModule _oModulecourant =(oModule)_listModule.get(i);
                boolean exist =false;
                MODULEType NodeModule = (MODULEType)((XMLUserObject)_oModulecourant.getUserObject()).getXMLNode();
                PROPRIETES_MODULEType _PROPRIETES_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes(NodeModule);
                ACCOMPAGNEMENT_MODULEType _ACCOMPAGNEMENT_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement(_PROPRIETES_MODULEType);
                ACCOMPAGNEMENTS_GLOBAUXType3 _ACCOMPAGNEMENTS_GLOBAUXType3 = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_AccompagnementsGlobaux(_ACCOMPAGNEMENT_MODULEType);
                
                if (_ACCOMPAGNEMENTS_GLOBAUXType3.hasACCOMPAGNEMENT_GLOBAL()){
                    
                    
                    for(int j=1;j<_ACCOMPAGNEMENTS_GLOBAUXType3.getACCOMPAGNEMENT_GLOBALCount();j++) {
                        ACCOMPAGNEMENT_GLOBALType3 AccompagnementGlobalCourant =  XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_AccompagnementGlobal(_ACCOMPAGNEMENTS_GLOBAUXType3,j);;
                        long IDNom = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_Nom(AccompagnementGlobalCourant);
                        
                        if (_IDNom == IDNom) {
                            exist = true;
                            
                        }
                    }
                    
                }
                
                if (!exist){
                    _oModulecourant.setColor(new java.awt.Color(255,255,204));
                    
                }
            }
        }
    }
}
