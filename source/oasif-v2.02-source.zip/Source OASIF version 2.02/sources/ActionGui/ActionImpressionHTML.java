/*
 * ActionImpressionHTML.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 *
 * Created on 23 mars 2006, 14:40
 *
 */

package ActionGui;

import Exportation.ExportToHTML;
import Gui.IOASIF;
import com.Ostermiller.util.Browser;
import java.io.File;
import javax.swing.AbstractAction;



/**
 *
 * @author Pierre
 */
public class ActionImpressionHTML extends AbstractAction {
    IOASIF oasif;
    File chemin;
    File formationfile;
    /** Creates a new instance of ActionImpressionHTML */
    public ActionImpressionHTML(IOASIF i) {
        oasif = i;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        chemin = new File("temp");
        formationfile = new File(chemin.getAbsolutePath() +File.separator+chemin.getName()+".html");
        ExportToHTML _ExportToHTML = new ExportToHTML(oasif,chemin);
        openHTMLFile();
        
        
        
    }
    /**
     *Ouvre dans le navigateur le fichier HTML FORMATION
     *
     */
    public void openHTMLFile(){
        
        Browser.init();
        //Browser.dialogConfiguration(oasif.getFrameOASIF());
        try{
            Browser.displayURL(formationfile.toURL().toString());
        } catch (Exception e) {
            System.out.println("Exception : Impression HTML" + e);
        }
        
        
    }
    
    
}
