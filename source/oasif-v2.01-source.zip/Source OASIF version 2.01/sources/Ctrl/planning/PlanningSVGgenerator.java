/*
 * PlanningSVGgenerator.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Created on 9 f�vrier 2006, 12:23
 */

package Ctrl.planning;

import Gui.JComposant;
import java.io.FileOutputStream;
import java.io.Writer;
import java.io.OutputStreamWriter;
import java.io.IOException;
import org.apache.batik.svggen.SVGGraphics2D;
import org.apache.batik.dom.GenericDOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DOMImplementation;

/**
 *
 * @author nicolas.lavoillotte
 */
public class PlanningSVGgenerator extends PlanningExporter {
    
    /** Creates a new instance of PlanningSVGgenerator */
    public PlanningSVGgenerator(JComposant jc) {
        super(jc);
    }
    
    public void generator(String output) throws IOException {

        // Get a DOMImplementation
        DOMImplementation domImpl =
            GenericDOMImplementation.getDOMImplementation();

        // Create an instance of org.w3c.dom.Document
        Document document = domImpl.createDocument(null, "svg", null);

        // Create an instance of the SVG Generator
        SVGGraphics2D svgGenerator = new SVGGraphics2D(document);

        // Ask the test to render into the SVG Graphics2D implementation
        //TestSVGGen test = new TestSVGGen();
        //test.paint(svgGenerator);
        exportTo(svgGenerator, 0,20, null);
       
        

        // Finally, stream out SVG to the standard output using UTF-8
        // character to byte encoding
        boolean useCSS = true; // we want to use CSS style attribute
        Writer out = new OutputStreamWriter(new FileOutputStream(output), "UTF-8");
        svgGenerator.stream(out, useCSS);
    
        
    }
    
}
