/*
 * GridDaysOfYear.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 *
 * Cette classe d�riv�e de GridCalendar, d�finie un calendrier des jours de l'ann�e
 *
 * Created on 22 septembre 2005, 10:12
 */

package Ctrl.planning.grille;

import java.awt.Color;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

/**
 * <pre>
 *  Cette classe d�riv�e de GridCalendar, est charg�e de la gestion d'un planning :
 *      - Jour de l'Ann�e.
 *
 *  Elle est capable d'afficher les jours f�ri�s, les WE, ... en tenant compte des options
 *  d'affichages donn�es par les diff�rents flags. Les flags sont cummulables en utilisant | (ou) pour
 *  les concat�ner.
 *
 *  Colonne par Jours ordinnaires
 *      GDOY_GAP_DAYS
 *  Colonne par Semaine
 *      GDOY_GAP_WEEKS
 *  Colonne par Mois
 *      GDOY_GAP_MONTHS
 *  Pas de colonne
 *      GDOY_NO_GAP
 *
 *
 *  Affiche jours f�ri�s
 *      GDOY_DISP_HOLIDAYS
 *  Affiche Week end
 *      GDOY_DISP_WEEKEND
 *  Affiche Jours blancs
 *      GDOY_DISP_WHITEDAYS
 *
 *  Affiche Num�ros de semaine
 *      GDOY_HEAD_WEEKNUMBER
 *  Affiche Semaine en claire
 *      GDOY_HEAD_WEEK
 *  Affiche Num�ros de mois
 *      GDOY_HEAD_MONTHNUMBER
 *  Affiche mois en clair
 *      GDOY_HEAD_MONTH
 *
 *  La table de hashage qui d�finit les jours f�ri�s ou jours blancs est compos�e
 *  de :
 *  Date dat:Integer type
 *
 *   ou date est la date du jour f�ri� au format Date
 *   ou type est un Integer �gale � :
 *
 *      Type de jours : jour blanc
 *          GDOY_WHITEDAYS
 *      Type de jours : jour f�ri�s
 *          GDOY_HOLIDAYS
 *
 * � * </pre>
 *   @author nicolas.lavoillotte
 */
public class GridDaysOfYear extends GridCalendar {
    Hashtable<Date,Integer>   _joursFeries=null;
    
    /** Type de jours : jour blanc */
    public static final int GDOY_WHITEDAYS=1;
    /** Type de jours : jour f�ri�s */
    public static final int GDOY_HOLIDAYS=2;
    
    /** Colonne par Jours ordinnaires */
    public static final int GDOY_GAP_DAYS=1;
    /** Colonne par Semaine */
    public static final int GDOY_GAP_WEEKS=2;
    /** Colonne par Mois */
    public static final int GDOY_GAP_MONTHS=4;
    /** Pas de colonne */
    public static final int GDOY_NO_GAP=8;
    
    static int _GDOY_GAPS=GDOY_GAP_DAYS | GDOY_GAP_WEEKS | GDOY_GAP_MONTHS | GDOY_NO_GAP;
    
    /** Affiche jours f�ri�s */
    public static final int GDOY_DISP_HOLIDAYS=32;
    /** Affiche Week end */
    public static final int GDOY_DISP_WEEKEND=64;
    /** Affiche Jours blancs */
    public static final int GDOY_DISP_WHITEDAYS=128;
    static int _GDOY_DISPS=GDOY_DISP_HOLIDAYS |GDOY_DISP_WEEKEND|GDOY_DISP_WHITEDAYS;
    
    /** Affiche Num�ros de semaine */
    public static final int GDOY_HEAD_WEEKNUMBER=256;
    /** Affiche Semaine en claire */
    public static final int GDOY_HEAD_WEEK=512;
    /** Affiche Num�ros de mois */
    public static final int GDOY_HEAD_MONTHNUMBER=1024;
    /** Affiche mois en clair */
    public static final int GDOY_HEAD_MONTH=2048;
    static int _GDOY_HEADS=GDOY_HEAD_WEEKNUMBER | GDOY_HEAD_WEEK | GDOY_HEAD_MONTHNUMBER | GDOY_HEAD_MONTH;
    
    
    
    /**
     * Creates a new instance of GridDays
     *
     * @param cal type Calendar. Le calendrier associ�.
     * @param flgs type long. Flags de constructions
     * @param geo type int. La geometry : VERTICAL, HORIZONTAL
     * @param len type int. Le nombre de jours.
     * @param total type int. Le nombre de lignes.
     * @param h type int. La hauteur virtuelle d'une cellule.
     * @param w type int. La largeur virtuelle d'une cellule.
     * @param s type int. Le pas d'avance du calendrier.
     */
    public GridDaysOfYear(Calendar cal, long flgs, int geo, int len, int total, int h, int w, int s) {
        super(GridCalendar.GRID_DAYS, s);
        _flags=flgs;
        setCalendar(cal,geo,len,total,h,w);
    }
    
    public void setCalendar(Calendar cal) {
        setCalendar(cal,getGeometry(),count(),lineCount(),virtualHeigh(),virtualWidth());
    }
    
    /**
     * D�termine si un jour de l'ann�e est f�ri�. Comparaison avec la liste des jours f�ri�s.
     *
     * @param aDay type Date. Une date de l'ann�e
     * @return type boolean. True : jour f�ri�, false si non.
     */
    public boolean estJourFerie(Date aDay) {
        
        boolean bRes=false;
        if (_joursFeries!=null) {
            // 2numeration des clefs
            Enumeration itDate=_joursFeries.keys();
            Date        aDate;
            Integer     aType;
            Calendar    cDate=Calendar.getInstance();
            Calendar    cDay=Calendar.getInstance();
            cDay.setTime(aDay);
            int         dd1,yy1,dd2,yy2;
            dd2=cDay.get(Calendar.DAY_OF_YEAR);
            yy2=cDay.get(Calendar.YEAR);
            
            while (!bRes && itDate.hasMoreElements()) {
                // Une clef
                aDate=(Date)itDate.nextElement();
                cDate.setTime(aDate);
                // Un type de clef
                aType=(Integer)_joursFeries.get(aDate);
                dd1=cDate.get(Calendar.DAY_OF_YEAR);
                yy1=cDate.get(Calendar.YEAR);
                if (dd1==dd2 && yy1==yy2 && aType.intValue()==GDOY_HOLIDAYS)
                    bRes=true;
            }
            
        }
        return bRes;
        
    }
    
    /**
     * D�termine si un jour de l'ann�e est blanc. Comparaison avec la liste des jours blancs.
     *
     * @param aDay type Date. Une date de l'ann�e.
     * @param weekEnd type boolean. true inclus les weekEnd dans le test, fals si non.
     * @return type boolean. True : jour f�ri�, false si non.
     */
    public boolean estJourBlanc(Date aDay, boolean weekEnd) {
        boolean     bRes=false;
        Calendar    cDay=Calendar.getInstance();
        cDay.setTime(aDay);
        
        if (_joursFeries!=null) {
            Calendar    cDate=Calendar.getInstance();
            // 2numeration des clefs
            Enumeration itDate=_joursFeries.keys();
            Date        aDate;
            Integer     aType;
            int         dd1,yy1,dd2,yy2;
            dd2=cDay.get(Calendar.DAY_OF_YEAR);
            yy2=cDay.get(Calendar.YEAR);
            while (!bRes && itDate.hasMoreElements()) {
                // Une clef
                aDate=(Date)itDate.nextElement();
                cDate.setTime(aDate);
                // Un type de clef
                aType=(Integer)_joursFeries.get(aDate);
                dd1=cDate.get(Calendar.DAY_OF_YEAR);
                yy1=cDate.get(Calendar.YEAR);
                if (dd1==dd2 && yy1==yy2 && aType.intValue()==GDOY_WHITEDAYS)
                    bRes=true;
            }
            
        }
        // inclus le test des weekend ?
        if (!bRes && weekEnd)
            bRes=(cDay.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY | cDay.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY);
        return bRes;
        
    }
    
    /**
     * Calcul les jours f�ri�s fixes et mobiles
     * @param aDay type Date
     * @return true=jour f�ri� , false=jour non f�ri�
     */
    public boolean estJourFerieFixe(Date aDay) {
        Calendar    cDate=Calendar.getInstance();
        cDate.setTime(aDay);
        return estJourFerieFixe(cDate.get(Calendar.DAY_OF_MONTH), cDate.get(Calendar.MONTH), cDate.get(Calendar.YEAR));
    }
    
    /** Calcul les jours f�ri�s fixes et mobiles
     *  @author Bertrand MAINZ
     *
     *  @param jj jour
     *  @param mm mois
     *  @param aa ann�
     *  @return true=jour f�ri� , false=jour non f�ri�
     */
    public boolean estJourFerieFixe(int jj, int mm, int aa) {
        //Jours fixes
        if ( jj == 1 && mm == 0) return true; 	// jour de l'an
        if ( jj == 1 && mm == 4) return true; 	// f�te du travail
        if ( jj == 8 && mm == 4) return true; 	// victoire 1945
        if ( jj == 14 && mm == 6) return true; 	// f�te nationale
        if ( jj == 15 && mm == 7) return true; 	// assomption
        if ( jj == 11 && mm == 10) return true; // armistice 1918
        if ( jj == 1 && mm == 11) return true; 	// Toussaint
        if ( jj == 25 && mm == 12) return true; // no�l
        
        // Calcul du Jours de P�ques et du Lundi de P�ques
        
        
        int m; int c; int y; int s; int t; int p; int q; int e; int b; int d; int l; int h;int moispaques; int jourpaques;
        m=(aa) % 19;
        c=aa/100;
        y=(aa) % 100;
        s=c/4;
        t=(c) % 4;
        p=(c+8)/25;
        q=(c-p+1)/3;
        e=(19*m+c-s-q+15)% 30;
        b=y/4;
        d=y % 4;
        l=(32+(2*t)+(2*b)-e-d) % 7;
        h=(m+(11*e)+(22*l))/451;
        moispaques=((e+l-(17*h)+144)/31)-2;
        jourpaques=((e+l-(17*h)+144) % 31)+2;
        
        if ((jj == jourpaques || jj == jourpaques + 1) && mm == moispaques) return true;
        
        // Calcul du jour de la Pentec�te et du lundi de Pentec�te
        
        int jourpentecote =1 ;
        int moispentecote =1 ;
        
        if ( moispaques == 2 ) {
            jourpentecote = 49 - (31 - jourpaques + 30);
            moispentecote = 4;
        }
        if ( moispaques == 3 && jourpaques <= 12) {
            jourpentecote = 49 - (30 - jourpaques);
            moispentecote = 4;
        }
        if ( moispaques == 3 && jourpaques > 12 ) {
            jourpentecote = 49 - (30 - jourpaques + 31);
            moispentecote = 5;
        }
        
        if ( (jj == jourpentecote || jj == (jourpentecote +1) ) && mm == moispentecote) return true;
        
        // Calcul du jour de l'Ascension
        
        int jourAscension =1 ;
        int moisAscension =1 ;
        if ( jourpaques == 22 && moispaques == 2) {
            jourAscension = 30;
            moisAscension = 3;
        }
        if ( jourpaques > 22 && moispaques == 2) {
            jourAscension = 39 - (31 - jourpaques + 30 );
            moisAscension = 4;
        }
        if ( jourpaques <=22 && moispaques == 3) {
            jourAscension = 39 - (30 - jourpaques);
            moisAscension = 4;
        }
        if ( jourpaques > 22 && moispaques == 3){
            jourAscension = 39 - (30 - jourpaques + 31);
            moisAscension = 5;
        }
        
        if ( jj == jourAscension && mm == moisAscension) return true;
        
        
        else return false;
    }
    
    /**
     * Mise en place des jours f�ri�s et jours blancs sp�cifiques.
     *
     * @param lJf type Hashtable. La liste des jours f�ri�s sous la forme <Date>:<Integer : GDOY_WHITEDAYS | GDOY_HOLIDAYS>
     */
    public void setJoursferies(Hashtable<Date,Integer> lJf) {
        _joursFeries=lJf;
    }
    
    /**
     *
     * Initialisation du calendrier.
     *
     * @param cal type Calendar. Le calendrier associ�.
     * @param geo type int. La geometry : VERTICAL, HORIZONTAL
     * @param len type int. Le nombre de jours.
     * @param total type int. Le nombre de lignes.
     * @param h type int. La hauteur virtuelle d'une cellule.
     * @param w type int. La largeur virtuelle d'une cellule.
     */
    public void setCalendar(Calendar cal, int geo, int len, int total, int h, int w) {
        
        Cellules.Cellule aCel;
        
        Date        actualDate,aDate;
        
        int         i,nMax;
        int         aStep,aDay;
        int         today=Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        int         toyear=Calendar.getInstance().get(Calendar.YEAR);
        
        Color       gris=new Color(204,204,204),        // Week end en jours f�ri�
                aColor,aBColor,
                backcolorMonth=new Color(82,93,172);
        
        // R�servation cellules
        initCalendar(cal,geo,len,total,h,w);
        nMax=count();
        
        
        actualDate=getCalendar().getTime();
        
        for (i=0;i<nMax;i++) {
            // Une cellule
            aCel=getCellule(i);
            
            
            // Une �tape
            aStep=getCalendar().get(Calendar.DAY_OF_WEEK);
            aDay=getCalendar().get(Calendar.DAY_OF_YEAR);
            aDate=getCalendar().getTime();
            
            // Fixe la coleur du jour en cours de la m�me ann�e
            if (aDay==today && getCalendar().get(Calendar.YEAR)==toyear )
                aColor=new Color(231,157,70);
            // Samedi ou dimanche
            else if ((aStep==Calendar.SUNDAY || aStep==Calendar.SATURDAY) && (_flags & GDOY_DISP_WEEKEND)!=0)
                aColor=gris;
            // Jours f�ri�s, jour chaum�, jours blanc
            else if ((estJourFerieFixe(getCalendar().get(Calendar.DAY_OF_MONTH),getCalendar().get(Calendar.MONTH),getCalendar().get(Calendar.YEAR)) && (_flags & GDOY_DISP_HOLIDAYS)!=0) ||
                    (estJourFerie(aDate) && (_flags & GDOY_DISP_HOLIDAYS)!=0) ||
                    (estJourBlanc(aDate,false) && (_flags & GDOY_DISP_WHITEDAYS)!=0) )
                aColor=gris;
            else
                aColor=Color.WHITE;
            
            // colonne par jours
            if ((_flags & GDOY_GAP_DAYS)!=0) {
                aCel.setBackColor(gris);
                // colonne par semaine
            } else if ((_flags & GDOY_GAP_WEEKS)!=0) {
                if (aStep==Calendar.SUNDAY)
                    aBColor=gris;
                else
                    aBColor=Color.WHITE;
                aCel.setBackColor(aBColor);
            }
            // collone par mois
            else if ((_flags & GDOY_GAP_MONTHS)!=0) {
                if (getCalendar().get(Calendar.DAY_OF_MONTH)==1 && i>0)
                    getCellule(i-1).setBackColor(backcolorMonth);
                else
                    aCel.setBackColor(Color.WHITE);
            }
            // pas de colonne
            else if ((_flags & GDOY_NO_GAP)!=0) {
                aCel.setBackColor(Color.WHITE);
                aColor=Color.WHITE;
            }
            
            // Force les Fins de semaine en gris si les WE doivent �tre affich�s
            if ((aStep==Calendar.SUNDAY || aStep==Calendar.SATURDAY) && (_flags & GDOY_DISP_WEEKEND)!=0)
                aColor=gris;
            
            aCel.setColor(aColor);
            
            // Jour suivant
            getCalendar().add(Calendar.DAY_OF_MONTH,getCalendarUnite());
            
        }
        
        // Restaure date courrante
        getCalendar().setTime(actualDate);
    }
    
    /**
     * Changement visuelle. Option multiple
     *
     * @param type int. Le type choisi : GDOY_GAP_...
     **/
    public void setOptions(long type) {
        super.setOptions(type);/*
        if ((type & _GDOY_DISPS)!=0) {
            _flags &=~_GDOY_DISPS;
            _flags |= (type & _GDOY_DISPS);
        }
        if ((type & _GDOY_GAPS)!=0) {
             _flags &= ~_GDOY_GAPS;
            _flags |= (type &_GDOY_GAPS);
        }
        if ((type & _GDOY_HEADS)!=0) {
             _flags &= ~_GDOY_HEADS;
            _flags |= (type & _GDOY_HEADS);
        }*/
    }
    
}
