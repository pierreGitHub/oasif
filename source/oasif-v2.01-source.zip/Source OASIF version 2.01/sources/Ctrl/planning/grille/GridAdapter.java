/*
 * PluginAdapter.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 10 juin 2005, 16:04
 */

package Ctrl.planning.grille;

import java.awt.Dimension;
import java.awt.Rectangle;
import javax.swing.JComponent;
import Ctrl.planning.*;

/**
 *
 * Cet Adapteur permet de r�pondre aux messages de positionnement et de taille, d'un composant pos� sur une grille.
 *
 *
 * @author n.lavoillotte
 */
public abstract class GridAdapter implements IGridConstraint {
    JComponent      _comp;
    Cellules        _grille;
    Dimension       _dimCel=new Dimension();    
    /**
     * Instanciation de l'adapter
     *
     * @param j type JComponent. Le composant de r�f�rence qui contient la grille.
     * @param g type Cellules. La grille associ�
     */
    public GridAdapter(JComponent j, Cellules g) {
        _comp=j;
        _grille=g;
    }

    /**
     * Ajuste la position du composant en l'allignant sur la grille et en tenant compte de la largeur et de la hauteur de r�f�rence.
     *
     * @param settingBounds type Rectangle. Coordonn�s dans l'espace de l'�cran � ajuster.
     * @param cols type int. La largeur de r�f�rence en nombre de colonne.
     * @param lines type int. La hauteur de r�f�rence en nombre de ligne.
     */
    public void adjustGridPosition(Rectangle settingBounds, int cols, int lines) {
        PluginMngr.convertRectangleFromScreen(settingBounds,_comp);
        
        // La ligne et la colonne 1
        int c1=_grille.xToColumn(settingBounds.x);
        int l1=_grille.yToLine(settingBounds.y);
        
        // La largeur et la hauteur de r�f�rence
        int w=_grille.columnsToWidth(c1, cols);
        int h=_grille.linesToHeight(l1, lines);
        
        // ajuste sur la colonne 1
        settingBounds.x=_grille.columnToX(c1);
        settingBounds.y=_grille.lineToY(l1);
        
        // largeur mimimum = largeur de la 1ere colonne
        Dimension     c=_grille.getCelluleDimension(c1,_dimCel);
        
        settingBounds.width =Math.max(c.width,w);
        settingBounds.height=Math.max(c.height,h);
        
        PluginMngr.convertRectangleToScreen(settingBounds,_comp);
    }
    /**
     * Ajuste la talle du composant en l'allignement sur la grille et en tenant compte de la position x,y de r�f�rence.
     *
     * @param settingBounds type Rectangle. Coordonn�s dans l'espace de l'�cran � ajuster.
     * @param c1 type int. La position x base 1 de r�f�rence en nombre de colonne.
     * @param l1 type int. La position y base 1 de r�f�rence en nombre de ligne.
     */
    public void adjustGridSize(Rectangle settingBounds, int c1, int l1) {
        
        c1--;
        l1--;
        
        // La largeur et la hauteur
        int cw=_grille.widthToColumns(c1, settingBounds.width);
        int lw=_grille.heightToLines(l1, settingBounds.height);
        
        // ajuste largeur et hauteur sur la colonne 1 et la ligne 1
        int w=_grille.columnsToWidth(c1,cw);
        int h=_grille.linesToHeight(l1,lw);
        
        // largeur mimimum = largeur de la 1ere colonne
        Dimension     c=_grille.getCelluleDimension(c1,_dimCel);
        
        settingBounds.width =Math.max(c.width,w);
        settingBounds.height=Math.max(c.height,h);
        
    }
    
    /**
     * Convertion de grille en pixels ecran
     *
     * @param grid type Rectangle. Les coordonn�es en grille base 1 transform� en pixel �cran en sortie.
     */
    public void gridToBounds(Rectangle grid) {
        
        int x=_grille.columnToX(grid.x-1);
        int y=_grille.lineToY(grid.y-1);
        int w=_grille.columnsToWidth(grid.x-1,grid.width);
        int h=_grille.linesToHeight(grid.y-1,grid.height);
        
        // R�sultat
        grid.x=x;grid.y=y;
        grid.width=w;grid.height=h;
        
        PluginMngr.convertRectangleToScreen(grid,_comp);
    }
    /**
     * Convertion de pixels en grille
     *
     * @param bounds type Rectangle. Les coordonn�es en pixel �cran transform� en grile base 1 en sortie.
     */
    public void boundsToGrid(Rectangle bounds) {
        PluginMngr.convertRectangleFromScreen(bounds,_comp);
        
        // La colonne 1
        int c1=_grille.xToColumn(bounds.x);
        // La colonne 2
        int c2=c1+_grille.widthToColumns(c1, bounds.width);
        
        
        // La ligne 1
        int l1=_grille.yToLine(bounds.y);
        // La ligne 2
        int l2=l1+_grille.heightToLines(l1,bounds.height);
        
        // r�sultat
        bounds.x=c1+1;
        bounds.width =Math.max(1,c2-c1);
        bounds.y=l1+1;
        bounds.height=Math.max(1,l2-l1);
    }
    
}
