/*
 * Cellules.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 17 mai 2005, 14:48
 */

package Ctrl.planning.grille;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.lang.reflect.Array;
import java.util.EventObject;

/**
 *
 * @author n.lavoillotte
 */
public class Cellules {
    // Compteur d'appels � la methode ResizeTable()
    // permet d'appeler le garbageColector.
    static final int    _countModulo=200;
    static      int     _countResizeTable=0;
    
    public static class CelluleEvent extends EventObject {
        int             _celNumber;
        
        public CelluleEvent(int celNumber, Cellules grid) {
            super(grid);
            _celNumber=celNumber;
        }
        /**
         * Renvoie le no de la cellule cliqu� base 0
         *
         * @return type int. Le no de cellule.
         */
        public int getCelNumber() {
            return _celNumber;
        }
        
    };
    
    public static class Cellule {
        int     _width,_height;
        Color   _forColor,_backColor=null;
        Object  _userObject=null;
        /**
         * Construit une cellule blanche de taille 0,0*/
        public Cellule() {
            setSize(0,0);
            setColor(Color.WHITE);
        }
        /**
         * Construit une cellule � partir d'une autre cellule.
         * @param c type Cellule. La cellule de r�f�rence.
         */
        public Cellule(Cellule c) {
            setSize(c._width,c._height);
            setColor(c._forColor);
        }
        /**
         * Construit une cellule sur mesure.
         * @param w type int. La largeur en pixel.
         * @param h type int. La hauteur en pixel.
         * @param c type Color. La couleur de premier plan
         */
        public Cellule(int w, int h,Color c) {
            setSize(w,h) ;
            setColor(c);
        }
        /**
         * Fixe la largeur de la cellule.
         * @param w type int. La largeur en pixel.
         */
        public void setWidth(int w) {
            _width=w;
        }
        /**
         * Fixe la hauteur de la cellule.
         * @param h type int. La hauteur en pixel.
         */
        public void setHeight(int h) {
            _height=h;
        }
        /**
         * Fixe la taile de la cellule.
         * @param w type int. La largeur en pixel.
         * @param h type int. La hauteur en pixel.
         */
        public void setSize(int w, int h) {
            _width=w;_height=h;
//            if (w==h && w==40)
//                w=40;
        }
        /**
         * Attace un objet � la cellule.
         * @param o type Object. L'objet � attach�.
         */
        public void setUserObject(Object o) {
            _userObject=o;
        }
        /**
         * Demande l'objet attach� � la cellule.
         * @return type Object. NULL ou l'objet attach�.
         */
        public Object getUserObject() {
            return _userObject;
        }
        /**
         * Fixe la couleur de premier plan
         * @param c type Color. La couleur de premier plan
         */
        public void setColor(Color c) {
            _forColor=c;
        }
        /**
         * Fixe la couleur d'arri�re plan
         * @param c type Color. La couleur de fond
         */
        public void setBackColor(Color c) {
            _backColor=c;
        }
        /**
         * Fixe la couleur de premier et d'arri�re plan
         * @param c type Color. La couleur de premier plan
         * @param b type Color. La couleur de fond
         */
        public void setColors(Color c, Color b) {
            _forColor=c;
            _backColor=b;
        }
        /**
         * Renvoie la couleur de fond.
         *
         * @return type Color. La couleur de fond.
         */
        public Color getBackColor() {
            return _backColor;
        }
        /**
         * Renvoie la couleur de premier plan
         * @return type Color. La couleur de premier plan
         */
        public Color getColor() {
            return _forColor;
        }
        /**
         * Desin d'une celulle.
         */
        public void draw(Graphics g, int x, int y, int w, int h) {
            g.setColor(_forColor);
            g.fillRect(x, y, w, h);
        }
        
        /**
         * Renvoie la largeur d'une cellule.
         */
        private int _getWidth() {
            return _width;
        }
        
        /**
         * Rencoie la hauteur d'une cellule. Utilise le facteur de zoom, renvoie 1 au minimum.
         */
        private int _getHeight() {
            return _height;
        }
    }
    
    static public final  int VERTICAL=1;
    static public final  int HORIZONTAL=2;
    
    Cellule[] _table=null;
    int     _gap,_gapRealZize;
    int     _width,_height;
    int     _geometry;
    Color   _backColor=Color.DARK_GRAY;
    float   _zoom=1.0f;
    boolean _extendedDimension=false;
    Insets  _insets=new Insets(0,0,0,0);
    
    /** Options des classes d�riv�es */
    protected long  _flags;
    /** Renvoie les options de la classe r�riv�e
     *
     * @return type long. Les options.
     */
    public long getOptions() {return _flags;}
    /**
     * Affectations d'options multiples.
     *
     * @param f type long. Les options � affecter.
     */
    public void setOptions(long f) {_flags=f;}
    
    /**
     * Changement visuelle. Otion multiple
     *
     * @param type int. Le type choisi : GDOY_GAP_...
     * @param set type boolean. True s�lectionne l'option, false l'efface.
     **/
    public void setMultiOptions(long opt, boolean set) {
        if (set)
            _flags |= opt;
        else
            _flags &= ~opt;
    }
    /**
     *
     * R�servation du tableau de cellules.
     *
     * @return type Cellule[]. Le tableau de cellules r�serv�.
     */
    protected Cellule[] newTable(int n, Cellule c, int g) {
        int i;
        
        // Ancien tableau
        if (_table!=null) {
            for (i=0;i<_table.length;i++) {
                _table[i].setUserObject(null);
                _table[i].setColors(null,null);
                _table[i]=null;
            }
            _table=null;
        }
        
        // Nouveau tableau
        _table=(Cellule[])Array.newInstance(Cellule.class,n);
        for (i=0;i<n;i++)
            _table[i]=new Cellule(c);
        
        _width=_height=-1;
        _geometry=g;
        // Force le recalcule largeur/hauteur r�ele
        _dimReal.setSize(0,0);
        return _table;
    }
    protected Cellule[] resizeTable(int n, Cellule[]old) {
        int         i;
        Cellule cel[]=null;
        
        if (n!=old.length) {
            
            if (n>0)
                // Nouveau tableau
                cel=(Cellule[])Array.newInstance(Cellule.class,n);
            
            // Recopie les cellules d'entr�es
            // et efface les anciennes cellules
            for (i=0;i<old.length;i++) {
                if (i<n)
                    cel[i]=old[i];
                else {
                    old[i].setUserObject(null);
                    old[i].setColors(null,null);
                    old[i]=null;
                }
            }
            _table=cel;
        } else
            _table=old;
        
        _width=_height=-1;
        
        // force le recyclage d'objet tous les n appels
        if ((++_countResizeTable % _countModulo)==0) {
            //System.out.println("calling gc()...");
            System.gc();
        }
        
        // Force le recalcule largeur/hauteur r�ele
        _dimReal.setSize(0,0);
        return _table;
        
    }
    /**
     * Cr�ation d'un tableau de 1 cellule.
     */
    public Cellules() {
        newTable(1,new Cellule(),VERTICAL);
        setGap(1);
    }
    /**
     * Cr�ation de plusieurs cellules.
     * @param n type int. Le nombre de cellules souhait�s.
     * @param w type int. La largeur d'une cellule en pixels.
     * @param h type int la hauteur d'une cellule en pixels.
     * @param c type Color. La couleur de la cellule.
     * @param g type int. Le model g�ometrique : VERTICAL ou HORIZONTAL.
     */
    public Cellules(int n, int w, int h, Color c, int g) {
        newTable(n,new Cellule(w,h,c),g);
        setGap(1);
    }
    /**
     * Cr�ation de plusieurs cellules bas� sur un mod�le.
     *
     * @param n type int. Le nombre de cellules � cr�er.
     * @param c type {@link Cellule}. La cellule de r�f�rence.
     * @param g type int. Le model g�ometrique : VERTICAL ou HORIZONTAL.
     */
    public Cellules(int n, Cellule c, int g) {
        newTable(n,c,g);
        setGap(1);
    }
    
    public void setInsets(int top, int left, int bottom, int right) {
        _insets.set(top,left,bottom,right);
    }
    /**
     * Gestion du mode �tendue
     *
     * <pre>
     *      Le mode �tendue quand il est actif, permet d'extrapoler les calcules
     *  de convertions de coordonn�e pixels -> coordonn�e grille et inversement.
     *
     *      Elle permet d'obtenir des coordonn�es n�gatifs et des tailles sup�rieures
     *  � la taille de la grille quand les parama�tres d'entr�e sont n�gatif ou > aux
     *  dimensions de la grille.
     *
     *      L'extrapolation est faite en se r�f�rant au cellules extr�me :
     *  0,0 et largeur-1. Ce sont celles ci qui servent de base au calcule lors des
     *  op�rations de convertions.
     *
     * </pre>
     * @param b type boolean. True : active le mode �tendu, false le d�sacive.
     */
    public void setExtendedMode(boolean b) {
        _extendedDimension=b;
    }
    /**
     * Rennvoi l'�tat du mode �tendue.
     *
     * @return type boolean. True : active le mode �tendu, false le d�sacive.{@link #setExtendedMode(boolean)}
     */
    public boolean isExtendedMode() {
        return _extendedDimension;
    }
    /**
     * Selection du facteur de zoom
     *
     * @param f type float. Le facteur de zoom � appliquer au cellules
     */
    public void setZoom(float f) {
        //        Dimension dim=getRealDimension();
        //
        //        if (dim.width>=dim.height) {
        //            if (Math.round(dim.width*f)<200)
        //                f=dim.width/200.0f;
        //
        //        } else if  (Math.round(dim.height*f)<200)
        //            f=dim.height/200.0f;
        
        if (f<0.01f)
            f=0.01f;
        
        _zoom=f;
        setGap(_gapRealZize);
    }
    /**
     * Renvoie le facteur zoom courant
     *
     * @return type float. La facteur de zoom en cours
     */
    public float getZoom() {
        return _zoom;
    }
    
    /**
     * Affectaion du gap inter cellules
     * @param g type int. Le gap en pixels.
     */
    public void setGap(int g) {
        _gapRealZize=g;
        _gap=Math.max(1,Math.round(g*_zoom));//g;
        // Pour forcer � recalculer la largeur et la hauteur des cellules dans getWidth, getHeight.
        _width=_height=-1;
    }
    
    /**
     * Demande le gap inter cellules.
     *
     * @return type int. Le gap en pixels.
     */
    public int getGap() {
        return _gap;
    }
    /**
     * Fixe la couleur d'arri�re plan
     * @param c type Color. La couleur de fond
     */
    public void setBackColor(Color c) {
        _backColor=c;
    }
    /**
     * Renvoie la couleur de fond.
     *
     * @return type Color. La couleur de fond.
     */
    public Color getBackColor() {
        return _backColor;
    }
    
    
    /**
     * Demande une cellule.
     *
     * @param i type int. L'index de la cellule base 0. Utilise le mode �tendue si i n'est pas compris dans les limites de la grille.
     * @return type {@link Cellule}. La cellule demand� ou celle extrapol�e (0 ou max-1) voir {@link #setExtendedMode(boolean)}.
     * @throws {@link GridException}.
     */
    public Cellule getCellule(int i) {
        
        if (_extendedDimension) {
            if (i<0) i=0;
            else if (i>=_table.length) i=_table.length-1;
        }
        
        if (i>-1 && i<_table.length)
            return _table[i];
        else
            throw new GridException("getCellule out of range : "+i+"/"+_table.length);
    }
    /**
     * Demande une s�rie de c c�llules commen�ant en i avec un pas de s.
     *
     * @param i type int. 1ere cellule base 0.
     * @param c type int. Nombre de cellules voulues.-1 : jusqu'a la fin du tableau de cellule.
     * @param s type int. Incr�ment pour la cellule suivante.
     * @return type {@link Cellule}. Le tableau des cellules demand�es.
     */
    public Cellule[] getCellules(int i, int c, int s) {
        Cellule cells[];
        int     n,k;
        
        // Ajustement
        if (c==-1)
            c=_table.length;
        if (s<=0)
            s=1;
        
        // Decompte du nombre de cellule demand�es
        for (n=i,k=0;n<_table.length && k<c;n+=s)
            k++;
        cells=(Cellule [])Array.newInstance(Cellule.class,k);
        c=k;
        
        for (n=i,k=0;n<_table.length && k<c;n+=s)
            cells[k++]=_table[n];
        
        return cells;
    }
    
    /**
     * Renvoie le mod�le g�om�trique utilis�.
     * @return type int. VERTICAL, HORIZONTAL
     */
    public int getGeometry() {
        return _geometry;
    }
    /**
     * Demande toutes les cellules
     * @return type {@link Cellule}. Le tableau de cellules.
     */
    public Cellule[] getCellules() {
        return _table;
    }
    
    /**
     * Renvoie le rectangle de la cellule
     *
     * @param i type int. La cellule souhait�.
     * @return type Rectangle. La taille de la cellule.
     * @throws {@link GridException}.
     */
    Rectangle       _celBounds=new Rectangle();
    public Rectangle getCelluleBounds(int i) {
        _celBounds.setBounds(0,0,getCelluleWidth(i),getCelluleHeight(i));
        return _celBounds;
    }
    
    /**
     * Demande la dimension d'une cellule, en tenant compte du facteur de zoom
     *
     * @param i type int. La cellule souhait�.
     * @param d type Dimension. Un objet Dimension pour recevoir la taille. Null, Cr�e l'objet
     * @return type Dimension. Taille de la cellule.
     * @throws {@link GridException}.
     */
    public Dimension getCelluleDimension(int i, Dimension d) {
        if (d==null) d=new Dimension();
        d.setSize(getCelluleWidth(i),getCelluleHeight(i));
        return d;
    }
    
    /**
     * Demande la largeur d'une cellule, en tenant compte du facteur de zoom.
     *
     * @param i type int. La cellule souhait�.
     * @return type int. Taille de la cellule.
     * @throws {@link GridException}.
     */
    public int getCelluleWidth(int i) {
        return Math.max(4,Math.round(getCellule(i)._getWidth()*_zoom));
    }
    /**
     * Demande la hauteur d'une cellule, en tenant compte du facteur de zoom.
     *
     * @param i type int. La cellule souhait�.
     * @return type int. Taille de la cellule.
     * @throws {@link GridException}.
     */
    public int getCelluleHeight(int i) {
        return Math.max(4,Math.round(getCellule(i)._getHeight()*_zoom));
    }
    
    /**
     * Renvoie la largeur total des cellules, en tenant compte du facteur de zoom
     */
    public int getWidth() {
        int i,w;
        
        // Calcule la largeur si c'est pas d�j� fait
        if (_width==-1) {
            for (i=_width=0;i<_table.length;i++) {
                if (_geometry==VERTICAL)
                    _width+=(getCelluleWidth(i)+_gap);
                else if (_geometry==HORIZONTAL)
                    // La ligne la plus large
                    _width=Math.max(getCelluleWidth(i),_width);
            }
        }
        
        return _width;
    }
    
    
    /**
     * Renvoie la hauteur total des cellules, en tenant compte du facteur de zoom
     */
    public int getHeight() {
        int i,w;
        
        // Calcule la hauteur si c'est pas d�j� fait
        if (_height==-1) {
            for (i=_height=0;i<_table.length;i++) {
                if (_geometry==VERTICAL)
                    // La ligne la plus haute
                    _height=Math.max(getCelluleHeight(i),_height);
                else if (_geometry==HORIZONTAL)
                    _height+=(getCelluleHeight(i)+_gap);
            }
        }
        return _height;
    }
    Dimension   _dimReal=new Dimension();
    
    /**
     * Renvoie la taille r�ele de la grille sans tenir compte du facteur de zoom.
     *
     * @return type Dimension. La dimension.
     */
    public Dimension getRealDimension() {
        int i;
        
        // D�j� calcul� ?
        if (_dimReal.width==_dimReal.height && _dimReal.width==0) {
            for (i=0;i<_table.length;i++) {
                if (_geometry==VERTICAL) {
                    // La ligne la plus haute
                    _dimReal.height=Math.max(getCellule(i)._getHeight(),_dimReal.height);
                    _dimReal.width+=(getCellule(i)._getWidth()+_gap);
                } else if (_geometry==HORIZONTAL) {
                    _dimReal.height+=(getCellule(i)._getHeight()+_gap);
                    _dimReal.width=Math.max(getCellule(i)._getWidth(),_dimReal.width);
                }
            }
        }
        return _dimReal;
    }
    
    /**
     * Renvoie le nombre total de cellules verticale ou horizontaless. D�pendant de la g�ometrie : Columns ou Lines.
     *
     * {@link GridCalendar#lineCount()}
     * @return type int. Le nombre total de cellules.
     */
    public int count() {
        return _table.length;
    }
    /**
     * Renvoie le nombre total de cellules
     *
     * @return type int.
     */
    public int lineCount() {
        return _table.length;
    }
    /**
     * Dessine une cellule.
     *
     * @param g type Graphics. Le contexte
     * @param x type int. Coordonn� x de dessin.
     * @param y type int. Coordonn� y de dessin.
     * @param w type int. Largeur de la cellule (zoom�).
     * @param h type int. Hauteur de la cellule (zoom�).
     * @param i type int. Le no de la cellule base 0.
     */
    public void drawCellule(Graphics g, int x, int y,int w, int h, int i) {
        getCellule(i).draw(g,x,y,w,h);
    }
    /**
     * Dessine l'inter cellule.
     *
     * @param g type Graphics. Le contexte
     * @param x type int. Coordonn� x de dessin.
     * @param y type int. Coordonn� y de dessin.
     * @param w type int. Largeur du gap.
     * @param h type int. Hauteur du gap.
     * @param i type int. Le no de la cellule base 0.
     */
    public void drawGap(Graphics g, int x, int y, int w, int h, int i) {
        g.setColor(_backColor);
        g.fillRect(x,y,w,h);
    }
    
    /**
     * Dessine l'ensemble des cellules,  ou seulement celles faisant partie du clipping d'affichage
     */
    public void draw(Graphics g, int x, int y, Rectangle clip) {
        boolean     inClip;
        int         l;
        Cellule     aCel;
        int         xy=0,yx=_table.length;
        Dimension   dim=new Dimension();
        
        // Clipping par rapport � la c�lulle
        if (clip!=null) {
            
            if (_geometry==VERTICAL) {
                xy=xToColumn(clip.x);//-1;
                yx=xToColumn(clip.x+clip.width);//+1;
            } else if (_geometry==HORIZONTAL) {
                xy=yToLine(clip.y);//-1;
                yx=yToLine(clip.y+clip.height);//+1;
            }
            // Efface le rectangle de fond avec la couleur d'arri�re plan
            // supprim� depuis la version de fin du lot no3 version 0.8
            // pour l'impression lot no 4
            
            //g.setColor(_backColor);
            //g.fillRect(clip.x,clip.y,clip.width,clip.height);
            
        }
        
        for (l=0;l<_table.length;l++) {
            aCel=_table[l];
            dim.setSize(getCelluleWidth(l),getCelluleHeight(l));
            // Dans le clipping de la cellule horizontal ou vertical ?
            if (l>=xy && l<=yx) {
                
                if (_geometry==VERTICAL)
                    drawGap(g,
                            x+dim.width,
                            y,_gap,dim.height,l);
                else if (_geometry==HORIZONTAL)
                    drawGap(g,x,y+dim.height,dim.width,_gap,l);
                
                drawCellule(g,
                        x+_insets.left,
                        y+_insets.top,
                        dim.width-_insets.right,
                        dim.height-_insets.bottom,
                        l);
                inClip=true;
            } else
                inClip=false;
            
            if (_geometry==VERTICAL)
                x+=(dim.width+_gap);
            else if (_geometry==HORIZONTAL)
                y+=(dim.height+_gap);
        }
        
        
    }
    /**
     * Convertit des coordonn�es pixels en no de cellule
     *
     * @param p type Point. Le point x,y � convertire en coordonn�e grille
     * @return type int. Le no de cellule coorespondante base 0.
     */
    public int pointToCellule(Point p) {
        return pointToCellule(p.x,p.y);
    }
    
    /**
     * voir {@link #pointToCellule(Point p)}
     */
    public int pointToCellule(int x, int y) {
        int xy=0;
        
        if (_geometry==VERTICAL)
            xy=xToColumn(x);
        else if (_geometry==HORIZONTAL)
            xy=yToLine(y);
        
        return xy;
        
    }
    
    
    /**
     * Transforme un pixel x en colonne
     * Utilise le mode �tendue voir : {@link #setExtendedMode(boolean)}
     *
     * @param x type int. Un pixel.
     * @return type int. La colonne base 0 correspondante au pixel x.
     */
    public int xToColumn(int x) {
        int     i;
        int     w;
        
        // Dans la limitte du max ?
        if (x>getWidth() && !_extendedDimension)
            x=getWidth();
        
        for (w=i=0;i<_table.length && w<x;) {
            
            if (i<_table.length)
                w+=(getCelluleWidth(i)+_gap);
            else if (_extendedDimension)
                w+=(getCelluleWidth(_table.length-1)+_gap);
            
            if (w<=x) i++;
        }
        
        // renvoie une approximation si le format �tendu est actif et que le param�tre
        // est n�gatif (compl�ment de la boucle positive pr�c�dente)
        if (_extendedDimension && x<0)
            i=x/(getCelluleWidth(0)+_gap);
        return i;
        
    }
    
    /**
     * Transforme un pixel y en ligne
     * Utilise le mode �tendue voir : {@link #setExtendedMode(boolean)}
     *
     * @param y type int. Un pixel.
     * @return type int. La ligne base 0 correspondante au pixel y.
     */
    public int yToLine(int y) {
        int     i;
        int     w;
        
        if (y>getHeight() && !_extendedDimension)
            y=getHeight();
        
        // Dans la limitte du max ?
        for (w=i=0;i<_table.length && w<y;) {
            if (i<_table.length)
                w+=(getCelluleHeight(i)+_gap);
            else if (_extendedDimension)
                w+=(getCelluleHeight(_table.length-1)+_gap);
            if (w<=y) i++;
            
        }
        
        // renvoie une approximation si le format �tendu est actif et que le param�tre
        // est n�gatif (compl�ment de la boucle positive pr�c�dente)
        if (_extendedDimension && y<0)
            i=y/(getCelluleHeight(0)+_gap);
        return i;
    }
    
    /**
     * Transforme une colonne en un pixel x qui correspond au pixel gauche de la cellule.
     * Utilise le mode �tendue voir : {@link #setExtendedMode(boolean)}
     *
     * @param c type int. La colonne base 0.
     * @return type int. Le pixel gauche de la colonne correspondante.
     * voir {@link #setExtendedMode(boolean)}.
     */
    public int columnToX(int c) {
        int     i;
        int     x;
        
        for (x=i=0;i<c;i++) {
            if (i<_table.length)
                x+=(getCelluleWidth(i)+_gap);
            else if (_extendedDimension)
                x+=(getCelluleWidth(_table.length-1)+_gap);
            else
                break;
        }
        
        if (_extendedDimension && c<0)
            x=c*(getCelluleWidth(0)+_gap);
        return x;
    }
    
    /**
     * Transforme une ligne en un pixel y qui correspond au pixel haut de la cellule.
     * Utilise le mode �tendue voir : {@link #setExtendedMode(boolean)}
     *
     * @param l type int. La ligne base 0.
     * @return type int. Le pixel haut de la ligne correspondante.
     */
    public int lineToY(int l) {
        int     i;
        int     y;
        
        for (y=i=0;i<_table.length && i<l;i++) {
            if (i<_table.length)
                y+=(getCelluleHeight(i)+_gap);
            else if (_extendedDimension)
                y+=(getCelluleHeight(_table.length-1)+_gap);
            else
                break;
        }
        if (_extendedDimension && l<0)
            y=l*(getCelluleHeight(0)+_gap);
        
        return y;
    }
    
    
    /**
     * Transforme une largeur relative de pixel en nombre relatif de colonnes
     * Utilise le mode �tendue voir : {@link #setExtendedMode(boolean)}
     *
     * @param c type int. La colonne base 0 de d�part pour d�marrer le calcule. (colonne � pas variable)
     * @param w type int. La largeur en pixels relative � la colonne 0
     * @return type int. Le nombre de colonnes correspondantes
     */
    public int widthToColumns(int c, int w) {
        int     x;
        int     i;
        
        
        if (w>getWidth() && !_extendedDimension)
            w=getWidth();
        
        
        for (x=i=0;x<w;i++) {
            if (c>=0 && c<_table.length)
                x+=(getCelluleWidth(c++)+_gap);
            else if (_extendedDimension) {
                if (c<0)
                    x+=(getCelluleWidth(0)+_gap);
                else
                    x+=(getCelluleWidth(_table.length-1)+_gap);
            } else
                break;
        }
        
        
        // Nombre de colonnes relatives � la colonne de base
        return i;
    }
    
    
    /**
     * Transforme une hauteur relative de pixel en nombre relatif de lignes
     * Utilise le mode �tendue voir : {@link #setExtendedMode(boolean)}
     *
     * @param l type int. La ligne base 0 de d�part pour d�marrer le calcule. (ligne � pas variable)
     * @param h type int. La hauteur en pixels � ne pas d�passer par rapport � la ligne 0
     * @return type int. Le nombre de ligne correspondantes
     */
    public int heightToLines(int l, int h) {
        int     i;
        int     y;
        
        if (h>getHeight() && !_extendedDimension)
            h=getHeight();
        
        
        for (y=i=0;y<h;i++) {
            if (l>=0 && l<_table.length)
                y+=(getCelluleHeight(l++)+_gap);
            else if (_extendedDimension) {
                if (l<0)
                    y+=(getCelluleHeight(0)+_gap);
                else
                    y+=(getCelluleHeight(_table.length-1)+_gap);
            } else
                break;
        }
        
        
        // Nombre de lignes relatives � la ligne de base
        return i;
    }
    
    
    
    /**
     * Transforme une largeur relative de colonne en nombre relatif de pixels.
     * Utilise le mode �tendue voir : {@link #setExtendedMode(boolean)}
     *
     * @param c type int. La colonne base 0 de d�part pour d�marrer le calcule. (colonne � pas variable)
     * @param w type int. La largeur en colonne relative � la colonne 0
     * @return type int. Le nombre de pixels correspondants
     */
    public int columnsToWidth(int c, int w) {
        int     x;
        
        for (x=0;w>0;c++,w--) {
            
            // Taille maximum atteinte ?
            if (c>=0 && c<_table.length)
                x+=(getCelluleWidth(c)+_gap);
            else if (_extendedDimension) {
                if (c<0)
                    x+=(getCelluleWidth(0)+_gap);
                else
                    x+=(getCelluleWidth(_table.length-1)+_gap);
            } else
                break;
        }
        
        // Nombre de pixels relatif � la colonne de base
        return x;
        
        
    }
    
    
    /**
     * Transforme une hauteur relative de lignes en nombre relatif de pixels.
     * Utilise le mode �tendue voir : {@link #setExtendedMode(boolean)}
     *
     * @param l type int. La ligne base 0 de d�part pour d�marrer le calcule. (ligne � pas variable)
     * @param h type int. La hauteur en ligne relative � la ligne 0 � convertir
     * @return type int. Le nombre de pixels correspondants
     */
    public int linesToHeight(int l, int h) {
        int     y;
        
        for (y=0;h>0;h--,l++) {
            
            // Taille maximum atteinte ?
            if (l>=0 && l<_table.length)
                y+=(getCelluleHeight(l)+_gap);
            else if (_extendedDimension) {
                if (l<0)
                    y+=(getCelluleHeight(0)+_gap);
                else
                    y+=(getCelluleHeight(_table.length-1)+_gap);
            } else
                break;
        }
        
        // Nombre de pixels relatif � la colonne de base
        return y;
    }
    
    
    
}
