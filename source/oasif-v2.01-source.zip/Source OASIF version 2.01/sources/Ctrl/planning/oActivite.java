/*
 * oActivite.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * 
 *
 * Created on 25 novembre 2004, 10:53
 */

package Ctrl.planning;


import Ctrl.planning.grille.IGridConstraint;
import data.altova.xml.Node;
import java.awt.*;
import java.awt.Composite;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import java.awt.event.*;
import javax.swing.*;


/**
 *
 * @author  lolo
 */
public class oActivite extends oComposant {
    /**
     * Cr�ation d'une Activit� par d�faut
     */
    public oActivite() {
        super(null,PluginMngr.FOCUSABLE | PluginMngr.DOCKABLE | PluginMngr.MOVEABLE | PluginMngr.EAST_RESIZEABLE | PluginMngr.WEST_RESIZEABLE ,0);
        initGridBounds(1,1,1,1);
        setColor(Color.blue);
        setAlphaComposite(null);
    }
    
    /**
     * Cr�ation d'une Activit�
     *
     * @param g type IGridConstraint. L'interface de gestion des contraintes
     * @param deb type int. Debut de l'activit� relative � son parent (base 1)
     * @param ligne type int. Le no de ligne relatif � son parent (base 1)
     * @param jours type int. La dur�e de l'activit� en nombre de jours. (minimum 1)
     */
    
    public oActivite(IGridConstraint g,int deb, int ligne, int jours) {
        super(g,PluginMngr.FOCUSABLE | PluginMngr.DOCKABLE | PluginMngr.MOVEABLE | PluginMngr.EAST_RESIZEABLE | PluginMngr.WEST_RESIZEABLE ,0);
        initGridBounds(deb, ligne, jours,1);
        setColor(Color.blue);
    }
    /**
     * Clonage d'une activit�
     *
     * @param o type oActivite. L'activit� de r�f�rence � dupliquer
     */
    public oActivite(oActivite o) {
        super(o);
    }
    /**
     * Clonage d'une activit�
     */
    public oActivite clone() {
        return new oActivite(this);
    }
    /**
     * Un composant � chang� de place, ajuste la position x, y,
     * r�ajuste la taille de son parent en cons�quence.
     */
    public void componentMoved(ComponentEvent c) {
        super.componentMoved(c);
        updateIconPosition();
    }
    public void componentResized(ComponentEvent c)  {
        super.componentResized(c);
        updateIconPosition();
    }
    
   public void updateIconPosition() {
        int         i,size;
        oIcon       aIcon;
        // Mise � jour de la position des icones associ�s
        if ( (size=getUserComposantSize())>0) {
            
            for (i=0;i<size;i++) {
                if (getUserComposantAt(i) instanceof oIcon) {
                    aIcon=(oIcon)getUserComposantAt(i);
                    // L'icone pr�sentiel ne bouge plus
                    if (aIcon.getUserID()!=IconsActivitesMngr.JF_ICON_PRESENTIEL) {
                        if (aIcon.getUserID()==IconsActivitesMngr.JF_ICON_DEVOIR)
                            aIcon.setGridPosition(getGridX()+getGridWidth()-1, aIcon.getGridY());
                        else
                            aIcon.setGridPosition(getGridX(), aIcon.getGridY());
                    }
                }
            }
        }
    }

}

