/*
 * PActionRemoveComponent.java
 *
 * Created on 2 mai 2005, 16:08
 *
 * Plus utilis� depuis le 14/06/05. L'action (undo/redo) est cr�e dan l'application principale
 * et non plus dans PluginMngr
 *
 */

package Ctrl.planning;

import java.awt.Container;
import javax.swing.JComponent;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

/**
 *
 * @author n.lavoillotte
 */
public class PActionRemoveComponent extends PUndoableAction {
    Container   _pRoot;
    JComponent  _comp;
    PluginMngr  _plugPane;
    
    /** instancie l'action */
    public PActionRemoveComponent(Container p, JComponent c, PluginMngr pp) {
        _pRoot=p;
        _comp=c;
        _plugPane=pp;
        
        _doAction();
        
    }
    
    void _doAction() {
        _pRoot.remove(_comp);
        _pRoot.repaint();        
    }
    public void die() {
        _plugPane.resetComponent(_comp);
        
        _plugPane=null;
        _comp=null;
        _pRoot=null;
    }
    // Redo by setting the button state as it was initially.
    public void redo() throws CannotRedoException {
        super.redo();
        _doAction();
    }
    
    // Undo by setting the button state to the opposite value.
    public void undo() throws CannotUndoException {
        super.undo();
        _pRoot.add(_comp);
        _pRoot.repaint();
    }
}