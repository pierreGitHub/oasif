/*
 * IconsActivitesMngr.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 *
 * Created on 27 octobre 2005, 11:08
 */

package Ctrl.planning;

import Gui.JComposant;
import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import Ctrl.planning.grille.*;

/**
 * Cette classe permet la gestion des ic�nes li�s aux activit�s, dans la grile 'jour' du planning courant.
 * <pre>
 * Utilisation avec le planning courant (JFormation, JModule) :
 *
 * // <b>Ajout d'une ic�ne sur une activit� :</b>
 *
 *  JPlanning       planning;       // Le planing courant
 *  oActivite       uneActivite     // une activit�
 *
 *  planning.getIconsActiviteMngr().addIconComposant(uneActivite,
 *                                                   IconsActivitesMngr.JF_ICON_DEVOIR);
 *
 * // <b>Suppression d'une ic�ne sur une activit� :</b>
 *  Boolean         updateView=false; // Indique s'il faut rafraichire l'affichage (true)
 *                                    // Le rafraichissement peut �tre fait sur le dernier dans
 *                                    // le cas de suppression r�p�t�s.
 *
 *  planning.getIconsActiviteMngr().removeIconComposant(uneActivite,
 *                                                      IconsActivitesMngr.JF_ICON_DEVOIR,
 *                                                      updateView);
 *
 * // <b>Rendre visible/invisible une ic�ne d'activit� :</b>
 *
 *  Boolean         visible=false;  // Pour rendre invisible l'ic�ne.
 *
 *  planning.getIconsActiviteMngr().setVisibleComposant(uneActivite,
 *                                                      IconsActivitesMngr.JF_ICON_DEVOIR,
 *                                                      visible);
 *
 * // <b>Rendre visible/invisble une s�rie d'ic�ne pour l'ensemble des activit� du planning courant :</b>
 *
 *  planning.getIconsActiviteMngr().setVisibleIconsComposant(IconsActivitesMngr.JF_ICON_DEVOIR |
 *                                                           IconsActivitesMngr.JF_ICON_RENDEZ_VOUS,
 *                                                           visible);
 *
 * </pre>
 *
 * @author nicolas.lavoillotte
 */
public class IconsActivitesMngr {
    JComposant              _parent;
    JPlanning.GridTools     _gridIconTools=null;
    
    public static final int JF_ICON_PRESENTIEL = 1;
    public static final int JF_ICON_DEVOIR = 2;
    public static final int JF_ICON_RENDEZ_VOUS = 4;
    public static final int JF_ALL= JF_ICON_PRESENTIEL | JF_ICON_DEVOIR | JF_ICON_RENDEZ_VOUS;
    
    /**
     * Renvoie true si l'icone existe
     */
    boolean _isFriseContainsIcon(oIcon aIcon) {
        return _gridIconTools.getAllComposants(oIcon.class).contains(aIcon);
    }
    
    /**
     * Renvoie l'icone si l'iconeId existe � la position donn�e.
     */
    oIcon _isFriseContainsIconIdAt(int iconId, int x) {
        int             i;
        ArrayList<Component> lIcons    =_gridIconTools.getRoot().getAllComposants(oIcon.class);
        for (i=0;i<lIcons.size();i++)
            if (((oIcon)lIcons.get(i)).getUserID()==iconId &&
                ((oIcon)lIcons.get(i)).getGridX()==x)
                break;
        
        return (i<lIcons.size() ? ((oIcon)lIcons.get(i)) : null);
    }
    
    /**
     * Ajout d'un ic�ne � un composant.
     *
     * @param child type oComposant. Le composant source. NULL, l'ic�ne sera seulement ajout� � grille "jour"
     * @param iconType type int. L'un des ic�nes : JF_ICON_PRESENTIEL, JF_ICON_DEVOIR, JF_ICON_RENDEZ_VOUS
     * @return type oIcon. l'icone ajout�.
     */
    oIcon _addIconComposant(oComposant child, int iconType) {
        
        
        oIcon   aIcon;
        
        aIcon=new oIcon(getIconComposantName(iconType),iconType,child.getGridX(),child.getUserComposantSize()+1);
        
        child.addUserComposant(aIcon);
        aIcon.setToolTipText(getIconComposantToolTip(iconType));
        //
        // Ajout de 'icone
        //
        _gridIconTools.add(aIcon,false);
        if (child instanceof oActivite)
            ((oActivite)child).updateIconPosition();
        return aIcon;
    }
    
    
    /**
     * Suppression d'un ic�ne � un composant.
     *
     * @param child type oComposant. Le composant source.
     * @param iconType type int. L'un des ic�nes : JF_ICON_PRESENTIEL, JF_ICON_DEVOIR, JF_ICON_RENDEZ_VOUS
     * @param update type boolean. True pour actualiser l'affichage
     */
    void _removeIconComposant(oComposant child, int iconType, boolean update) {
        
        int     indx;
        oIcon   aIcon;
        
        
        indx=child.containsUserComposantID(iconType);
        // Retire l'icon s'il existe.
        if (indx>-1) {
            aIcon=(oIcon)child.removeUserComposantAt(indx);
            _gridIconTools.remove(aIcon,false);
        }
        // Mise � jour de la grille ?
        if (update && indx>-1)
            updateGridDays();
        
    }
    
    /**
     * Renvoie la racine des icones (l'objet oFrise)
     *
     * @return type oComposant. Le container principal des ic�nes.
     */
    public oComposant getRoot() {
        return _gridIconTools.getRoot();
    }
    /**
     * Renvoie le nom de la ressource image correspondante � un identifiant.
     *
     * @param iconType type int. Le no de la raessource soiuhait�.
     * @return type string. La ressource, "" si le no est inconnu.
     */
    public String getIconComposantName(int iconType) {
        String res=null;
        
        switch(iconType) {
            case JF_ICON_PRESENTIEL :
                res="/ressources/static/presentiel.png";
                break;
            case JF_ICON_DEVOIR :
                res="/ressources/static/echeances.png";
                break;
            case JF_ICON_RENDEZ_VOUS :
                res="/ressources/static/synchrone.png";
                break;
        }
        return res;
    }
    /**
     * Renvoie le nom de la ressource image correspondante � un identifiant.
     *
     * @param iconType type int. Le no de la raessource soiuhait�.
     * @return type string. La ressource, "" si le no est inconnu.
     */
    public String getIconComposantToolTip(int iconType) {
        String res=null;
        
        switch(iconType) {
            case JF_ICON_PRESENTIEL :
                res="Jour planifi�";
                break;
            case JF_ICON_DEVOIR :
                res="Production � rendre";
                break;
            case JF_ICON_RENDEZ_VOUS :
                res="<html>Outil d'�change et<br> de communication synchrone</html>";
                break;
        }
        return res;
    }
    /**
     * Instanciation.
     *
     * @param gridId type int. Le no de la grille (GRID_DAY,...) qui supportera les ic�nes.
     * @param ref type JComponent. Le planning de r�f�rence (JFormation ou JModule)
     * @param listener type IGridEvent. L'�couteur d'�venement sur la grille d'icones.
     *
     */
    public IconsActivitesMngr(int gridId, JComposant ref) {
        
        _parent=ref;
        
        // Instanciation du gestionnaire Planning Jour
        // Container principale
        oFrise m=new oFrise(new Rectangle(1,1,_parent.getDuration().width,1),0);
        
        // Gestionnaire
        _gridIconTools=_parent.getGridTools(gridId,m);
        
        
    }
    
    
    
    /**
     * Suppression de tous les ic�nes d'un composant.
     *
     * @param child type oComposant. Le composant source.
     * @param update type boolean. True pour actualiser l'affichage
     */
    public void removeAllIconComposant(oComposant child, boolean update) {
        
        int     indx=0;
        oIcon   aIcon;
        
        while (indx<child.getUserComposantSize()) {
            
            aIcon=(oIcon)child.getUserComposantAt(indx);
            // Retire l'icon s'il existe.
            
            aIcon=(oIcon)child.removeUserComposantAt(indx);
            _gridIconTools.remove(aIcon,false);
            
            indx++;
            
        }
        // Mise � jour de la grille ?
        if (update && indx>0)
            updateGridDays();
        
    }
    
    
    /**
     * Mise en place de l'�couteur d'�v�nement sur les composants de la frise.
     *
     * @param e type IComponentEvent. L'�couteur d'�v�nements.
     */
    public void setComponentEvent(IComponentEvent e) {
        _gridIconTools.getRoot().setComponentEvent(e);
    }
    
    /**
     * Rend visible ou invisible (par suppression) un icone directement dans la zonne "grille"
     *
     * @param iconType type int. L'identifiant de l'icone.
     * @param x type int. La colonne base 1 de la position de l'icone.
     * @param visible type boolean. True l'ajoute false le retire
     */
    public void setVisibleIconToGrid(int iconType, int x, boolean visible) {
        oIcon   aIcon;
        
        // l'icone existe � cette position ?
        aIcon=_isFriseContainsIconIdAt(iconType, x);
        if ((aIcon!=null && !visible) || (aIcon!=null && x>getRoot().getGridWidth() ) )
            // suppression
            _gridIconTools.remove(aIcon,false);
        else if (aIcon==null && visible) {
            if (x<=getRoot().getGridWidth()) {
                aIcon=new oIcon(getIconComposantName(iconType),iconType,x,1);
                aIcon.setToolTipText(getIconComposantToolTip(iconType));
                //
                // Ajoute de nouveau l'icone � la frise (cas des changments de planning  : formation, module)
                //
                _gridIconTools.add(aIcon,false);
            }
            
                
        }
        updateGridDays();
        
    }
    /**
     * Rend visible/invisible les ic�nes d'un composant.
     *
     * @param child type oComposant. Le composant source.
     * @param iconType type int. L'un des ic�nes : JF_ICON_PRESENTIEL, JF_ICON_DEVOIR, JF_ICON_RENDEZ_VOUS
     * @param visible type boolean. True visible, False invisible.
     */
    public void setVisibleIconComposant(oComposant child, int iconType, boolean visible) {
        
        int     indx;
        oIcon   aIcon=null;
        boolean update=false;
        
        // L'icon s'il existe.
        indx=child.containsUserComposantID(iconType);
        
        if (visible && indx<0) {
            //
            // Ajout de 'icone
            //
            aIcon=_addIconComposant(child,iconType);
            update=true;
        } else if (indx>-1)
            aIcon=(oIcon)child.getUserComposantAt(indx);
        
        
        // Si icone il y a ?
        if (aIcon != null) {
            // les icones attach�s aux composants doivent �tre unique dans la grille
            if (!_isFriseContainsIcon(aIcon)) {
                
                //
                // Ajoute de nouveau l'icone � la frise (cas des changments de planning  : formation, module)
                //
                _gridIconTools.add(aIcon,false);
                update=true;
            }
            // Si changement d'�tat
            if (aIcon.isVisible() != visible) {
                aIcon.setVisible(visible);
                update=true;
            }
        }
        
        // Mise � jour de la grille
        if (update)
            updateGridDays();
    }
    
    public void updateFriseWidth(int w) {
        _gridIconTools.getRoot().setGridDimension(w, _gridIconTools.getRoot().getGridHeight());
    }
    /**
     * Mise � jour de la taille de la grille des ic�nes (hauteur variable)
     */
    public void updateGridDays() {
        //
        // Ajout, suppression des icones pour chaque activit�
        //
        HeadDays hd=(HeadDays)(_parent.getJGrid(JComposant.GRID_DAY).getGrid());
        //ArrayList<Component> lActivites=_parent.getAllComposants(oComposant.class);
        ArrayList<Component> lIcons    =_gridIconTools.getRoot().getAllComposants(oIcon.class);
        
        oComposant  child;
        int     i,j,iconCount,size,total,lineCount;
        int     x,y[]=null;
        int     indx;
        oIcon   aIcon;
        
        //
        // 1) comptage du nombre d'icone maximum par activit�s
        lineCount=1;
        i=0;
//        while (i<lActivites.size()) {
//            child=(oComposant)lActivites.get(i);
//
//            if (child instanceof oActivite) {
//                size=child.getUserComposantSize();
//                lineCount=Math.max(lineCount,size);
//            }
//            i++;
//        }
        int     iDs=0;
        lineCount=0;
        while (i<lIcons.size()) {
            aIcon=(oIcon)lIcons.get(i);
            // Nouveau type d'icone visible trouv� ?
            if (aIcon.isVisible() && (iDs | aIcon.getUserID())!=iDs) {
                // cummule les ID des icones pour les utiliser une seule fois
                iDs|=aIcon.getUserID();
                // augmente le nombre de ligne
                lineCount++;
            }
            
            i++;
        }
        // Minimum 1 ligne
        lineCount=Math.max(lineCount,1);
        y=new int[lineCount];
        
        //
        // 2) redimentionnement de la zonne GRID_DAY
        // s'il faut augmenter ou r�tr�cir la zonne d'ent�te jour
        if (hd.lineCount()!=lineCount) {
            // Modifie le nombre de ligne virtueles de l'ent�te jour
            hd.setLineCount(lineCount);
            _gridIconTools.getRoot().setGridDimension(_gridIconTools.getRoot().getGridWidth(), lineCount);
        }
        
        //
        // 3) Repositionnement des icones verticalement
        i=0;
//        while (i<lActivites.size()) {
//            child=(oComposant)lActivites.get(i);
//            if (child instanceof oActivite) {
//                //                ((oActivite)child).updateIconPosition();
//                size=child.getUserComposantSize();
//
//                for (j=0,y=1;j<size;j++) {
//                    aIcon=(oIcon)child.getUserComposantAt(j);
//
//                    if (aIcon.getUserID()!=JF_ICON_PRESENTIEL)
//                        x=child.getGridX();
//                    else
//                        x=aIcon.getGridX();
//
//                    aIcon.setGridPosition(x,y++);
//                }
//            }
//            i++;
//        }
        iDs=0;
        int n=0;
        int iD;
        while (i<lIcons.size()) {
            aIcon=(oIcon)lIcons.get(i);
            iD=aIcon.getUserID();
            if (aIcon.isVisible() && (iDs | iD)!=iDs) {
                iDs|=iD;
                // Place de l'ID en ligne n
                y[n++]=iD;
            }
            // positionnement
            for (j=0;j<n;j++) {
                if (y[j]==iD)
                    aIcon.setGridPosition(aIcon.getGridX(),j+1);
            }
            
            i++;
        }
        
        
    }
    
    
    /**
     * Mise � jour visuelle des ic�nes : position, taille. (apr�s un zoom du planning de r�f�rence)
     */
    public void updateChilds() {
        // mise � jour de l'ent�te
        _gridIconTools.updateChilds();
        
    }
    
    
    
    
}
