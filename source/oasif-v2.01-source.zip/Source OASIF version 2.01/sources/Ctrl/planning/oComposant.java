/*
 * oComposant.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 *
 * Created on 15 avril 2005, 14:58
 */

package Ctrl.planning;

import Ctrl.planning.grille.IGridConstraint;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Composite;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.ComponentEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JComponent;
import javax.swing.JToolTip;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


/**
 * Gestionnaire de composants OASIF depla�ables et enfichables. Chaque composant est d�crit avec deux systemes de coordonn�s : <br/>
 * <pre>
 *      les coordonn�s pixel de position et de taille dans l'espace de son parent. setBounds()
 *      les coordon�es grilles de position et de taille dans l'espace de la grille. setGridBounds()
 *
 *      Interface d'entr�e :
 *
 *      IPluginListener : messages de d�placement des composants en provenance
 *                        du gestionnaire PluginMngr.
 *
 *      KeyListener     : �v�nements clavier, ils sont transmis au listener IComponentEvent.
 *
 *      Interface de sortie :
 *
 *      IGridConstraint : gestionnaire de contraintes. Cette interface g�re les positions
 *                        en colonne, ligne. Elle translate les coordonn�s pixel vers les coordonn�s "grille" et inversement.
 *      IComponentEvent : transmet les �v�nements des composants (clique, move, select, keytype ...)
 *
 * </pre>
 *
 *
 * @author n.lavoillotte
 */
public class oComposant extends JComponent implements IPluginListener {
    
    
    // Un bord arrondis dont le rayon de l'arc ne varie pas
    class RoundBorder extends LineBorder {
        int _arcWidth,_arcHeight;
        Color   _color;
        RoundBorder(Color color, int thickness, int aW, int aH ) {
            super(color,thickness);
            _arcWidth=aW;
            _arcHeight=aH;
            _color=color;
        }
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Color oldColor = g.getColor();
            int i;
            
            g.setColor(_color);//getLineColor());
            for(i = 0; i < thickness; i++)
                g.drawRoundRect(x+i, y+i, width-i-i-1, height-i-i-1, _arcWidth, _arcHeight);
            
            g.setColor(oldColor);
        }
        public void setColor(Color color) {
            _color=color;;
        }
    }
    
    
    
    Border          _stdBorderStyle;
    Border          _rollOverBorderStyle;
    
    Color           _color;
    Color           _stdColor=Color.LIGHT_GRAY;
    Color           _rolloverColor=Color.GRAY;
    Color           _selectedColor=new Color(231,157,70);
    
    AlphaComposite  _alphaCmp;
    Object          _userObject;
    int             _userID;
    ArrayList <oComposant> _userComposants=null;
    
    
    
    IGridConstraint _gridConstraint;
    IComponentEvent _componentEvent;
    
    int             _iLevel;
    long            _lBehavior;
    //boolean         _bSelect;
    Rectangle       _gridBounds,_initGridBounds=null;
    Point           _gridOrg;
    boolean         _createByCloning=false;
    
    /**
     * Renvoie le mode de cr�ation de l'objet.
     *
     * @return type boolean. True si cr�� par clonnage, false si non.
     */
    public boolean isAclone() {
        return _createByCloning;
    }
    
    
    /**
     * Creation d'une instance de composant.
     *
     * @param g type IGridConstraint. Interface de gestion des contraintes de positionnement et de taille.
     * @param b type long. Les comportements
     * @param l type int. Le niveau d'imbrication.
     */
    public oComposant(IGridConstraint g, long b,int l) {
        //_bSelect=false;
        _iLevel=l;
        _lBehavior=b;
        
        setBorderStyle(new RoundBorder(_stdColor,1,12,12));
        setRollOverBorderStyle(new RoundBorder(_rolloverColor,2,12,12));
        
        
        setAlphaComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,(float).5));
        
        // Ajoute l'�couteur sur les �v�nements li�s au d�placement de composant
        addComponentListener(this);
        
        
        _gridBounds=new Rectangle();
        _gridOrg=new Point(1,1);
        setGridConstraint(g);
        _componentEvent=null;
        _userObject=null;
        _userID=0;
        
        
    }
    /**
     * Clonage par composant. Seul _userObject ne sera pas clon� !
     *
     * @param o type oComposant. Le composant de r�f�rence
     */
    public oComposant(oComposant o) {
        this(null,o.getBehavior(),o.getLevel());
        
        _createByCloning=true;
        
        _gridBounds.setBounds(o._gridBounds);
        _gridOrg.setLocation(o._gridOrg);
        _color=o._color;
        setColor(_color);
        _stdBorderStyle=o._stdBorderStyle;
        _rollOverBorderStyle=o._rollOverBorderStyle;
        setBorder(_stdBorderStyle);
        _alphaCmp=o._alphaCmp;
        _userID=o._userID;
        if (o._userObject!=null && o._userObject instanceof IUserObjectCloneable)
            _userObject=((IUserObjectCloneable)o._userObject).clone();
        
    }
    
    
    
    
    /**
     * Clonage par composant. Seul _userObject ne sera pas clon� !
     *
     * @param o type oComposant. Le composant de r�f�rence
     */
    public oComposant clone() {
        _userObjectCloneable=null;
        return new oComposant(this);
    }
    
    /**
     * Clonage par composant. Seul _userObject ne sera pas clon� !
     *
     * @param o type oComposant. Le composant de r�f�rence
     */
    IUserObjectCloneable _userObjectCloneable=null;
    public oComposant clone(IUserObjectCloneable uo) {
        _userObjectCloneable=uo;
        oComposant composant =new oComposant(this);
        
        return composant;
    }
    
    /**
     * Interface de gestion des contraintes
     *
     * @param g type IGridConsraint. L'interface de gestion des conrtaintes.
     */
    public void setGridConstraint(IGridConstraint g) {
        // Interface des contraintes
        _gridConstraint=g;
    }
    /**
     * Demande l'Interface de gestion des contraintes
     *
     * @return type IGridConsraint. L'interface de gestion des conrtaintes.
     */
    public IGridConstraint getGridConstraint() {
        // Interface des contraintes
        return _gridConstraint;
    }
    
    /**
     * Interface de gestion des �v�nements
     *
     * @param e type IComponentEvent. L'interface de gestion des �v�nements.
     */
    public void setComponentEvent(IComponentEvent e) {
        // Interface des contraintes
        _componentEvent=e;
    }
    /**
     * Demande l'Interface de gestion des �v�nements
     *
     * @return type IComponentEvent. L'interface de gestion des �v�nements.
     */
    public IComponentEvent getComponentEvent() {
        // Interface des contraintes
        return _componentEvent;
    }
    
    
    /**
     * Pr�pare le rectangle de position relative et de taille du composant qui sera utilis� par la methode addNotify(),
     * pour positionner le composant sur la grille par rapport � son parent.
     *
     * @param x type int. X base 1.
     * @param y type int. Y base 1.
     * @param width type int. Largeur.
     * @param height type int. Hauteur.
     */
    public void initGridBounds(int x, int y, int width, int height) {
        _initGridBounds=new Rectangle(x, y, width, height);
    }
    /**
     * Pr�pare le rectangle de position relative et de taille du composant qui sera utilis� par la methode addNotify(),
     * pour positionner le composant sur la grille par rapport � son parent.
     *
     * @param r type Rectanglet. Rectangle du composant base 1.
     */
    public void initGridBounds(Rectangle r) {
        _initGridBounds=r;
    }
    
    public void addNotify() {
        super.addNotify();
        if (_initGridBounds!=null) {
            setGridBounds(_initGridBounds);
            _initGridBounds=null;
        }
    }
    /**
     * Change la valeur de transparence de la composante alpha
     *
     * @param d type double. La valeur de transparence : 0..1
     */
    public void setAlphaComposite(float d) {
        _alphaCmp=AlphaComposite.getInstance(AlphaComposite.SRC_OVER,d);
        if (isVisible())
            repaint();
    }
    /**
     * Change le mode de composante alpha du composant
     *
     * @param alpha type AlphaComposite. Le mode alpha
     */
    public void setAlphaComposite(AlphaComposite alpha) {
        _alphaCmp=alpha;
        if (isVisible())
            repaint();
    }
    /**
     * Change le bord du compoosant.
     *
     * @param b type Border. Le nouveau bord � s�lectionner
     */
    public void setBorderStyle(Border b) {
        _stdBorderStyle=b;
        if (isVisible())
            repaint();
    }
    /**
     * Change le bord de survolle du compoosant.
     *
     * @param b type Border. Le nouveau bord de survolle � s�lectionner
     */
    public void setRollOverBorderStyle(Border b) {
        _rollOverBorderStyle=b;
    }
    
    /**
     * Change la couleur du composant
     *
     * @param color type Color. Sa nouvelle couleur.
     */
    public void setColor(Color color) {
        _color=color;
        if (isVisible())
            repaint();
    }
    /**
     * Change la couleur du bord d'un composant
     *
     * @param color type Color. Sa nouvelle couleur.
     */
    public void setBorderColor(Color color) {
        _stdColor=color;
        if (isVisible())
            repaint();
    }
    
    /**
     * Initialisation de la position et de taille du composant
     * les coordonn�es sont en colonnes, lignes.
     *
     * @param r type Rectangle. Les coordon�es base 1.
     */
    public void setGridBounds(Rectangle r) {
        setGridBounds(r.x,r.y,r.width,r.height);
    }
    
    /**
     * Initialisation de la position et de la taille du composant
     * les coordonn�es sont en colonnes, lignes relatis � son parent
     *
     * @param col type int. La colonne de d�part base 1.
     * @param line type int. La ligne de d�part base 1.
     * @param width type int. Le nombre de colonne.
     * @param height type int le nombre de ligne.
     */
    public void setGridBounds(int col, int line, int width, int height) {
        _gridBounds.setBounds(0,0,width, height);
        setGridPosition(col,line);
    }
    
    
    /**
     * Renvoie la position relative du composant. base 1
     *
     * @param p type Point. Le point de position base 1 modifi� en sortie.
     * @return type Point. (p) La position base 1.
     */
    public Point getGridPosition(Point p) {
        if (p==null)
            p=new Point();
        p.setLocation(_gridOrg);
        return p;
    }
    
    
    /**
     * Change la position de d�part du composant. (met � jour son bounds) la position est relative
     * � son parent.
     *
     * @param x type int. La nouvelle colonne base 1.
     * @param y type int. La nouvelle ligne base 1.
     * @return type boolean. True la position � chang�, false si non.
     */
    public boolean setGridPosition(int x, int y) {
        boolean     change=false;
        // Position absolue
        _gridBounds.x=x+getGridXParent()-1;
        _gridBounds.y=y+getGridYParent()-1;
        if (_gridBounds.x<0)
            change=false;
        
        // Position relative
        _gridOrg.x=x;
        _gridOrg.y=y;
        
        if (_gridConstraint!=null) {
            Rectangle settingBounds=new Rectangle(_gridBounds);
            
            _gridConstraint.gridToBounds(settingBounds);
            PluginMngr.convertRectangleFromScreen(settingBounds,getParent());
            if (!getBounds().equals(settingBounds)) {
                setBounds(settingBounds);
                change=true;
            }
        }
        return change;
    }
    
    /**
     * Change la position de d�part du composant. (met � jour son bounds) la position est relative � la grille
     * de son parent.
     *
     * @param p type Point. La nouvelle position base 1.
     * @return type boolean. True la position � chang�, false si non.
     */
    public boolean setGridPosition(Point p) {
        return setGridPosition(p.x,p.y);
    }
    
    
    /**
     * Change la dimension du composant. (met � jour son bounds)
     *
     * @param w type int. La nouvelle largeur.
     * @param h type int. La nouvelle hauteur.
     * @return type boolean. True la taille � chang�, false si non.
     */
    public boolean setGridDimension(int w, int h) {
        boolean     change=false;
        _gridBounds.width=w;
        _gridBounds.height=h;
        
        if (_gridConstraint!=null) {
            Rectangle bounds=new Rectangle(_gridBounds);
            _gridConstraint.gridToBounds(bounds);
            PluginMngr.convertRectangleFromScreen(bounds,this);
            if (!getBounds().equals(bounds)) {
                setBounds(bounds);
                change=true;
            }
        }
        return change;
        
    }
    
    /**
     * Change la dimension du composant. (met � jour son bounds)
     *
     * @param d type Dimension. La nouvelle dimension.
     * @return type boolean. True la position � chang�, false si non.
     */
    public boolean setGridDimension(Dimension d) {
        return setGridDimension(d.width,d.height);
    }
    
    /**
     * Renvoie la dimension du composant.
     *
     * @param d type Dimension. La dimension modifi�e en sortie.
     * @return type Dimension. (d) La dimension du composant.
     */
    public Dimension getGridDimension(Dimension d) {
        if (d==null)
            d=new Dimension();
        d.setSize(getGridWidth(), getGridHeight());
        return d;
    }
    
    /**
     * Attache un objet � la cellule.
     * @param o type Object. L'objet � attach�.
     */
    public void setUserObject(Object o) {
        _userObject=o;
    }
    /**
     * Demande l'objet attach� � la cellule.
     * @return type Object. NULL ou l'objet attach�.
     */
    public Object getUserObject() {
        return _userObject;
    }
    
    /**
     * Selection d'un identifiant pour ce composant
     *
     * @param id type int. L'identifiant � associer
     */
    public void setUserID(int id) {
        _userID=id;
    }
    
    /**
     * Demande l'identifiant du compoosant
     *
     * @return type int. L'identifaint en cours.
     */
    public int getUserID() {
        return _userID;
    }
    /**
     * Ajoute un composant utilisateur � la liste.
     *
     * @param o type oComposant. Le oComposant � ajouter
     *@return type int. L'index du composant ajout�.
     */
    public int addUserComposant(oComposant o) {
        
        if (_userComposants==null)
            _userComposants=new ArrayList<oComposant>();
        
        _userComposants.add(o);
        return _userComposants.size()-1;
    }
    /**
     * Retire un composant utilisateur de la liste.
     *
     * @param o le oComposant � retirer.
     * @return type oComposant. Le compoosant retir�, null si absent.
     */
    public oComposant removeUserComposant(oComposant o) {
        oComposant       res=null;
        int         indx=containsUserComposant(o);
        
        res=removeUserComposantAt(indx);
        return res;
    }
    
    /**
     * Retire un composant utilisateur � une position donn�e de la liste.
     *
     * @param iNdx type int. L'index du composant � retirer.
     * @return type oComposant. Le compoosant retir�, null si absent.
     */
    public oComposant removeUserComposantAt(int iNdx) {
        oComposant     res=null;
        
        if (_userComposants!=null && iNdx>=0 && iNdx<_userComposants.size())
            res=_userComposants.remove(iNdx);
        
        return res;
    }
    /**
     * Renvoie le composant utilisateur d'une position donn�e.
     *
     * @param iNdx type int. L'index du composant souhait�.
     * @return type oComposant. Le compoosant, null si absent.
     */
    public oComposant getUserComposantAt(int iNdx) {
        oComposant     res=null;
        
        if (_userComposants!=null && iNdx>=0 && iNdx<_userComposants.size())
            res=_userComposants.get(iNdx);
        
        return res;
    }
    
    /**
     * Demande l'index d'un composant de la liste.
     *
     * @param o le oComposant � trouver.
     * @return type int. L'index du composant base 0. -1 si absent.
     */
    public int containsUserComposant(oComposant o) {
        int     iNdx=-1;
        
        if (_userComposants!=null)
            iNdx=_userComposants.indexOf(o);
        
        return iNdx;
    }
    
    /**
     * Demande l'index de l'identifiant d'un composant de la liste.
     *
     * @param id type int. L'identiant a trouver.
     * @return type int. L'index du composant base 0. -1 si absent.
     */
    public int containsUserComposantID(int id) {
        int     i,max,iNdx=-1;
        oComposant   res;
        if (_userComposants!=null) {
            max=_userComposants.size();
            for (i=0;i<max;i++) {
                res=_userComposants.get(i);
                if (res.getUserID()==id)
                    break;
            }
            // R�sultat ?
            iNdx=(i<max ? i:-1);
        }
        
        return iNdx;
    }
    
    /**
     * Renvoie le nombre de composants utilisateur en cours
     *
     * @return type int. Total composant utilisateur.
     */
    public int getUserComposantSize() {
        int     res=0;
        
        if (_userComposants!=null)
            res=_userComposants.size();
        return res;
    }
    
    
    
    /**
     * Renvoie la colonne parente du composant en absolue par rapport � la grille.
     *
     * @return type int. La colonne base 1.
     */
    public int getGridXParent() {
        int     x=1;
        if (getParent() instanceof oComposant)
            x=((oComposant)getParent()).getGridX();
        return x;
    }
    
    /**
     * Renvoie la colonne du composant en relatif par rapport � son parent.
     *
     * @return type int. La ligne base 1.
     */
    public int getGridXOrg() {
        return _gridOrg.x;
    }
    /**
     * Renvoie la ligne du composant en relatif par rapport � son parent.
     *
     * @return type int. La ligne base 1.
     */
    public int getGridYOrg() {
        return _gridOrg.y;
    }
    /**
     * Renvoie la ligne parente du composant en absolue par rapport � la grille.
     *
     * @return type int. La ligne base 1.
     */
    public int getGridYParent() {
        int     y=1;
        if (getParent() instanceof oComposant)
            y=((oComposant)getParent()).getGridY();
        return y;
    }
    
    /**
     * Renvoie la colonne du composant en absolue par rapport � la grille.
     *
     * @return type int. La colonne base 1.
     */
    public int getGridX() {
        if (_initGridBounds!=null)
            return _initGridBounds.x;
        else
            return _gridBounds.x;
    }
    /**
     * Renvoie la ligne du composant en absolue par rapport � la grille.
     *
     * @return type int. La ligne base 1.
     */
    public int getGridY() {
        if (_initGridBounds!=null)
            return _initGridBounds.y;
        else
            return _gridBounds.y;
    }
    /**
     * Renvoie la largeur du composant.
     *
     * @return type int. La largeur.
     */
    public int getGridWidth() {
        if (_initGridBounds!=null)
            return _initGridBounds.width;
        else
            return _gridBounds.width;
    }
    /**
     * Renvoie la hauteur du composant.
     *
     * @return type int. La hauteur.
     */
    public int getGridHeight() {
        if (_initGridBounds!=null)
            return _initGridBounds.height;
        else
            return _gridBounds.height;
    }
    
   
    public Dimension getDimension() {
        int         n;
        Dimension   size=new Dimension(getWidth(),getHeight());
        return size;
    }
    String _label=null;
    public String getLabel() {
        return _label;
    }
    public void setLabel(String label) {
        _label=label;
    }
    
    public Dimension printComponent(Graphics g, int x,int y, Rectangle clip) {
        Dimension   size=new Dimension(getBounds().width, getBounds().height);
        if (!isVisible()) return size;
        
        draw(g, x, y, clip);
        Component  child;
        String      tt=getLabel();
        
        Color       old;
        if (tt!=null) {
            old=g.getColor();
            g.setColor(Color.BLACK);
            g.drawString(tt,x+3,y+10);
            g.setColor(old);
        }
        for (int n=0;n<getComponentCount();n++) {
            child=getComponent(n);
            
            // Les oComposants
            if (child instanceof oComposant) {
                ((oComposant)child).printComponent(g, x+child.getX(), y+child.getY(), clip);
            }
            // les autres
            else {
                Graphics2D g2D=(Graphics2D)g;
                // Translation pour le paint
                g2D.translate(x+child.getX(), y+child.getY());
                child.paintAll(g2D);
                tt=getLabel();
                if (tt!=null) {
                    old=g.getColor();
                    g.setColor(Color.BLACK);
                    g2D.drawString(tt,x+child.getX()+3, y+child.getY()+10);
                    g.setColor(old);
                    
                }
                // restore translation inverse
                g2D.translate(-(x+child.getX()), -(y+child.getY()));
            }
        }
        
        return size;
    }
    
    protected void draw(Graphics g, int x, int y,Rectangle clip) {
        Graphics2D g2 = (Graphics2D)g;
        
        Insets          insets=getInsets();
        Rectangle       r=new Rectangle(x+insets.left,y+insets.top,getBounds().width-insets.right,getBounds().height-insets.bottom);
        
        if (clip==null || clip.intersects(r)) {
            g2.setColor(_color);
            Composite cOld=g2.getComposite();
            if (_alphaCmp!=null)
                g2.setComposite(_alphaCmp);
            
            g2.fillRoundRect(r.x,r.y,r.width,r.height,12,12);
            
            g2.setComposite(cOld);
        }
        
        
    }
    
    /**
     * Desin du composant et dessein de la selection si le composant est s�lectionn�
     */
    public void paintComponent(Graphics g) {
        
        draw(g,0,0,g.getClipBounds());
        
        if (_stdBorderStyle!=null) {
            
            if (PluginMngr.isSelected(this)) {
                ((RoundBorder)_stdBorderStyle).setColor(_selectedColor);
                ((RoundBorder)_rollOverBorderStyle).setColor(_selectedColor);
            } else {
                ((RoundBorder)_stdBorderStyle).setColor(_stdColor);
                ((RoundBorder)_rollOverBorderStyle).setColor(_rolloverColor);
            }
            
            _stdBorderStyle.paintBorder(this, g, 0,0, getWidth(), getHeight());
        }
        
    }
    
    
    /**
     * Ajuste la taille global du composant au minimum, pour voir
     * tous les sous-composants
     *
     * @param hote type JComponent. Le composant parent � pars�.
     * @param r type Rectangle. La taille te position de l'hote dans son espace.
     */
    void adjustComponentsBounds(JComponent  hote, Rectangle r) {
        // Nombre de sous-composants int�gr�s
        int             count=hote.getComponentCount();
        Component       child;
        int             x,y,
                maxX=0,
                maxY=0;
        int             i;
        
        // Calcule l'espace minimum pour afficher tous les enfants
        for (i=count-1;i>=0;i--) {
            // Un enfant
            child=hote.getComponent(i);
            
            // Largeur et hauteur des enfants
            x=child.getBounds().x+child.getBounds().width;
            y=child.getBounds().y+child.getBounds().height;
            // Maximum
            if (x>maxX)
                maxX=x;
            if (y>maxY)
                maxY=y;
        }
        
        // Fixe le minimum en largeur et hauteur
        if (r.width<maxX)
            r.width=maxX;
        
        if (r.height<maxY)
            r.height=maxY;
        // Ajuste sur la grille
        adjustSize(r);
    }
    
    /**
     * Ajuste la position des composant enfants quand le parent � boug�.
     *
     * @param hote type JComponent. Le composant parent � pars�.
     * @param r type Rectangle. La taille et position de l'hote dans son espace.
     */
    void adjustComponentsPosition(JComponent  hote) {
        // Nombre de sous-composants int�gr�s
        int             count=hote.getComponentCount();
        Component       child;
        int             x,y;
        int             i;
        Point           org=new Point();
        boolean         change;
        // Calcule l'espace minimum pour afficher tous les enfants
        for (i=count-1;i>=0;i--) {
            // Un enfant
            child=hote.getComponent(i);
            change=false;
            if (child instanceof oComposant) {
                // Position  relative des enfants
                ((oComposant)child).getGridPosition(org);
                
                // Repositionne au m�me endroit pour valider ses coordonn�s grilles
                change=((oComposant)child).setGridPosition(org);
                
                // S'il ni a pas de changement "r�el" du bounds, le message componentMoved n'est pas g�n�r�.
                if (!change && ((JComponent)child).getComponentCount()>0) {
                    
                    // Transmet le message pour ajuster les composants enfants.
                    adjustComponentsPosition((JComponent)child);
                }
                
            }
            
        }
    }
    
    
    /**
     * Quand le composant � chang� de taille, valide ses dimentions.
     * action finale au lach� de la souris
     *
     * @param r type rectangle. Coordonn�s dans l'espace parent
     */
    void validateComponentsBounds(JComponent h, Rectangle r) {
        adjustComponentsBounds(h,r);
    }
    
    /**
     * Quand le composant � boug� ou chang� de taille, met � jour la
     * position et la taille du composant grille
     *
     * @param r type Rectangle. Les dimensions du composant en pixel.
     */
    void validateGridBounds(Rectangle r) {
        
        if (_gridConstraint!=null) {
            // Dans l'espace relatif du composant : 0,0
            Rectangle bounds=new Rectangle(0,0,r.width,r.height);
            
            PluginMngr.convertRectangleToScreen(bounds,this);
            _gridConstraint.boundsToGrid(bounds);
            _gridBounds.setBounds(bounds);
            _gridOrg.setLocation(getGridX()-getGridXParent()+1,getGridY()-getGridYParent()+1);
        }
        
    }
    
    /*
     * Ajuste la position du composant en l'allignant sur la grille.
     */
    void adjustPosition(Rectangle settingBounds) {
        if (_gridConstraint!=null) {
            PluginMngr.convertRectangleToScreen(settingBounds,this);
            _gridConstraint.adjustGridPosition(settingBounds,getGridWidth(),getGridHeight());
            PluginMngr.convertRectangleFromScreen(settingBounds,this);
        }
    }
    /**
     * Ajuste la largeur et la hauteur du composant en l'allignant sur la grille.
     */
    void adjustSize(Rectangle settingBounds) {
        if (_gridConstraint!=null)
            _gridConstraint.adjustGridSize(settingBounds,getGridX(),getGridY());
    }
    
    //
    // Impl�mentation de l'interface IPluginListener
    //
    public int getLevel() {
        return _iLevel;
    }
    public long getBehavior() {
        return _lBehavior;
    }
    public void setBehavior(long l) {
        _lBehavior=l;
    }
    /**
     * Renvoie l'objet JComponent
     */
    public JComponent getComponent() {
        return this;
    }
    
    /**
     * Demande les composants enfants du container courant
     *
     *  @param c type Class. La class de sous-composants souhait�s
     *  @return type ArrayList. La liste des composants (vide si aucun composant de type c)
     */
    public ArrayList<Component> getComposants(Class  c) {
        ArrayList<Component>       lComposant=new ArrayList<Component>();
        int             i,count=getComponentCount();
        Component       child;
        
        // recherche des s�quences
        for (i=0;i<count;i++) {
            // Un enfant
            child=getComponent(i);
            
            // Est ce que c est un instance de child ?
            // ou bien c est il l'anc�tre de child ?
            if (c.isInstance(child))
                lComposant.add(child);
            
        }
        return lComposant;
    }
    
    /**
     * Demande les composants enfants du container courant en remplissant une liste
     * pass� en param�tre
     *
     * @param c type Class. La class de sous-composants souhait�s
     * @param lComposant type ArrayList. La liste � compl�ter. Si null, cr�� une nouvelle liste.
     * @return type ArrayList. La liste des composants (vide si aucun composant de type c)
     */
    public ArrayList<Component> getComposants(Class  c, ArrayList<Component> lComposant) {
        Iterator        it=getComposants(c).iterator();
        
        if (lComposant==null)
            lComposant=new ArrayList<Component>();
        
        while (it.hasNext())
            lComposant.add((Component)it.next());
        
        return lComposant;
    }
    
    /**
     * Deamnde la liste compl�te de tous les composants et sous-composants enfants d'une classe
     * de composant.
     *
     * @param c type Class. La class de sous-composants souhait�s
     * @return type ArrayList. La liste de tous les composants enfants(vide si aucun composant de type c)
     */
    public ArrayList<Component> getAllComposants(Class c) {
        ArrayList<Component>       lComposant=getComposants(c);
        
        oComposant  o;
        
        int     i=0;
        while (i<lComposant.size()) {
            o=(oComposant)lComposant.get(i);
            o.getComposants(c,lComposant);
            i++;
        }
        return lComposant;
    }
    
    /**
     * Un composant est en train de changer de place, calcul et ajuste la position x,y
     * donn� dans l'espace du composant.
     */
    public void componentMoving(PluginEvent c) {
        JComponent  o=null;
        if (c.getComponent() instanceof JComponent)
            o=(JComponent)c.getComponent();
        
        if (o!=null) {
            //System.out.println("setting "+c.settingBounds);
            PluginMngr adapter=c.pluginAdapter;
            adjustPosition(c.settingBounds);
            // Future position du composant
            Rectangle       r=new Rectangle(c.settingBounds);
            // dans l'espace de son parent
            r.x+=getX();
            r.y+=getY();
            
            // Recherche une intersection avec un autre composant
            if (adapter.findIntersectionComponent(o,o.getParent(),r))
                // si il y a interaction, pas de changement de place
                c.settingBounds.setLocation(0,0);
            
        }
        
        
    }
    
    
    /**
     * Un composant est en train de changer de taille, calcul la taille minimum
     * pour contenir tous les sous-composants
     *
     */
    public void componentResizing(PluginEvent c) {
        JComponent  o=null;
        
        if (c.getComponent() instanceof JComponent)
            o=(JComponent)c.getComponent();
        
        if (o!=null) {
            PluginMngr adapter=c.pluginAdapter;
            adjustComponentsBounds(o,c.settingBounds);
            
            // Futur taille du composant
            Rectangle       r=new Rectangle(c.settingBounds);
            
            // dans l'espace de son parent
            r.x+=getX();
            r.y+=getY();
            
            // Recherche une intersection avec un autre composant
            if (adapter.findIntersectionComponent(o,o.getParent(),r)) {
                
                // R�duit la taille en retranchant l'intersection (largeur, hauteur)
                // en tenant compte de l'�tirrement par la droite ...
                if (o.getCursor().getType()==Cursor.E_RESIZE_CURSOR) {
                    if (c.settingBounds.width-r.width>0)
                        c.settingBounds.width-=r.width;
                }
                // ... ou par le bas
                else if (o.getCursor().getType()==Cursor.S_RESIZE_CURSOR) {
                    if (c.settingBounds.height-r.height>0)
                        c.settingBounds.height-=r.height;
                }
            }
            
            
        }
    }
    
    /**
     * Un composant : c.addingComponent, va �tre d�poser dans le composant
     * hote : c.getComponent().
     * V�rifie les niveaux d'imbrications et l'intersection avec un autre composant.
     * Renvoie par l'interm�diaire de c.addingComponent : null pour interdire, non null pour autoriser.
     */
    public void componentAdding(PluginEvent c) {
        // L'hote d'acceuil
        JComponent  hote=null;
        if (c.getComponent() instanceof JComponent)
            hote=(JComponent)c.getComponent();
        
        // Le composant � docker
        JComponent  toDock=(JComponent)c.addingComponent;
        if (hote!=null && toDock!=null) {
            PluginMngr adapter=c.pluginAdapter;
            
            // si le niveau du compoosant est >= au niveau actuel
            // refuse l'imbrication
            if (adapter.getLevel(toDock)>=adapter.getLevel(hote)) {
                // N'accepte pas
                c.addingComponent=null;
            } else {
                // Future position du composant dockable
                Rectangle       r=new Rectangle(c.settingBounds);
                // Dans l'espace de l'hote d'acceuil
                Point           p=SwingUtilities.convertPoint(toDock,r.x,r.y,hote);
                r.x=p.x;r.y=p.y;
                
                // Recherche une intersection possible
                if (adapter.findIntersectionComponent(toDock,hote,r)) {
                    // N'accepte pas
                    c.addingComponent=null;
                }
                
            }
        }
    }
    
    public void componentExited(PluginEvent c) {
        setBorder(_stdBorderStyle);
    }
    
    public void componentEntered(PluginEvent c) {
        setBorder(_rollOverBorderStyle);
    }
    
    /**
     * Un composant : c.addingComponent, vient d'�tre ajout� au composant
     * hote : c.getComponent().
     * valide la taille du composant hote
     */
    public void componentAdded(PluginEvent c) {
        // L'hote d'acceuil
        JComponent  hote=null;
        if (c.getComponent() instanceof JComponent)
            hote=(JComponent)c.getComponent();
        
        if (hote!=null) {
            Rectangle settingBounds=hote.getBounds();
            validateComponentsBounds(hote,settingBounds);
            
            // si changement ...
            if (!hote.getBounds().equals(settingBounds))
                // Ex�cute et ajoute l'action : setBounds, � la liste des actions undoabled
                c.pluginAdapter.addUndoableAction(new PActionSetBounds(hote,settingBounds));
            
        }
    }
    
    
    // Non cabl�
    public void componentHidden(ComponentEvent componentEvent) {
    }
    public void componentShown(ComponentEvent componentEvent) {
    }
    
    /**
     * La taille du composant vient de changer, r�ajuste la taille pour
     * que tous les sous-composants soit visibles
     *
     */
    public void componentResized(ComponentEvent c) {
        
        // Le composant
        JComponent  comp=null;
        JComponent  hote=null;
        
        if (c.getComponent() instanceof JComponent)
            comp=(JComponent)c.getComponent();
        
        // Valide la grille du composants
        if (comp!=null && comp instanceof oComposant) {
            validateGridBounds(comp.getBounds());
            
            if (_componentEvent!=null)
                _componentEvent.componentResized((oComposant)comp,(Rectangle)(_gridBounds.clone()));
        }
        
        
    }
    /**
     * Un composant � chang� de place, ajuste la position x, y,
     * r�ajuste la taille de son parent en cons�quence.
     */
    public void componentMoved(ComponentEvent c) {
        // Le composant
        JComponent  comp=null;
        JComponent  hote=null;
        
        if (c.getComponent() instanceof JComponent)
            comp=(JComponent)c.getComponent();
        
        // Valide la grille du composants
        if (comp!=null)
            validateGridBounds(comp.getBounds());
        
        
        // Valide la position du composant (uniquement les oComposants)
        if (comp!=null && comp instanceof oComposant) {
            adjustComponentsPosition(comp);
            
            if (_componentEvent!=null)
                _componentEvent.componentMoved((oComposant)comp,(Point)(_gridOrg.clone()));
            
        }
        
    }
    /** S�lection/dess�lection du composant */
    public void componentSelected(PluginEvent e) {
        //_bSelect=e.selectComponent;
        repaint();
        
        if (_componentEvent!=null && e.getComponent() instanceof oComposant)
            _componentEvent.componentSelected((oComposant)(e.getComponent()),e.selectComponent);
        
    }
    
    /** Clique (sans bouger) du composant*/
    public void componentClicked(PluginEvent e) {
        if (_componentEvent!=null && e.getComponent() instanceof oComposant)
            _componentEvent.componentClicked((oComposant)(e.getComponent()),e.pluginAdapter.getModifierKey());
        
    }
    
    public void componentKeyTyped(PluginEvent e) {
        if (_componentEvent!=null && e.getComponent() instanceof oComposant)
            _componentEvent.keyTyped((oComposant)(e.getComponent()),e.keyCode,e.pluginAdapter.getModifierKey());
    }
    
    public void componentKeyPressed(PluginEvent e) {
        if (_componentEvent!=null && e.getComponent() instanceof oComposant)
            _componentEvent.keyPressed((oComposant)(e.getComponent()),e.keyCode,e.pluginAdapter.getModifierKey());
    }
    
    public void componentKeyReleased(PluginEvent e) {
        if (_componentEvent!=null && e.getComponent() instanceof oComposant)
            _componentEvent.keyReleased((oComposant)(e.getComponent()),e.keyCode,e.pluginAdapter.getModifierKey());
    }
    
    
}
