/*
 * PlanningExporter.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 n.lavoillotte@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 *
 * Created on 9 f�vrier 2006, 16:39
 *
 */

package Ctrl.planning;

import Ctrl.planning.grille.Cellules;
import Gui.JComposant;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 *
 * @author nicolas.lavoillotte
 */
public class PlanningExporter {
    JComposant          _jcomposant;
    Dimension           _headSize,_daySize,_planningSize,_size;
    
    public PlanningExporter() {
    }
    /**
     * Instanciation
     */
    public PlanningExporter(JComposant jc) {
        setPlanning(jc);
    }
    
    public void setPlanning(JComposant jc) {
        _jcomposant=jc;
        
        
        // Taille de l'ent�te global
        _headSize=_jcomposant.getDimension(JPlanning.GRID_HEAD);
        _daySize =_jcomposant.getDimension(JPlanning.GRID_DAY);
        
        // Taille du planning courant
        _planningSize=_jcomposant.getDimension(JPlanning.GRID_PLANNING);
        
        // Taille globale
        if (_jcomposant.getPlanningOptions().getGeometry()==Cellules.VERTICAL)
            _size=new Dimension(_headSize.width, _headSize.height+_planningSize.height);
        else
            _size=new Dimension(_headSize.width+_planningSize.width, _headSize.height);
    }
    /**
     * Renvoie la largeur globale du planning courrant.
     *
     * @return type int. La largeur.
     */
    public int getWidth() {
        return _size.width;
    }
    /**
     * Renvoie la hauteur globale du planning courrant.
     *
     * @return type int. La hauteur.
     */
    public int getHeight() {
        return _size.height;
    }
    
    /**
     * Exporteur du planning courrant vers un graphique contexte.
     *
     * @param g type Graphics. Le GC de sortie.
     * @param x type int. La position x de d�part.
     * @param y type int. La position y de d�part.
     * @param clip type Rectangle. Le clipping. NULL si absent.
     */
    public void exportTo(Graphics g, int x, int y, Rectangle clip) {
        Graphics2D          g2d = (Graphics2D)g;
        Color               old;
        
        _jcomposant.printComponent(g, x,y, clip);
        
        
        
        // Encadrement du planning complet
        old=g.getColor();
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.drawRect(x, y, _size.width,_size.height);
        g2d.setColor(old);
        
        // Impression des composants
        if (_jcomposant.getPlanningOptions().getGeometry()==Cellules.VERTICAL) {
            
            // Impression des composants de l'ent�te jour
            if (_jcomposant.getIconsActiviteMngr()!=null)
                _jcomposant.getIconsActiviteMngr().getRoot().printComponent(g,x,y+_headSize.height-_daySize.height, clip);
            
            _jcomposant.getRoot().printComponent(g,x,y+_headSize.height,clip);
        } else {
            // Impression des composants de l'ent�te jour
            if (_jcomposant.getIconsActiviteMngr()!=null)
                _jcomposant.getIconsActiviteMngr().getRoot().printComponent(g,x+_headSize.width-_daySize.width, y, clip);
            
            _jcomposant.getRoot().printComponent(g,x+_headSize.width,y, clip);
        }
    }
}
