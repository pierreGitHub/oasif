/*
 * jTreeFormation.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 21 avril 2005, 13:25
 */

package Ctrl.ArbreFormation;


import Ctrl.planning.oComposant;
import data.XMLDoc.XMLUserObject;
import data.oasif.FORMATIONType;
import data.oasif.JOURSPLANIFIESType2;
import java.awt.Cursor;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;




/**
 *JTree {@link JTree} affichant l'arborescence des formations impl�mente les interfaces DragGestureListener{@link DragGestureListener},DragSourceListener {@link DragSourceListener},DropTargetListener {@link DropTargetListener}
 *
 *
 *
 * @author pierre.chanussot@educagri.fr
 */
public class JTreeFormation extends JTree implements TreeSelectionListener,TreeWillExpandListener, KeyListener  {
    
    boolean autofocus =false;
    SelectionTree treeSelection = new SelectionTree();
    RenderTree treeRender = new RenderTree();
    
    NoeudUserObject r = new NoeudUserObject("Formation(s) ouverte(s) :");
    public DefaultMutableTreeNode Root = new DefaultMutableTreeNode(r);
    DefaultMutableTreeNode noldselection = null;
    DefaultTreeModel monmodele = new DefaultTreeModel(Root) ;
    
    UndoableEditListener    undoLst;
    Insets autoscrollInsets = new Insets(20, 20, 20, 20); // insets
    Cursor _defaultCursor=new Cursor(Cursor.DEFAULT_CURSOR);
    
    
    class trans extends TransferHandler {
        public trans(){
            super();
        }
    }
    
    
    
    /** Creates a new instance of jTreeFormation */
    public JTreeFormation() {
        
        this(null);
    }
    /** Constructeur �tant appeler dans le constructeur par d�fault demandant en parametre un UndoableEditListener {@link UndoableEditListener}
     *
     *@param lst  type UndoableEditListener. Ecouteur undo/redo .
     */
    public JTreeFormation(UndoableEditListener lst) {
        setRootVisible(false);
        setShowsRootHandles(true);
        undoLst = lst;
        setFocus(Root);
        setScrollsOnExpand(true);
        setModel(monmodele);
        setSelectionModel(treeSelection);
        setCellRenderer(treeRender);
        setDragEnabled(false);
        setAutoscrolls(true);
        addTreeSelectionListener(this);
        addTreeWillExpandListener(this);
        ToolTipManager.sharedInstance().registerComponent(this);
        // Ecouteur sur le focus
        addFocusListener(new FocusListener(){
            
            public void focusGained(FocusEvent evt){
                
                DefaultMutableTreeNode noeudclick =(DefaultMutableTreeNode)treeSelection.getSelectionPath().getLastPathComponent();
                NoeudUserObject noeuduserobject = (NoeudUserObject)noeudclick.getUserObject();
                _treeEvent.treeClicked(noeuduserobject);
                autofocus = false;
            }
            
            public void focusLost(FocusEvent evt){
                
            }
            
        });
        
        setCursor(_defaultCursor);
        addKeyListener(this);
    }
    
    
    
    /**
     *Ajoute un noeud formation au Jtree
     *
     *@param f type DefaultMutableTreeNode. Noeud Formation .
     *
     *
     */
    public void addFormationNode(NoeudUserObject f,boolean focus){
        DefaultMutableTreeNode n = new DefaultMutableTreeNode(f);
        
        monmodele.insertNodeInto(n, Root,Root.getChildCount());
        monmodele.reload(n);
        if (focus)
            setFocus(n);
    }
    
    
    /**
     * Ajoute un noeud module � un noeud formation au Jtree
     *
     *@param f type NoeudUserObject. Noeud Formation .
     *@param m type NoeudUserObject. Noeud Module.
     *
     *
     *
     */
    public void addModuleNode(NoeudUserObject f,NoeudUserObject m){
        DefaultMutableTreeNode formation = NoeudUserObjecttoDefaultMutableTreeNodeFormation(f);
        DefaultMutableTreeNode module = new DefaultMutableTreeNode(m);
        int numero = m.getNumero()-1;
        if (formation.getChildCount() < m.getNumero()) {
            numero = formation.getChildCount();
            m.setNumero(numero +1);
            
        }
        monmodele.insertNodeInto(module, formation,numero);
        TreePath path = new TreePath(monmodele.getPathToRoot(formation));
        expandPath(path);
        monmodele.reload(formation);
    }
    
    public void moveModuleNode(NoeudUserObject f,NoeudUserObject m,int numero){
        DefaultMutableTreeNode formation = NoeudUserObjecttoDefaultMutableTreeNodeFormation(f);
        DefaultMutableTreeNode module = new DefaultMutableTreeNode(m);
        if (formation.getChildCount() < numero) {
            numero = formation.getChildCount();
            m.setNumero(numero +1);
        }
        monmodele.insertNodeInto(module, formation,numero);
        monmodele.reload(formation);
        setFocus(module);
        
    }
    
    /**
     * Supprime un noeud
     *
     *@param m type NoeudUserObject. Noeud
     *
     *
     *
     */
    public void removeNode(NoeudUserObject m){
        DefaultMutableTreeNode noeudsuppr = NoeudUserObjecttoDefaultMutableTreeNodeFormation(m);
        
        monmodele.removeNodeFromParent(noeudsuppr);
        monmodele.reload(noeudsuppr.getParent());
    }
    
    /**
     * Recupere l'ancienne selection
     *
     *@return  DefaultMutableTreeNode
     */
    public DefaultMutableTreeNode recupoldselectionnode() {
        return  noldselection;
        
    }
    
    
    /**
     * Recupere le noeud selectionn�
     *
     *@return  NoeudUserObject
     */
    public NoeudUserObject recupselectionnode() {
        TreePath tp = treeSelection.getSelectionPath();
        DefaultMutableTreeNode defaultmutabletreenode = (DefaultMutableTreeNode)  tp.getLastPathComponent();
        
        return (NoeudUserObject)defaultmutabletreenode.getUserObject();
    }
    
    
    
    /**
     *
     *Donne le oComposant formation d'un ocomposant donner en parametre
     *
     *
     *@param f type oComposant.
     */
    public oComposant parentof(oComposant o){
        oComposant ocomposantfind=null;
        
        for(int i =0;i<Root.getChildCount();i++) {
            DefaultMutableTreeNode parent = (DefaultMutableTreeNode)Root.getChildAt(i);
            
            for(int j =0;j<parent.getChildCount();j++) {
                DefaultMutableTreeNode child = (DefaultMutableTreeNode)parent.getChildAt(j);
                NoeudUserObject noeuduserobject = (NoeudUserObject)child.getUserObject();
                
                if (o == noeuduserobject.getoComposant()) {
                    NoeudUserObject noeudparent = (NoeudUserObject)parent.getUserObject();
                    ocomposantfind = noeudparent.getoComposant();
                }
            }
        }
        
        return ocomposantfind;
    }
    
    
    
    /**
     *Methode permettant de retrouver le DefaultMutableTreeNode
     * dans l'ensemble des noeuds d'un noeud donner en parametre � partir d'un String
     *
     *
     *@param n type DefaultMutableTreeNode. Noeud.
     *@param s type String. Chaine.
     *
     *@return type DefaultMutableTreeNode. Noeud trouv�.
     *
     **/
    public DefaultMutableTreeNode findNodewithString(DefaultMutableTreeNode n,String s){
        DefaultMutableTreeNode noeudfind = null;
        for(int i=0;i <n.getChildCount();i++){
            
            DefaultMutableTreeNode noeudcourant = (DefaultMutableTreeNode) n.getChildAt(i);
            NoeudUserObject userObject = (NoeudUserObject) noeudcourant.getUserObject();
            
            if (userObject.getLabel().equals(s)){
                noeudfind = noeudcourant;
            } else{
                
            }
            
        }
        return noeudfind ;
        
    }
    
    
    /**
     *M�thode permettant de retrouver le DefaultMutableTreeNode d'un NoeudUserObject de type "Formation"
     *
     *@param n type NeoudUserObject. Noeud.
     *
     *@return DefaultMutableTreeNode
     */
    public DefaultMutableTreeNode NoeudUserObjecttoDefaultMutableTreeNodeFormation(NoeudUserObject n) {
        DefaultMutableTreeNode defaultmutabletreenodefind=null;
        NoeudUserObject noeud = null;
        if (n == r) {
            defaultmutabletreenodefind = Root;
        }
        for(int i =0;i<Root.getChildCount();i++) {
            DefaultMutableTreeNode parent = (DefaultMutableTreeNode)Root.getChildAt(i);
            noeud = (NoeudUserObject)parent.getUserObject();
            if (n == noeud) {
                defaultmutabletreenodefind = parent;
            }
            
            for(int j =0;j<parent.getChildCount();j++){
                DefaultMutableTreeNode child = (DefaultMutableTreeNode)parent.getChildAt(j);
                noeud = (NoeudUserObject)child.getUserObject();
                
                if (n == noeud) {
                    defaultmutabletreenodefind = child;
                }
            }
        }
        
        return defaultmutabletreenodefind;
    }
    
    
    
    /**
     *Recupere NoeudUserObject d'un oComposant
     *
     *@param o type oComposant
     *
     *@return NoeudUserObject
     */
    public NoeudUserObject oComposanttoNoeudUserObject(oComposant o) {
        NoeudUserObject noeuduserobjectfind=null;
        NoeudUserObject noeuduserobject;
        for(int i =0;i<Root.getChildCount();i++) {
            
            DefaultMutableTreeNode parent = (DefaultMutableTreeNode)Root.getChildAt(i);
            noeuduserobject = (NoeudUserObject)parent.getUserObject();
            if (o == noeuduserobject.getoComposant()) {
                noeuduserobjectfind = noeuduserobject;
            }
            
            for(int j =0;j<parent.getChildCount();j++){
                DefaultMutableTreeNode child = (DefaultMutableTreeNode)parent.getChildAt(j);
                noeuduserobject = (NoeudUserObject)child.getUserObject();
                
                if (o == noeuduserobject.getoComposant()) {
                    noeuduserobjectfind = noeuduserobject;
                }
            }
        }
        
        return noeuduserobjectfind;
    }
    
    
    /**
     *Trouve TreePath d'un DefaultMutableTreeNode
     *et lui met le focus
     *
     *@param node type DefaultMutableTreeNode
     */
    public void setFocus(DefaultMutableTreeNode node) {
        autofocus = true;
        TreePath treePath = new TreePath(node.getPath());
        treeSelection.setSelectionPath(treePath);
        
    }
    
    
    
    /**
     *Renvoi un tableau de type ArrayList<NoeudUserObject> contenant les sous-composant du noeud formation donner en parametre
     *
     *@return ArrayList<oComposant>
     *
     */
    public ArrayList<NoeudUserObject> moduleslist(NoeudUserObject n) {
        ArrayList<NoeudUserObject> lComposant=new ArrayList<NoeudUserObject>();
        DefaultMutableTreeNode noeud = NoeudUserObjecttoDefaultMutableTreeNodeFormation(n);
        if (noeud == null){
            noeud = NoeudUserObjecttoDefaultMutableTreeNodeFormation(n);
        }
        for (int i = 0; i<noeud.getChildCount();i++) {
            DefaultMutableTreeNode noeudfilscourant = (DefaultMutableTreeNode)noeud.getChildAt(i);
            NoeudUserObject noeuduserobject = (NoeudUserObject)noeudfilscourant.getUserObject();
            
            lComposant.add(noeuduserobject);
        }
        
        return lComposant;
    }
    
    
    /**
     *Renvoi un tableau de type ArrayList<NoeudUserObject> contenant les noeuds formation du Jtree
     *
     *@return ArrayList<NoeudUserObject>
     *
     */
    public ArrayList<NoeudUserObject> formationslist() {
        ArrayList<NoeudUserObject> lFormation=new ArrayList<NoeudUserObject>();
        
        for (int i = 0; i<Root.getChildCount();i++) {
            DefaultMutableTreeNode noeudfilscourant = (DefaultMutableTreeNode)Root.getChildAt(i);
            NoeudUserObject noeuduserobject = (NoeudUserObject)noeudfilscourant.getUserObject();
            
            lFormation.add(noeuduserobject);
        }
        
        return lFormation;
    }
    
    /**
     *
     *Met a jour pour une formation donner les numeros de module situer au dessus du noeud donner en parametre(numero)
     *
     *
     *type 1 ascendant  --> Noeud supprimer , on redescend tout les noeuds du dessus de 1
     *type 2 descendant --> Noeud rajouter, on remonte tout les noeuds du dessus de 1
     */
    
    public void updateNumModule(NoeudUserObject n,int numero,int type) {
        ArrayList<NoeudUserObject> listModule = moduleslist(n);
        NoeudUserObject noeudformation = getNoeudUserObjectFormationofSelection();
        FORMATIONType _FORMATIONType = (FORMATIONType)((XMLUserObject)noeudformation.getoComposant().getUserObject()).getXMLNode();
        
        Iterator liste = listModule.iterator();
        NoeudUserObject  noeuduserobject;
        while(liste.hasNext()) {
            noeuduserobject=(NoeudUserObject)liste.next();
            if (type == 1){
                if (noeuduserobject.getNumero()> numero){
                    noeuduserobject.setNumero(noeuduserobject.getNumero()-1);
                }
            } else if (type == 2){
                if (noeuduserobject.getNumero() >= numero){
                    noeuduserobject.setNumero(noeuduserobject.getNumero()+1);
                }
            }
            
            XMLTools.FormationXMLParametrage.updateNumModule(_FORMATIONType,numero,type);
            
            updateUI();
            
        }
    }
    
    
    /**
     *Retourne le noeud formation du noeud selectionn�
     *
     */
    public NoeudUserObject getNoeudUserObjectFormationofSelection(){
        //Recupere le noeud de la formation concern� dans noeudformation
        NoeudUserObject noeudformation =null;
        NoeudUserObject noeudselect = getSelectionNode();
        if (isFormation(noeudselect)){
            noeudformation = noeudselect;
            
        }
        // Si le noeud selectionner est un noeud module
        else if (isModule(noeudselect)) {
            noeudformation = getParentof(noeudselect);
        }
        return noeudformation;
        
    }
    
    /**
     *Verifie si le noeud selectionner est une noeud formation
     *
     *@return Noeuduserobject
     *
     */
    public boolean isFormation(NoeudUserObject n){
        
        DefaultMutableTreeNode Noeud =  NoeudUserObjecttoDefaultMutableTreeNodeFormation(n);
        
        if (Noeud != null) {
            if (Noeud.getLevel() == 1){
                NoeudUserObject userobjectformation = (NoeudUserObject)Noeud.getUserObject();
                return true;
            } else {
                return false;
            }
            
        } else {return false;}
    }
    /**
     *Verifie si le noeud selectionner est une noeud module
     *
     *@return Noeuduserobject
     */
    public boolean isModule(NoeudUserObject n){
        DefaultMutableTreeNode Noeud =  NoeudUserObjecttoDefaultMutableTreeNodeFormation(n);
        if (Noeud.getLevel() == 2){
            NoeudUserObject userobjectmodule = (NoeudUserObject)Noeud.getUserObject();
            return true;
        } else {
            return false;
        }
        
        
    }
    
    /**
     * Autoscroll sur le JTREE pendant le drag and drop
     *
     *
     */
    public void autoscroll(Point cursorLocation)  {
        Insets insets = getAutoscrollInsets();
        Rectangle outer = getVisibleRect();
        Rectangle inner = new Rectangle(outer.x+insets.left, outer.y+insets.top, outer.width-(insets.left+insets.right), outer.height-(insets.top+insets.bottom));
        if (!inner.contains(cursorLocation))  {
            Rectangle scrollRect = new Rectangle(cursorLocation.x-insets.left, cursorLocation.y-insets.top,	insets.left+insets.right, insets.top+insets.bottom);
            scrollRectToVisible(scrollRect);
        }
    }
    
    
    /**
     * Grandeur du d�placement pendant l'autoscroll
     *
     *@return Insets
     */
    public Insets getAutoscrollInsets()  {
        return (autoscrollInsets);
    }
    
    
    
    
    
    
    
    
    
    ITreeEvent  _treeEvent;
    public void setTreeEvent(ITreeEvent t) {
        _treeEvent=t;
    }
    public ITreeEvent getTreeEvent() {
        return _treeEvent;
    }
    
    
    /**
     *Evenement executer lors du changement de selection ds le Jtree
     *
     */
    public void valueChanged(javax.swing.event.TreeSelectionEvent treeSelectionEvent) {
        // Retient l'ancien noeud selectionner
        if (autofocus == false){
            TActionSelectionNoeud actionselectionnoeud = new TActionSelectionNoeud(_treeEvent,treeSelectionEvent,this);
            undoLst.undoableEditHappened(new UndoableEditEvent(this,actionselectionnoeud));
        } else {
            DefaultMutableTreeNode noeudclick =(DefaultMutableTreeNode)treeSelectionEvent.getPath().getLastPathComponent();
            NoeudUserObject noeuduserobject = (NoeudUserObject)noeudclick.getUserObject();
            _treeEvent.treeClicked(noeuduserobject);
            autofocus = false;
        }
        
    }
    
    public NoeudUserObject getSelectionNode() {
        DefaultMutableTreeNode noeud = (DefaultMutableTreeNode)treeSelection.getSelectionPath().getLastPathComponent();
        return (NoeudUserObject)noeud.getUserObject();
    }
    
    
    /**
     *Retourne le parent du noeud
     *
     *@param n type NoeudUserObject
     *
     *
     *@return NoeudUserObject
     *
     */
    public NoeudUserObject getParentof(NoeudUserObject n){
        DefaultMutableTreeNode noeud = NoeudUserObjecttoDefaultMutableTreeNodeFormation(n);
        DefaultMutableTreeNode noeudParent = (DefaultMutableTreeNode)noeud.getParent();
        
        return (NoeudUserObject)noeudParent.getUserObject();
    }
    
    
    
    
    public void keyPressed(java.awt.event.KeyEvent keyEvent) {
    }
    
    public void keyReleased(java.awt.event.KeyEvent keyEvent) {
        
        if (_treeEvent != null){
            
            TreePath tpselected = getSelectionPath();
            DefaultMutableTreeNode Noeud = (DefaultMutableTreeNode) tpselected.getLastPathComponent();
            NoeudUserObject noeuduserobject = (NoeudUserObject) Noeud.getUserObject();
            _treeEvent.treeKeyReleased(noeuduserobject,keyEvent);
            
        }
    }
    
    public void keyTyped(java.awt.event.KeyEvent keyEvent) {
        
    }
    
    public void treeWillExpand(javax.swing.event.TreeExpansionEvent treeExpansionEvent) throws javax.swing.tree.ExpandVetoException {
    }
    
    /**
     *
     *Lorsque l'on collapse un noeud il selectionne automatiquement le noeud que l'on n'as collapse
     *
     */
    public void treeWillCollapse(javax.swing.event.TreeExpansionEvent treeExpansionEvent) throws javax.swing.tree.ExpandVetoException {
        DefaultMutableTreeNode noeudcollapse =(DefaultMutableTreeNode)treeExpansionEvent.getPath().getLastPathComponent();
        NoeudUserObject noeuduserobject = (NoeudUserObject)noeudcollapse.getUserObject();
        
        setFocus(NoeudUserObjecttoDefaultMutableTreeNodeFormation(noeuduserobject));
    }
    
    
}
