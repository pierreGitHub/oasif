/*
 * NoeudUserObject.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 2 juin 2005, 11:22
 */

package Ctrl.ArbreFormation;

import CVSPrj.IProjectMngr;
import Ctrl.planning.IUserObjectCloneable;
import Ctrl.planning.oComposant;
import Ctrl.planning.oFormation;
import Ctrl.planning.oModule;
import data.XMLDoc.XMLUserObject;
import data.altova.xml.Node;
import data.oasif.*;
import javax.swing.Icon;
import javax.swing.ImageIcon;


/**
 * UserObject de chaque Noeud du JTREE (JtreeFormation).
 *
 *
 * @author Pierre
 */
public class NoeudUserObject implements IUserObjectCloneable {
    
    
    IProjectMngr _iProjectMngr;
    String _string;
    // type : Module ou Formation
    String _type;
    // Permet de savoir si l'on a d�j� cliqu� sur le Noeud ou pas depuis l'ouverture de la Formation
    boolean _firstCalltoOpen = false;
    // Fin du texte ajouter au noeud
    String _EndText ="";
    // Label correspond au type + numero . ex : Module 1
    public String _label ="";
    // Icone du Noeud
    Icon _icon = new ImageIcon(getClass().getResource("/ressources/static/dossier.png"));
    // objet pour la partie planning
    oComposant _oComposant;
    // Composant FORMATIONTYPE ou MODULETYPE ( XML)
    Node _XMLNode;
    // Numero du composant 0 si formation sinon numero du Module
    int _numero=0;
    // Noeud precedent click�
    NoeudUserObject PreviousNoeudUserObjectClicked = null;
    
    
    /**
     * Constructeur par default de la classe.
     *
     *
     *@param s type String . Chaine (non du noeud).
     *@param o type oComposant. Composant (JPLanning).
     *@param jptg type JPanelTabbedGen . Composant (Proprietes).
     *
     * Creates a new instance of NoeudUserObject */
    public NoeudUserObject(String t,oComposant o) {
        if (o instanceof oModule) {
            _icon = new ImageIcon(getClass().getResource("/ressources/static/dossierlocal.png")); }
        _oComposant=o;
        _type = t;
        
        MAJTextNoeud();
    }
    
    
    /**
     * Constructeur par default de la classe.
     *
     *
     *@param s type String . Chaine (non du noeud).
     *@param o type oComposant. Composant (JPLanning).
     **@param numero type int . Numero du noeud pour un module.
     *
     * Creates a new instance of NoeudUserObject */
    public NoeudUserObject(String s,oComposant o,int numero) {
        if (o instanceof oModule) {
            _icon = new ImageIcon(getClass().getResource("/ressources/static/dossierlocal.png")); }
        _type = s;
        _oComposant=o;
        
        _numero=numero;
        _EndText ="";
        MAJTextNoeud();
        
    }
    
    
    /**
     *
     *Constructeur permettant de cr�er un clone
     *
     */
    public NoeudUserObject(NoeudUserObject n) {
       
        _icon = n.getIcon();
        _type = n._type;
        _oComposant=((oModule)n._oComposant).clone();
        MAJTextNoeud();
        
    }
    /**
     *
     *Constructeur du noeud racine
     *
     *
     */
    public NoeudUserObject(String titre) {
        _label = titre;
        
    }
    
    
    
    
    /**
     *
     *Cr�er un clone
     *
     *
     */
    public NoeudUserObject clone() {
        
        return new NoeudUserObject(this);
    }
    
    
    /**
     *Change l'icone du noeud
     *
     *
     */
    public void setIcon(Icon i){
        _icon = i;
        
    }
    
    /**
     *Return le oComposant n�cessaire � la reconstruction du Composant dans le JPlanning
     *
     *@return oComposant.
     */
    public oComposant getoComposant(){
        return _oComposant ;
        
    }
    
    /**
     *Modifie le oComposant n�cessaire � la reconstruction du Composant dans le JPlanning
     *
     *
     */
    public void setoComposant(oComposant o){
        _oComposant = o;
        
    }
    
    /**
     *Return le Node XML du oComposant
     *
     *@return oComposant.
     */
    public Node getNode(){
        return (Node)((XMLUserObject)_oComposant.getUserObject()).getXMLNode() ;
        
    }
    
    
    
    /**
     *Return l'icone du noeud
     *
     *@return Icon.
     */
    public Icon getIcon(){
        return _icon ;
        
    }
    
    
    
    /**
     *Change le String apparaissant dans le Jtree
     */
    public void setValuetoString(String s){
        _string = s;
        
    }
    
    /**
     *Return le nom du noeud
     *
     *@return String.
     */
    public String getType(){
        return _type ;
        
    }
    
    /**
     *Modifie la valeur du noeud
     *
     *@return String.
     */
    public void setType(String type){
        _type =  type ;
        MAJTextNoeud();
    }
    
    /**
     *Return le string afficher dans le JTree
     *
     *@return String.
     */
    public String toString(){
        return _string;
    }
    
    /**
     *Return le IProjectMngr du noeud
     * Ne possede une valeur que si c'est noeud formation
     *
     *@return oComposant.
     */
    public IProjectMngr getIProjectMngr(){
        
        return _iProjectMngr ;
        
    }
    
    /**
     *Modifie le IProjectMngr du noeud
     * Ne possede une valeur que si c'est noeud formation
     *
     */
    public void setIProjectMngr(IProjectMngr ipm){
        _iProjectMngr = ipm;
        
    }
    
    /**
     * Retourne le numero du composant
     *
     *@return int.
     *
     */
    public int getNumero(){return _numero;}
    
    
    /**
     * Met a jour le numero du composant necessaire lors de d�placement de module par exemple
     *
     *
     *
     */
    public void setNumero(int numero){
        _numero = numero;
        if (_oComposant != null && _oComposant instanceof oModule){
            MODULEType _MODULEType = (MODULEType)((XMLUserObject)_oComposant.getUserObject()).getXMLNode();
            // Met � jour le numero du module dans le XML
            XMLTools.ModuleXMLProprietes.set_NumeroModule(_MODULEType, _numero);
        }
        
        MAJTextNoeud();
    }
    
    
    /**
     *
     *retourne le "label" du noeud correspond au type + numero
     *
     *@return String.
     */
    public String getLabel(){return _label;}
    
    /**
     *
     *retourne la fin du texte du noeud
     *
     *@return String.
     */
    public String getEndText(){return _EndText;}
    
    /**
     *
     *Met a jour le fin du texte du noeud donner en parametre
     *
     *
     */
    public void setEndText(String endtext){
        _EndText = endtext;
        MAJTextNoeud();
    }
    
    
    /**
     * Met a jour le texte du noeud ainsi que le tooltip du ocomposant planning
     *
     *
     *
     */
    public void MAJTextNoeud(){
//        _label = _type ;
        // Si le noeud est un module
        if (_numero != 0) {
            _label = _type +" "+_numero;
        } else
            _label = _type;
        
        if (_oComposant != null && _oComposant instanceof oModule){
            
            MODULEType _MODULEType = (MODULEType)((XMLUserObject)_oComposant.getUserObject()).getXMLNode();
            PROPRIETES_MODULEType _PROPRIETES_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes(_MODULEType);
            DESCRIPTIF_MODULEType _DESCRIPTIF_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_MODULEType);
            tTITREType4 _tTITREType4 = XMLTools.ModuleXMLProprietes.get_Proprietes_Descriptif_Titre(_DESCRIPTIF_MODULEType);
            String Titre = _tTITREType4.getValue().getValue();
            if (Titre != null && Titre.length()!=0)
                _label = Titre;
            
            _oComposant.setToolTipText(_label);
            _oComposant.setLabel(_label);
        } else if (_oComposant != null && _oComposant instanceof oFormation){
            
            FORMATIONType _FORMATIONType = (FORMATIONType)((XMLUserObject)_oComposant.getUserObject()).getXMLNode();
            PROPRIETES_FORMATIONType _PROPRIETES_FORMATIONType = XMLTools.FormationXMLProprietes.get_Proprietes(_FORMATIONType);
            DESCRIPTIF_FORMATIONType _DESCRIPTIF_FORMATIONType = XMLTools.FormationXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_FORMATIONType);
            tTITREType3 _tTITREType3 = XMLTools.FormationXMLProprietes.get_Proprietes_Descriptif_Titre(_DESCRIPTIF_FORMATIONType);
            String Titre = _tTITREType3.getValue().getValue();
            if (Titre != null && Titre.length()!=0)
                _label = Titre;
            
            _oComposant.setToolTipText(_label);
            _oComposant.setLabel(_label);
        }
        
        _string = _label;
        if (_EndText != ""){
            _string = _string+" "+ _EndText;
        }
        
    }
    /**
     *
     *Noeud qui a �t� click� avant celui la
     *
     */
    public void setPreviousClickNoeudUserObject(NoeudUserObject n) {
        PreviousNoeudUserObjectClicked = n;
        
    }
    
    /**
     *
     *Met � jour le noeud qui a �t� click� avant celui la
     *
     */
    public NoeudUserObject getPreviousClickNoeudUserObject() {
        return PreviousNoeudUserObjectClicked;
        
    }
    
    /**
     *
     *Change a valeur de FirstCall --> qui permet de savoir si l'on a d�j� cliqu� sur le Noeud ou pas
     *
     *
     */
    public void setFirstCalltoOpen(boolean value){
        
        _firstCalltoOpen = value;
        
    }
    /**
     *
     *Retourne la valeur de FirstCall --> qui permet de savoir si l'on a d�j� cliqu� sur le Noeud ou pas
     */
    public boolean getFirstCalltoOpen(){
        return _firstCalltoOpen;
    }
    
    
}
