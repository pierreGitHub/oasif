/*
 * JTabbedPaneFormation.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 11 juillet 2005, 11:03
 */

package Ctrl.Proprietes.Formation;


import Ctrl.planning.oFormation;
import Gui.IOASIF;
import Gui.JTabbedPane.JPanelLeafTabbedPane;
import Gui.JTabbedPane.JTabbedPaneGen;
import OngletsProprietes.Formation.FormationOngletAccompagnement;
import OngletsProprietes.Formation.FormationOngletDescriptif;
import OngletsProprietes.Formation.FormationOngletInfosGlobales;
import data.oasif.FORMATIONType;
import javax.swing.JScrollPane;


/**
 *JTABBEDPANE pour les onglets "FORMATION"
 *
 * @author Pierre
 */
public class JTabbedPaneFormation extends JTabbedPaneGen {
    JPanelLeafTabbedPane jPanelDescriptif;
    JPanelLeafTabbedPane jPanelAccompagnement;
    JPanelLeafTabbedPane jPanelInfosGlobales;
    oFormation _oFormation;
    FORMATIONType _FORMATIONType;
    IOASIF oasif;
    
    /** Creates a new instance of JTabbedPaneFormation */
    public JTabbedPaneFormation(FORMATIONType node,oFormation composant,IOASIF o) {
        super();
         _FORMATIONType = node;
         _oFormation = composant;
         oasif = o;
        initComponents();
        
        // Titre des differents onglets
        String titreDescriptif = "Descriptif";
        String titreAccompagnement = "Accompagnement";
        String titreInfosGlobales = "Informations globales";
        
          // Ajoute les onglets au TabbedPane
        JScrollPane scrollpaneDescriptif = new JScrollPane();
        scrollpaneDescriptif.setViewportView(jPanelDescriptif);
        scrollpaneDescriptif.getVerticalScrollBar().setUnitIncrement(40);
        scrollpaneDescriptif.getHorizontalScrollBar().setUnitIncrement(40);
        addTab(titreDescriptif,scrollpaneDescriptif);
        JScrollPane scrollpaneAccompagnement = new JScrollPane();
        scrollpaneAccompagnement.setViewportView(jPanelAccompagnement);
        scrollpaneAccompagnement.getVerticalScrollBar().setUnitIncrement(40);
        scrollpaneAccompagnement.getHorizontalScrollBar().setUnitIncrement(40);
        addTab(titreAccompagnement, scrollpaneAccompagnement);
        JScrollPane scrollpaneInfosGlobales = new JScrollPane();
        scrollpaneInfosGlobales.setViewportView(jPanelInfosGlobales);
        scrollpaneInfosGlobales.getVerticalScrollBar().setUnitIncrement(40);
        scrollpaneInfosGlobales.getHorizontalScrollBar().setUnitIncrement(40);
        addTab(titreInfosGlobales, scrollpaneInfosGlobales);
    }
    
    private void initComponents(){
       
      
           // Differents onglets du JTabbedPane
        
        jPanelDescriptif = new FormationOngletDescriptif(_FORMATIONType,_oFormation,oasif);
        jPanelAccompagnement = new FormationOngletAccompagnement(_FORMATIONType,_oFormation,oasif);
        jPanelInfosGlobales = new FormationOngletInfosGlobales(_FORMATIONType,_oFormation,oasif);
        
       
    
    }
      /**
     *Rend actif , inactif les champs
     *
     */
    public void refreshGlobalPropriete(){
        jPanelDescriptif.refreshGlobalPropriete();
        jPanelAccompagnement.refreshGlobalPropriete();
        jPanelInfosGlobales.refreshGlobalPropriete();
    }
    
}
