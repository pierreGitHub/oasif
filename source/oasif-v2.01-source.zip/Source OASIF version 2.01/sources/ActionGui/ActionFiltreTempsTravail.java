/*
 * ActionFiltreTempsTravail.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 20 f�vrier 2006, 11:11
 *
 */

package ActionGui;

import Ctrl.planning.oActivite;
import Ctrl.planning.oModule;
import Gui.JBarreOutilsLocale;
import Gui.JComposant;
import Gui.JLegende;
import data.XMLDoc.XMLUserObject;
import data.oasif.ACCOMPAGNEMENTS_GLOBAUXType;
import data.oasif.ACCOMPAGNEMENT_ACTIVITEType;
import data.oasif.ACTIVITEType;
import data.oasif.DESCRIPTIF_ACTIVITEType;
import data.oasif.DESCRIPTIF_MODULEType;
import data.oasif.MODULEType;
import data.oasif.PROPRIETES_ACTIVITESType;
import data.oasif.PROPRIETES_MODULEType;
import data.oasif.nDUREEhType;
import data.oasif.nDUREEmnType;
import data.oasif.nNBRE_MAX_APPRENANTType;
import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 *Action sur Filtre "Temps de travail"
 *
 * @author Pierre
 */
public class ActionFiltreTempsTravail extends AbstractAction {
    int _TypeFiltre;
    ArrayList<Component> _listActivite=new ArrayList<Component>();
    JComposant _planning;
    JBarreOutilsLocale _jBarreOutilsLocale;
    JLegende _jLegende;
    String _intitule;
    
    // Type FILTRE
    public static final int AUCUN_FILTRE = 0;
    public static final int TEMPS_APPRENANT =1;
    public static final int TEMPS_ACCOMPAGNEMENT =2;
    
    // Niveaux de couleurs pour le filtre
    public static final Color NIVEAU_O = new Color(255,255,204);
    public static final Color NIVEAU_1 = new Color(255,204,51);
    public static final Color NIVEAU_2 = new Color(255,153,51);
    public static final Color NIVEAU_3 = new Color(204,51,51);
    public static final Color NIVEAU_4 = new Color(153,51,51);
    public static final Color NIVEAU_5 = new Color(102,51,51);
    
    int TempsMAXApprenant =0;
    int TempsMINApprenant = 0;
    int TempsMAXAccompagnement =0;
    int TempsMINAccompagnement = 0;
    
    
    /** Creates a new instance of ActionFiltreTempsTravail */
    public ActionFiltreTempsTravail(JBarreOutilsLocale jBarreOutilsLocale,JLegende jLegende,ArrayList<Component> listActivite,int TypeFiltre,JComposant planning,String intitule) {
        _TypeFiltre = TypeFiltre;
        _listActivite = listActivite;
        _planning = planning;
        _jBarreOutilsLocale = jBarreOutilsLocale;
        _jLegende = jLegende;
        
        _intitule = intitule;
        
        int tempsTotalApprenant = 0;
        int tempsTotalAccompagnement = 0;
        
        // CONCERNANT LES ACTIVITES DU MODULE...
        // POUR CHAQUE ACTIVITES
        for (int i =0; i<_listActivite.size();i++) {
            oActivite _oActiviteCourant = (oActivite)_listActivite.get(i);
            // Parcours les noeuds ACTIVITE
            ACTIVITEType _ACTIVITEType = (ACTIVITEType)((XMLUserObject)_oActiviteCourant.getUserObject()).getXMLNode();
            PROPRIETES_ACTIVITESType _PROPRIETES_ACTIVITESType = XMLTools.ActiviteXMLProprietes.get_Proprietes(_ACTIVITEType);
            DESCRIPTIF_ACTIVITEType _DESCRIPTIF_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_ACTIVITESType);
            ACCOMPAGNEMENT_ACTIVITEType _ACCOMPAGNEMENT_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement(_PROPRIETES_ACTIVITESType);
            
            
            // TEMPS DE TRAVAIL APPRENANT
            int tempscourantApprenant= 0;
            int tempsTotalEstimeH = 0;
            int tempsTotalEstimeMin = 0;
            nDUREEhType _nDUREEhType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif_TempsH(_DESCRIPTIF_ACTIVITEType);
            tempsTotalEstimeH = tempsTotalEstimeH + _nDUREEhType.getValue().getValue();
            nDUREEmnType _nDUREEmnType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif_TempsMn(_DESCRIPTIF_ACTIVITEType);
            tempsTotalEstimeMin = tempsTotalEstimeMin + _nDUREEmnType.getValue().getValue();
            // MIS A JOUR TEMPS TOTAL APPRENANT
            tempscourantApprenant = (tempsTotalEstimeH * 60) + tempsTotalEstimeMin ;
            tempsTotalApprenant = tempsTotalApprenant + tempscourantApprenant ;
            
            
            int tempscourantAccompagnement= 0;
            
            // TEMPS TOTAL D'ACCOMPAGNEMENT
            if (_ACCOMPAGNEMENT_ACTIVITEType.hasACCOMPAGNEMENTS_GLOBAUX()) {
                ACCOMPAGNEMENTS_GLOBAUXType accompagnementsGlobaux = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_AccompagnementsGlobaux(_ACCOMPAGNEMENT_ACTIVITEType);
                if (accompagnementsGlobaux != null){
                    // POUR CHAQUE ACCOMPAGNEMENT DE L ACTIVITE COURANTE
                    for (int j=1;j<accompagnementsGlobaux.getACCOMPAGNEMENT_GLOBALCount();j++) {
                        int tempscourant = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_TempsAccompagnement(_ACCOMPAGNEMENT_ACTIVITEType,j);
                        int NbreApprenant = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_NbreApprenant(_ACCOMPAGNEMENT_ACTIVITEType,j);
                        boolean calculPossible = true;
                        if(NbreApprenant > 0){
                            if (_planning.getRoot() instanceof oModule){
                                oModule _oModule = (oModule)_planning.getRoot();
                                MODULEType _MODULEType = (MODULEType) ((XMLUserObject)_oModule.getUserObject()).getXMLNode();
                                PROPRIETES_MODULEType _PROPRIETES_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes(_MODULEType);
                                DESCRIPTIF_MODULEType _DESCRIPTIF_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_MODULEType);
                                nNBRE_MAX_APPRENANTType _nNBRE_MAX_APPRENANTType = XMLTools.ModuleXMLProprietes.get_Proprietes_Descriptif_NbreApprenant(_DESCRIPTIF_MODULEType);
                                int NbreApprenantModule = _nNBRE_MAX_APPRENANTType.getValue().getValue();
                                if (NbreApprenantModule > 0)
                                    tempscourant = (tempscourant * NbreApprenantModule) / NbreApprenant;
                                else calculPossible = false;
                            }
                        }
                        if (calculPossible)
                            // MIS A JOUR TEMPS TOTAL ACCOMPAGNEMENT
                            tempsTotalAccompagnement = tempsTotalAccompagnement + tempscourant;
                        tempscourantAccompagnement = tempscourantAccompagnement + tempscourant;
                    }
                }
            }
            
            ////// TEMPS MAX et MIN APPRENANT
            // Premier tour de FOR
            if (i==0){
                TempsMAXApprenant = tempscourantApprenant;
                TempsMINApprenant = tempscourantApprenant;
                TempsMAXAccompagnement = tempscourantAccompagnement;
                TempsMINAccompagnement = tempscourantAccompagnement;
            } else {
                // Concernant TEMPS APPRENANT
                if (TempsMAXApprenant < tempscourantApprenant)
                    TempsMAXApprenant = tempscourantApprenant;
                if (TempsMINApprenant > tempscourantApprenant)
                    TempsMINApprenant = tempscourantApprenant;
                //Concernant TEMPS ACCOMPAGNEMENT
                if (TempsMAXAccompagnement < tempscourantAccompagnement)
                    TempsMAXAccompagnement = tempscourantAccompagnement;
                if (TempsMINAccompagnement > tempscourantAccompagnement)
                    TempsMINAccompagnement = tempscourantAccompagnement;
            }
            //////////////////////////////////////
            
        }
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        _jBarreOutilsLocale.initFiltre();
        if(_TypeFiltre == AUCUN_FILTRE) {
            
        } else {
            Icon filtreSelected = new ImageIcon(getClass().getResource("/ressources/img/btnliste_map_sel.png"));
            _jBarreOutilsLocale.jButtonTempsTravail.setIcon(filtreSelected);
            _jBarreOutilsLocale.jButtonTempsTravail.setToolTipText(_intitule);
            _jLegende.setFiltreTemps(true);
            for(int i=0;i<_listActivite.size();i++) {
                oActivite _oActivitecourant =(oActivite)_listActivite.get(i);
                
                ACTIVITEType NodeActivite = (ACTIVITEType)((XMLUserObject)_oActivitecourant.getUserObject()).getXMLNode();
                PROPRIETES_ACTIVITESType _PROPRIETES_ACTIVITESType = XMLTools.ActiviteXMLProprietes.get_Proprietes(NodeActivite);
                DESCRIPTIF_ACTIVITEType _DESCRIPTIF_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_ACTIVITESType);
                
                // SI FILTRE : Temps estim� apprenant
                if(_TypeFiltre == TEMPS_APPRENANT) {
                    //////////////////////////////
                    // Calcul des diff�rents niveaux
                    int Difference = TempsMAXApprenant - TempsMINApprenant;
                    int Tranche = Difference * 20 /100 ;
                    ///////////////////////////////
                    int LEVEL1 = TempsMINApprenant + Tranche;
                    int LEVEL2 = TempsMINApprenant + (Tranche*2);
                    int LEVEL3 = TempsMINApprenant + (Tranche*3);
                    int LEVEL4 = TempsMINApprenant + (Tranche*4);
                    int LEVEL5 = TempsMAXApprenant;
                    
                    int tempscourantApprenant= 0;
                    int tempsTotalEstimeH = 0;
                    int tempsTotalEstimeMin = 0;
                    nDUREEhType _nDUREEhType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif_TempsH(_DESCRIPTIF_ACTIVITEType);
                    tempsTotalEstimeH = tempsTotalEstimeH + _nDUREEhType.getValue().getValue();
                    nDUREEmnType _nDUREEmnType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif_TempsMn(_DESCRIPTIF_ACTIVITEType);
                    tempsTotalEstimeMin = tempsTotalEstimeMin + _nDUREEmnType.getValue().getValue();
                    // MIS A JOUR TEMPS TOTAL APPRENANT
                    tempscourantApprenant = (tempsTotalEstimeH * 60) + tempsTotalEstimeMin ;
                    if (tempscourantApprenant > 0){
                        // Si NIVEAU 1
                        if (tempscourantApprenant <= LEVEL1)
                            _oActivitecourant.setColor(NIVEAU_1);
                        // Si NIVEAU 2
                        else if (tempscourantApprenant <= LEVEL2){
                            _oActivitecourant.setColor(NIVEAU_2);
                        }
                        // Si NIVEAU 3
                        else if (tempscourantApprenant <= LEVEL3){
                            _oActivitecourant.setColor(NIVEAU_3);
                        }
                        // Si NIVEAU 4
                        else if (tempscourantApprenant <= LEVEL4){
                            _oActivitecourant.setColor(NIVEAU_4);
                        }
                        // Sinon NIVEAU 5
                        else if (tempscourantApprenant > LEVEL4) {
                            _oActivitecourant.setColor(NIVEAU_5);
                        }
                    } else{
                        _oActivitecourant.setColor(NIVEAU_O);
                        _oActivitecourant.setAlphaComposite(0.55f);
                    }
                }
                // SI FILTRE : Temps estim� apprenant
                if(_TypeFiltre == TEMPS_ACCOMPAGNEMENT) {
                    //////////////////////////////
                    // Calcul des diff�rents niveaux
                    int Difference = TempsMAXAccompagnement - TempsMINAccompagnement;
                    int Tranche = Difference * 20 /100 ;
                    ///////////////////////////////
                    int LEVEL1 = TempsMINAccompagnement + Tranche;
                    int LEVEL2 = TempsMINAccompagnement + (Tranche*2);
                    int LEVEL3 = TempsMINAccompagnement + (Tranche*3);
                    int LEVEL4 = TempsMINAccompagnement + (Tranche*4);
                    int LEVEL5 = TempsMAXAccompagnement;
                    
                    int tempscourantAccompagnement= 0;
                    ACCOMPAGNEMENT_ACTIVITEType _ACCOMPAGNEMENT_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement(_PROPRIETES_ACTIVITESType);
                    
                    // TEMPS TOTAL D'ACCOMPAGNEMENT
                    if (_ACCOMPAGNEMENT_ACTIVITEType.hasACCOMPAGNEMENTS_GLOBAUX()) {
                        ACCOMPAGNEMENTS_GLOBAUXType accompagnementsGlobaux = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_AccompagnementsGlobaux(_ACCOMPAGNEMENT_ACTIVITEType);
                        if (accompagnementsGlobaux != null){
                            // POUR CHAQUE ACCOMPAGNEMENT DE L ACTIVITE COURANTE
                            for (int j=1;j<accompagnementsGlobaux.getACCOMPAGNEMENT_GLOBALCount();j++) {
                                int tempscourant = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_TempsAccompagnement(_ACCOMPAGNEMENT_ACTIVITEType,j);
                                int NbreApprenant = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_NbreApprenant(_ACCOMPAGNEMENT_ACTIVITEType,j);
                                boolean calculPossible = true;
                                if(NbreApprenant > 0){
                                    if (_planning.getRoot() instanceof oModule){
                                        oModule _oModule = (oModule)_planning.getRoot();
                                        MODULEType _MODULEType = (MODULEType) ((XMLUserObject)_oModule.getUserObject()).getXMLNode();
                                        PROPRIETES_MODULEType _PROPRIETES_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes(_MODULEType);
                                        DESCRIPTIF_MODULEType _DESCRIPTIF_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_MODULEType);
                                        nNBRE_MAX_APPRENANTType _nNBRE_MAX_APPRENANTType = XMLTools.ModuleXMLProprietes.get_Proprietes_Descriptif_NbreApprenant(_DESCRIPTIF_MODULEType);
                                        int NbreApprenantModule = _nNBRE_MAX_APPRENANTType.getValue().getValue();
                                        if (NbreApprenantModule > 0)
                                            tempscourant = (tempscourant * NbreApprenantModule) / NbreApprenant;
                                        else calculPossible = false;
                                    }
                                }
                                if (calculPossible)
                                    tempscourantAccompagnement = tempscourantAccompagnement + tempscourant;
                            }
                        }
                    }
                    
                    if (tempscourantAccompagnement > 0){
                        // Si NIVEAU 1
                        if (tempscourantAccompagnement <= LEVEL1)
                            _oActivitecourant.setColor(NIVEAU_1);
                        // Si NIVEAU 2
                        else if (tempscourantAccompagnement <= LEVEL2)
                            _oActivitecourant.setColor(NIVEAU_2);
                        // Si NIVEAU 3
                        else if (tempscourantAccompagnement <= LEVEL3)
                            _oActivitecourant.setColor(NIVEAU_3);
                        // Si NIVEAU 4
                        else if (tempscourantAccompagnement <= LEVEL4)
                            _oActivitecourant.setColor(NIVEAU_4);
                        // Sinon NIVEAU 5
                        else if (tempscourantAccompagnement > LEVEL4)
                            _oActivitecourant.setColor(NIVEAU_5);
                    } else{
                        _oActivitecourant.setColor(NIVEAU_O);
                        _oActivitecourant.setAlphaComposite(0.55f);
                    }
                }
            }
        }
    }
    
}
