/*
 * ActionFiltreActiviteOnFormation.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */

package ActionGui;

import Ctrl.planning.oModule;
import Gui.JBarreOutilsLocale;
import Gui.JComposant;
import data.XMLDoc.XMLUserObject;
import data.oasif.DESCRIPTIF_MODULEType;
import data.oasif.MODULEType;
import data.oasif.PROPRIETES_MODULEType;
import data.oasif.nCARACTERISTIQUEType2;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 *"Action Filtre "Module" sur planning MODULE
 *
 * @author Pierre
 */
public class ActionFiltreActiviteOnFormation extends AbstractAction{
    long _IDCaracteristique;
    ArrayList<Component> _listModule=new ArrayList<Component>();
    JComposant _planning;
    JBarreOutilsLocale _jBarreOutilsLocale;
    String _intitule;
    
    
    /** Creates a new instance of ActionFiltreActiviteOnFormation */
    public ActionFiltreActiviteOnFormation(JBarreOutilsLocale jBarreOutilsLocale,ArrayList<Component> listModule,long ID,JComposant planning,String intitule) {
        _IDCaracteristique = ID;
        _listModule = listModule;
        _planning = planning;
        _jBarreOutilsLocale = jBarreOutilsLocale;
        _intitule = intitule;
        
    }
    
     public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        _jBarreOutilsLocale.initFiltre();
        // Si non renseign�
        if (_IDCaracteristique == -1){
            
        } else {
            Icon filtreSelected = new ImageIcon(getClass().getResource("/ressources/img/btnliste_map_sel.png"));
            _jBarreOutilsLocale.jButtonActivite.setIcon(filtreSelected);
            _jBarreOutilsLocale.jButtonActivite.setToolTipText(_intitule);
            for(int i=0;i<_listModule.size();i++) {
                oModule _oModulecourant =(oModule)_listModule.get(i);
                
                
                MODULEType NodeModule = (MODULEType)((XMLUserObject)_oModulecourant.getUserObject()).getXMLNode();
                PROPRIETES_MODULEType _PROPRIETES_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes(NodeModule);
                DESCRIPTIF_MODULEType _DESCRIPTIF_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_MODULEType);
                nCARACTERISTIQUEType2 _nCARACTERISTIQUEType2 = XMLTools.ModuleXMLProprietes.get_Proprietes_Descriptif_Caracteristique(_DESCRIPTIF_MODULEType);
                long IDCaracteristique = _nCARACTERISTIQUEType2.getValue().getValue();
                
                // Si la caract�ristique est le meme alors visible = true
                if (_IDCaracteristique != IDCaracteristique)
                {
                    _oModulecourant.setColor(new java.awt.Color(255,255,204));
                }
                
            }
        }
        
        
        
    }
    
}
