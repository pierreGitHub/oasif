/*
 * ActionClosePlanningJour.java
 *
 * Created on 27 mars 2006, 10:32
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ActionGui;

import Gui.FenetresInternes.PlanningJour;
import javax.swing.AbstractAction;

/**
 *
 *Action Fermer dans Fenetre "Planning jour"
 *
 * @author Pierre
 */
public class ActionClosePlanningJour extends AbstractAction{
    PlanningJour ownerframe;
    /** Creates a new instance of ActionClosePlanningJour */
    public ActionClosePlanningJour(PlanningJour parentframe) {
        ownerframe = parentframe;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        ownerframe.close();
    }
    
}
