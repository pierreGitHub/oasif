/*
 * ActionCopySequence.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * Created on 18 janvier 2006, 13:43
 */

package ActionGui;

import CopierColler.CutCopyPasteObject;
import Ctrl.planning.oFormation;
import Ctrl.planning.oSequence;
import Gui.IOASIF;
import javax.swing.AbstractAction;

/**
 *Copie l'object Sequence dans l'objet Copier/Coller
 * @author Pierre
 */
public class ActionInitCopySequence extends AbstractAction {
    
    IOASIF _oasif;
    oSequence _oSequence;

    oFormation _oFormation;
    
    /** Creates a new instance of ActionCopySequence */
    public ActionInitCopySequence(oSequence o, IOASIF oasif) {
        _oasif = oasif;
        _oSequence = o;
        _oFormation = (oFormation)_oasif.getJPanelTree().getNoeudUserObjectFormationofSelection().getoComposant();

    }
    
    public void doAction(){
        
        _oasif.setCopyPasteObject(new CutCopyPasteObject(_oFormation,_oSequence));
        
    }
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        doAction();
    }
    
}
