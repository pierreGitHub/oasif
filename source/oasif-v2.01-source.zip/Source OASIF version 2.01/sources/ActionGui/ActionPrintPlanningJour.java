/*
 * ActionPrintPlanningJour.java
 *
 * Created on 27 mars 2006, 10:21
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ActionGui;

import Ctrl.planning.PlanningPrinter;
import Gui.FenetresInternes.JPrinterPagesDialog;
import Gui.JComposant;
import java.awt.Dimension;
import java.awt.print.PrinterJob;
import javax.swing.AbstractAction;
import javax.swing.JDialog;

/**
 *
 *Action "Impression du planning journalier"
 *
 * @author Pierre
 */
public class ActionPrintPlanningJour extends AbstractAction  {
    JDialog ownerframe;
    JComposant _planningjour = null;
    
    /** Creates a new instance of ActionPrintPlanningJour */
    public ActionPrintPlanningJour(JDialog parentframe,JComposant planningjour) {
        ownerframe = parentframe;
        _planningjour =planningjour;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        if (_planningjour != null){
            PlanningPrinter pp=new PlanningPrinter(_planningjour,false);
            pp.setTitle(ownerframe.getTitle());
            Dimension  pages=new Dimension(pp.getNumberOfPageX()+1, pp.getNumberOfPageY()+1);
            PrinterJob pjob = PrinterJob.getPrinterJob();
            pjob.setPageable(pp);
            
            JPrinterPagesDialog jc=new JPrinterPagesDialog(ownerframe, pjob, pp.getPageFormat(0), pages);
            
            if (!jc.run())
                return;
            pp.setPageCountXY(pages.width,pages.height);
            try {
                
                pjob.print();
                System.gc();
                
            } catch (java.awt.print.PrinterException e) {
                System.out.println("Impression Planning Jour "+e);
                e.printStackTrace();
            }
        }
    }
    
}
