/*
 * ActionExportToSVG.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 *
 * Created on 16 mars 2006, 11:27
 *
 */

package ActionGui;

import Ctrl.planning.PlanningSVGgenerator;
import FunctionsTools.SVGFileFilter;
import Gui.IOASIF;
import Gui.JFileChooser.JFileChooserGui;
import Gui.JOptionPane.JOptionPaneGui;
import java.io.File;
import java.io.IOException;
import javax.swing.AbstractAction;
import javax.swing.JFileChooser;

/**
 *
 ** Action sur le menu "Fichier --> Exporter --> Planning courant --> au format SVG"
 *
 * @author Pierre
 */
public class ActionExportToSVG extends AbstractAction {
    IOASIF oasif;
    String chemin;
    String extension = ".svg";
    JFileChooserGui chooserSaveas;
    
    /** Creates a new instance of ActionExportToSVG */
    public ActionExportToSVG(IOASIF i)  {
        oasif = i;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        boolean validFileChooser =  FileChooserAction();
        if (validFileChooser){
            PlanningSVGgenerator svg=new PlanningSVGgenerator(oasif.getJPlanning());
            try {
                svg.generator(chemin +extension);
            }
            catch(IOException e) {
                e.printStackTrace();
            }
            oasif.getPreferenceUser().put("_LastFileChooser",chooserSaveas.getCurrentDirectory().getAbsolutePath());
        }
    }
    
     public boolean FileChooserAction(){
        boolean validFileChooser = false;
        SVGFileFilter _SVGFileFilter =new SVGFileFilter();
        // FILECHOOSER
        chooserSaveas = new JFileChooserGui(oasif.getPreferenceUser().get("_LastFileChooser", ""));
        chooserSaveas.setFileFilter(_SVGFileFilter);
        chooserSaveas.setDialogType(JFileChooser.SAVE_DIALOG);
        chooserSaveas.setDialogTitle("Exporter planning courant en SVG...");
        chooserSaveas.setApproveButtonToolTipText("Enregistrer le fichier SVG");
        chooserSaveas.repaint();
        
        // Resultat de la box FILECHOOSEER
        while (chooserSaveas.showSaveDialog(oasif.getFrameOASIF())== JFileChooser.APPROVE_OPTION) {
            extension = ".svg";
            chemin = chooserSaveas.getSelectedFile().getAbsolutePath();
            File fichier = new File(chemin);
            if (fichier.exists()){
                JOptionPaneGui confirmeRemplacer = new JOptionPaneGui();
                int Resultconfirm = confirmeRemplacer.showConfirmDialog(chooserSaveas,new String("Voulez-vous remplacer le fichier existant ?"),"Question",JOptionPaneGui.YES_NO_OPTION,JOptionPaneGui.QUESTION_MESSAGE);
                if (Resultconfirm == JOptionPaneGui.OK_OPTION ){
                    extension ="";
                    validFileChooser = true;
                    break;
                }
                
            } else{
                validFileChooser = true;
                break;
            }
        }
        
        return validFileChooser;
    }
}
