/*
 * ActionPrintPlanningCourant.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 27 f�vrier 2006, 16:27
 *
 */

package ActionGui;

import Ctrl.ArbreFormation.NoeudUserObject;
import Ctrl.planning.PlanningPrinter;
import Gui.FenetresInternes.JPrinterPagesDialog;
import Gui.IOASIF;
import java.awt.Dimension;
import java.awt.print.PrinterJob;
import javax.swing.AbstractAction;

/**
 *Action "Impression du planning courant"
 *
 * @author Pierre
 */
public class ActionPrintPlanningCourant extends AbstractAction {
    IOASIF _oasif;
    
    /** Creates a new instance of ActionPrintPlanningCourant */
    public ActionPrintPlanningCourant(IOASIF oasif) {
        _oasif = oasif;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        if (_oasif.getJPlanning() != null){
            PlanningPrinter pp=new PlanningPrinter(_oasif.getJPlanning(),false);
            NoeudUserObject noeudPlanning = _oasif.getJPanelTree().oComposanttoNoeudUserObject(_oasif.getJPlanning().getRoot());
            pp.setTitle(noeudPlanning.getLabel());
            Dimension  pages=new Dimension(pp.getNumberOfPageX()+1, pp.getNumberOfPageY()+1);
            PrinterJob pjob = PrinterJob.getPrinterJob();
            pjob.setPageable(pp);
            
            JPrinterPagesDialog jc=new JPrinterPagesDialog(_oasif.getFrameOASIF(), pjob, pp.getPageFormat(0), pages);
            
            if (!jc.run())
                return;
            pp.setPageCountXY(pages.width,pages.height);
            try {
                
                pjob.print();
                System.gc();
                
            } catch (java.awt.print.PrinterException e) {
                e.printStackTrace();
            }
        }
    }
}
