/*
 * ActionFiltreAccompagnement.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 22 d�cembre 2005, 11:39
 */

package ActionGui;

import Ctrl.planning.oActivite;
import Gui.JBarreOutilsLocale;
import Gui.JComposant;
import data.XMLDoc.XMLUserObject;
import data.oasif.ACCOMPAGNEMENTS_GLOBAUXType;
import data.oasif.ACCOMPAGNEMENT_ACTIVITEType;
import data.oasif.ACCOMPAGNEMENT_GLOBALType;
import data.oasif.ACTIVITEType;
import data.oasif.PROPRIETES_ACTIVITESType;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *Action "Filtre Accompagnement" qui rend visible les activit�s qui ont comme accompagnateur l'ID donn� en parametre
 *
 *
 * @author Pierre
 */
public class ActionFiltreAccompagnement extends AbstractAction {
    long _IDNom;
    ArrayList<Component> _listActivite=new ArrayList<Component>();
    JComposant _planning;
    JBarreOutilsLocale _jBarreOutilsLocale;
    String _intitule;
    
    /** Creates a new instance of ActionFiltreAccompagnement */
    public ActionFiltreAccompagnement(JBarreOutilsLocale jBarreOutilsLocale,ArrayList<Component> listActivite,long ID,JComposant planning,String intitule)  {
        
        _IDNom = ID;
        _listActivite = listActivite;
        _planning = planning;
        _jBarreOutilsLocale = jBarreOutilsLocale;
        _intitule = intitule;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        _jBarreOutilsLocale.initFiltre();
        // Si non renseign� --> aucun filtre
        if (_IDNom == -1){
            
        } else {
            Icon filtreSelected = new ImageIcon(getClass().getResource("/ressources/img/btnliste_map_sel.png"));
            _jBarreOutilsLocale.jButtonAccompagnement.setIcon(filtreSelected);
            _jBarreOutilsLocale.jButtonAccompagnement.setToolTipText(_intitule);
            for(int i=0;i<_listActivite.size();i++) {
                oActivite _oActivitecourant =(oActivite)_listActivite.get(i);
                boolean exist =false;
                ACTIVITEType NodeActivite = (ACTIVITEType)((XMLUserObject)_oActivitecourant.getUserObject()).getXMLNode();
                PROPRIETES_ACTIVITESType _PROPRIETES_ACTIVITESType = XMLTools.ActiviteXMLProprietes.get_Proprietes(NodeActivite);
                ACCOMPAGNEMENT_ACTIVITEType _ACCOMPAGNEMENT_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement(_PROPRIETES_ACTIVITESType);
                ACCOMPAGNEMENTS_GLOBAUXType _ACCOMPAGNEMENTS_GLOBAUXType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_AccompagnementsGlobaux(_ACCOMPAGNEMENT_ACTIVITEType);
                if (_ACCOMPAGNEMENTS_GLOBAUXType.hasACCOMPAGNEMENT_GLOBAL()){
                    
                    
                    for(int j=1;j<_ACCOMPAGNEMENTS_GLOBAUXType.getACCOMPAGNEMENT_GLOBALCount();j++) {
                        ACCOMPAGNEMENT_GLOBALType AccompagnementGlobalCourant =  XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_AccompagnementGlobal(_ACCOMPAGNEMENTS_GLOBAUXType,j);
                        long IDNom = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_Nom(AccompagnementGlobalCourant);
                        
                        if (_IDNom == IDNom) {
                            exist = true;
                            
                        }
                    }
                    
                }
                if (!exist){
                    _oActivitecourant.setColor(new java.awt.Color(255,255,204));
                    _oActivitecourant.setAlphaComposite(0.55f);
                }
                
            }
        }
    }
    
}
