/*
 * CutCopyPasteObject.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 24 janvier 2006, 13:57
 */

package CopierColler;

import Ctrl.planning.oComposant;
import Ctrl.planning.oFormation;
import java.util.ArrayList;
import java.util.Date;

/**
 *Objet Copier Coller de l'application
 *
 * @author Pierre
 */
public class CutCopyPasteObject {
    oFormation _oFormation;
    oComposant _composantCopy;
    ArrayList<Date> _listdate;
    
    /** Creates a new instance of CutCopyPasteObject */
    public CutCopyPasteObject(oFormation f,oComposant o) {
        _oFormation = f;
        _composantCopy = o;
    }
    
     public CutCopyPasteObject(oFormation f,oComposant o,ArrayList<Date> listdate) {
        _oFormation = f;
        _composantCopy = o;
        _listdate = listdate;
    }
    
    public oFormation getoFormation(){
        return _oFormation;
    }
    
    public oComposant getoComposantCopy(){
        return _composantCopy;
    }
    
     public ArrayList<Date> getListDatePlanifie(){
        return _listdate;
    }
    
    
    
}
