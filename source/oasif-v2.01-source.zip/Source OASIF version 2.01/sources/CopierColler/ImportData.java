/*
 * ImportData.java
 *
 * OASIF - application de gestion de sc�nario p�dagogique
 *
 * Copyright (C) 2006 pierre.chanussot@educagri.fr
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Created on 1 f�vrier 2006, 13:17
 */

package CopierColler;

import Ctrl.planning.oActivite;
import Ctrl.planning.oComposant;
import Ctrl.planning.oFormation;
import Ctrl.planning.oModule;
import Ctrl.planning.oSequence;
import data.XMLDoc.XMLUserObject;
import data.altova.types.SchemaInt;
import data.altova.types.SchemaLong;
import data.altova.types.SchemaString;
import data.oasif.ACCOMPAGNATEURSType;
import data.oasif.ACCOMPAGNATEURType;
import data.oasif.ACCOMPAGNEMENTS_GLOBAUXType;
import data.oasif.ACCOMPAGNEMENTS_GLOBAUXType3;
import data.oasif.ACCOMPAGNEMENTType;
import data.oasif.ACCOMPAGNEMENTType2;
import data.oasif.ACCOMPAGNEMENT_ACTIVITEType;
import data.oasif.ACCOMPAGNEMENT_GLOBALType;
import data.oasif.ACCOMPAGNEMENT_GLOBALType3;
import data.oasif.ACCOMPAGNEMENT_MODULEType;
import data.oasif.ACTIONSType;
import data.oasif.ACTIONType;
import data.oasif.ACTIVITEType;
import data.oasif.ACTIVITEType2;
import data.oasif.ATTITUDESType;
import data.oasif.ATTITUDEType;
import data.oasif.DESCRIPTIF_ACTIVITEType;
import data.oasif.FORMATIONType;
import data.oasif.MODULEType;
import data.oasif.NOMSType;
import data.oasif.NOMType;
import data.oasif.OUTILSType;
import data.oasif.OUTILS_SERVICESType;
import data.oasif.OUTILType;
import data.oasif.PARAM_FORMATIONType;
import data.oasif.PARAM_MODULEType;
import data.oasif.PRODUCTION_ACTIVITEType;
import data.oasif.PROPRIETES_ACTIVITESType;
import data.oasif.PROPRIETES_MODULEType;
import data.oasif.RESSOURCES_DOCSType;
import data.oasif.RESSOURCES_DOCS_ACTIVITEType;
import data.oasif.RESSOURCES_LOGISTIQUESType;
import data.oasif.RESSOURCES_PEDAGOGIQUESType;
import data.oasif.RESSOURCE_PEDAGOGIQUEType;
import data.oasif.SOUS_GROUPESType;
import data.oasif.SOUS_GROUPEType;
import data.oasif.TYPES_ACCOMPAGNEMENTType;
import data.oasif.TYPES_ACCOMPAGNEMENTType2;
import data.oasif.TYPES_ACTIVITESType;
import data.oasif.TYPES_RESSOURCESType;
import data.oasif.TYPES_SALLESType;
import data.oasif.TYPES_TRAVAILType;
import data.oasif.TYPE_ACCOMPAGNEMENTType;
import data.oasif.TYPE_ACCOMPAGNEMENTType2;
import data.oasif.TYPE_ACTIVITEType;
import data.oasif.TYPE_RESSOURCEType;
import data.oasif.TYPE_SALLEType;
import data.oasif.TYPE_TRAVAILType;
import data.oasif.nINDIVIDUELCOLLECTIFType;
import data.oasif.nOUTIL_ECHANGEType;
import data.oasif.nOUTIL_SUBSTITUTIONType;
import data.oasif.nOUTIL_SUBSTITUTIONType2;
import data.oasif.nOUTIL_SUBSTITUTIONType4;
import data.oasif.nTYPEType;
import data.oasif.nTYPE_OUTILType;
import data.oasif.nTYPE_OUTILType3;
import data.oasif.nTYPE_SALLEType;
import java.awt.Component;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 *Classe instancier losqu'une importation de donn�e est n�cessaire
 *
 * @author Pierre
 */
public class ImportData {
    
    // Stocke les ajout deja effectuer pour ne pas ajouter X fois le meme enregistrement
    ArrayList<Hashtable> listIDAdd = new ArrayList<Hashtable>();
    
    FORMATIONType _oldFORMATIONType;
    FORMATIONType _newFORMATIONType;
    
    oComposant _objectCopy;
    
    
    /** Creates a new instance of ImportData */
    public ImportData(oFormation oldFormation, oFormation newFormation,oComposant objectCopy) {
        _oldFORMATIONType = (FORMATIONType)((XMLUserObject)oldFormation.getUserObject()).getXMLNode();
        _newFORMATIONType = (FORMATIONType)((XMLUserObject)newFormation.getUserObject()).getXMLNode();
        _objectCopy = objectCopy;
        executeImportData();
    }
    
    
    /**
     *
     *Importation des donn�es de l'ancien formation � la nouvelle suivant l'objet
     *
     */
    public void executeImportData(){
        // Si c'est un MODULE
        if (_objectCopy instanceof oModule){
            oModule _oModule = (oModule)_objectCopy;
            importDataofModule(_oModule);
            // Liste des sequences du module
            ArrayList<Component> listesequence = _oModule.getSequences();
            for (int i=0;i< listesequence.size();i++) {
                oSequence _oSequenceCourant = (oSequence)listesequence.get(i);
                importDataofSequence(_oSequenceCourant);
            }
            // Liste des activit�s du module
            ArrayList<Component> listeactivites = _oModule.getActivites();
            for (int i=0;i< listeactivites.size();i++) {
                oActivite _oActiviteCourant = (oActivite)listeactivites.get(i);
                importDataofActivite(_oActiviteCourant);
            }
            
        }
        // Si c'est une SEQUENCE
        else if (_objectCopy instanceof oSequence){
            oSequence _oSequence = (oSequence)_objectCopy;
            importDataofSequence(_oSequence);
            // Liste des activit�s du module
            ArrayList<Component> listeactivites = _oSequence.getActivites();
            for (int i=0;i< listeactivites.size();i++) {
                oActivite _oActiviteCourant = (oActivite)listeactivites.get(i);
                importDataofActivite(_oActiviteCourant);
            }
        }
        // Si c'est une ACTIVITE
        else if (_objectCopy instanceof oActivite){
            oActivite _oActivite = (oActivite)_objectCopy;
            importDataofActivite(_oActivite);
        }
        
    }
    /**
     *
     *Importation des donn�es pour le MODULE donn� en parametre
     *
     */
    public void importDataofModule(oModule _oModule){
        
        
        // Accompagnateurs dans l'onglet ACCOMPAGNEMENT
        MODULEType _MODULEType = (MODULEType)((XMLUserObject)_oModule.getUserObject()).getXMLNode();
        
        // Parcours les prori�t� du module
        PROPRIETES_MODULEType _PROPRIETES_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes(_MODULEType);
        ACCOMPAGNEMENT_MODULEType _ACCOMPAGNEMENT_MODULEType = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement(_PROPRIETES_MODULEType);
        
        /// Parcours l'ancienne formation
        PARAM_MODULEType _oldPARAM_MODULEType = XMLTools.FormationXMLParametrage.get_ParametrageModule(_oldFORMATIONType);
        ACCOMPAGNEMENTType2 _oldACCOMPAGNEMENTType2 = XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement(_oldPARAM_MODULEType);
        PARAM_FORMATIONType _oldPARAM_FORMATIONType = XMLTools.FormationXMLParametrage.get_ParametrageFormation(_oldFORMATIONType);
        ACCOMPAGNEMENTType _oldACCOMPAGNEMENTType = XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement(_oldPARAM_FORMATIONType);
        OUTILS_SERVICESType _oldOUTILS_SERVICESType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices(_oldPARAM_FORMATIONType);
        
        /// Parcours la nouvelle formation
        PARAM_MODULEType _newPARAM_MODULEType = XMLTools.FormationXMLParametrage.get_ParametrageModule(_newFORMATIONType);
        ACCOMPAGNEMENTType2 _newACCOMPAGNEMENTType2 = XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement(_newPARAM_MODULEType);
        PARAM_FORMATIONType _newPARAM_FORMATIONType = XMLTools.FormationXMLParametrage.get_ParametrageFormation(_newFORMATIONType);
        ACCOMPAGNEMENTType _newACCOMPAGNEMENTType = XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement(_newPARAM_FORMATIONType);
        OUTILS_SERVICESType _newOUTILS_SERVICESType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices(_newPARAM_FORMATIONType);
        
        //////////////////////////////////////////
        // ACCOMPAGNEMENT GLOBAUX
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ACCOMPAGNEMENTS_GLOBAUXType3 _ACCOMPAGNEMENTS_GLOBAUXType3 = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_AccompagnementsGlobaux(_ACCOMPAGNEMENT_MODULEType);
        // Pour chaque accompagnement r�el
        for (int i=1 ; i<_ACCOMPAGNEMENTS_GLOBAUXType3.getACCOMPAGNEMENT_GLOBALCount();i++) {
            long newIDNom=0;
            long newIDType=0;
            long newIDAttitude=0;
            long newIDGroupe=0;
            
            
            ACCOMPAGNEMENT_GLOBALType3 _ACCOMPAGNEMENT_GLOBALType3 = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_AccompagnementsGlobaux(_ACCOMPAGNEMENTS_GLOBAUXType3,i);
            
            
            //////////////////////////////////////////
            // NOM ACCOMPAGNATEUR
            //////////////////////////////////////////
            long IDNom = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_Nom(_ACCOMPAGNEMENT_GLOBALType3);
            
            if (_oldACCOMPAGNEMENTType2.hasNOMS()) {
                // Noeud NOM
                NOMType _NOMType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Nom(IDNom,_oldACCOMPAGNEMENTType2);
                if (_NOMType != null) {
                    NOMSType _NOMSType = XMLTools.FormationXMLParametrage.get_ParametrageModule_Noms(_newACCOMPAGNEMENTType2);
                    // Cr�er un nouvelle ID dans la nouvelle formation
                    newIDNom = getnewID(IDNom,_newFORMATIONType);
                    boolean add = false;
                    if (newIDNom <100){
                        // Champ par default n'existe pas dans la nouvelle formation
                        if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Nom(IDNom,_newACCOMPAGNEMENTType2)==null){
                            add=true;
                        }
                    } else{
                        add=true;
                    }
                    boolean alReadyAdd = alReadyAdd(IDNom,listIDAdd);
                    // Ajout du noeud NOM � la nouvelle formation
                    if (add){
                        if (alReadyAdd){
                            newIDNom = getIDinlistIDAdd(IDNom,listIDAdd);
                        } else {
                            NOMType _NOMSTypeNew = _NOMSType.newNOM();
                            _NOMSTypeNew.addnID(new SchemaLong(newIDNom));
                            _NOMSTypeNew.addtINTITULE_NOM(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleNom(_NOMType)));
                            _NOMSTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireNom(_NOMType)));
                            _NOMSTypeNew.addtMEL(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_MelNom(_NOMType)));
                            _NOMSType.addNOM(_NOMSTypeNew);
                            Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                            _Hashtable.put(new Long(IDNom),new Long(newIDNom));
                            listIDAdd.add(_Hashtable);
                            
                        }
                        
                    }
                } else {
                    ACCOMPAGNATEURType _ACCOMPAGNATEURType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_Accompagnateur(IDNom,_oldACCOMPAGNEMENTType);
                    
                    ACCOMPAGNATEURSType _ACCOMPAGNATEURSType = XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_Accompagnateurs(_newACCOMPAGNEMENTType);
                    // Cr�er un nouvelle ID dans la nouvelle formation
                    newIDNom = getnewID(IDNom,_newFORMATIONType);
                    boolean add = false;
                    if (newIDNom <100){
                        // Champ par default n'existe pas dans la nouvelle formation
                        if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_Accompagnateur(IDNom,_newACCOMPAGNEMENTType)==null){
                            add=true;
                        }
                    } else{
                        add=true;
                    }
                    boolean alReadyAdd = alReadyAdd(IDNom,listIDAdd);
                    // Ajout du noeud NOM � la nouvelle formation
                    if (add){
                        if (alReadyAdd){
                            newIDNom = getIDinlistIDAdd(IDNom,listIDAdd);
                        } else {
                            ACCOMPAGNATEURType _ACCOMPAGNATEURTypeNew = _ACCOMPAGNATEURSType.newACCOMPAGNATEUR();
                            _ACCOMPAGNATEURTypeNew.addnID(new SchemaLong(newIDNom));
                            _ACCOMPAGNATEURTypeNew.addtINTITULE_ACCOMPAGNATEUR(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_IntituleAccompagnateur(_ACCOMPAGNATEURType)));
                            _ACCOMPAGNATEURTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_CommmentaireAccompagnateur(_ACCOMPAGNATEURType)));
                            _ACCOMPAGNATEURTypeNew.addtMEL(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_MelAccompagnateur(_ACCOMPAGNATEURType)));
                            _ACCOMPAGNATEURSType.addACCOMPAGNATEUR(_ACCOMPAGNATEURTypeNew);
                            Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                            _Hashtable.put(new Long(IDNom),new Long(newIDNom));
                            listIDAdd.add(_Hashtable);
                            
                        }
                        
                    }
                }
            }
            //////////////////////////////////////////
            // TYPE ACCOMPAGNEMENT
            //////////////////////////////////////////
            long IDType = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_Type(_ACCOMPAGNEMENT_GLOBALType3);
            
            if (_oldACCOMPAGNEMENTType2.hasTYPES_ACCOMPAGNEMENT()) {
                // Noeud TYPE ACCOMPAGNEMENT
                TYPE_ACCOMPAGNEMENTType2 _TYPE_ACCOMPAGNEMENTType2 = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeAccompagnement(IDType,_oldACCOMPAGNEMENTType2);
                if (_TYPE_ACCOMPAGNEMENTType2 != null) {
                    TYPES_ACCOMPAGNEMENTType2 _TYPES_ACCOMPAGNEMENTType2 = XMLTools.FormationXMLParametrage.get_ParametrageModule_TypesAccompagnement(_newACCOMPAGNEMENTType2);
                    // Cr�er un nouvelle ID dans la nouvelle formation
                    newIDType = getnewID(IDType,_newFORMATIONType);
                    boolean add = false;
                    if (newIDType <100){
                        // Champ par default n'existe pas dans la nouvelle formation
                        if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeAccompagnement(IDType,_newACCOMPAGNEMENTType2)==null){
                            add=true;
                        }
                    } else{
                        add=true;
                    }
                    boolean alReadyAdd = alReadyAdd(IDType,listIDAdd);
                    // Ajout du noeud TYPE � la nouvelle formation
                    if (add){
                        if (alReadyAdd){
                            newIDType = getIDinlistIDAdd(IDType,listIDAdd);
                        } else {
                            TYPE_ACCOMPAGNEMENTType2 TYPE_ACCOMPAGNEMENTType2New = _TYPES_ACCOMPAGNEMENTType2.newTYPE_ACCOMPAGNEMENT();
                            TYPE_ACCOMPAGNEMENTType2New.addnID(new SchemaLong(newIDType));
                            TYPE_ACCOMPAGNEMENTType2New.addtINTITULE_TYPE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleTypeAccompagnement(_TYPE_ACCOMPAGNEMENTType2)));
                            TYPE_ACCOMPAGNEMENTType2New.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireTypeAccompagnement(_TYPE_ACCOMPAGNEMENTType2)));
                            _TYPES_ACCOMPAGNEMENTType2.addTYPE_ACCOMPAGNEMENT(TYPE_ACCOMPAGNEMENTType2New);
                            Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                            _Hashtable.put(new Long(IDType),new Long(newIDType));
                            listIDAdd.add(_Hashtable);
                        }
                    }
                } else{
                    TYPE_ACCOMPAGNEMENTType _TYPE_ACCOMPAGNEMENTType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_TypeAccompagnement(IDType,_oldACCOMPAGNEMENTType);
                    ////////////
                    TYPES_ACCOMPAGNEMENTType _TYPES_ACCOMPAGNEMENTType = XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_TypesAccompagnements(_newACCOMPAGNEMENTType);
                    // Cr�er un nouvelle ID dans la nouvelle formation
                    newIDType = getnewID(IDType,_newFORMATIONType);
                    boolean add = false;
                    if (newIDType <100){
                        // Champ par default n'existe pas dans la nouvelle formation
                        if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_TypeAccompagnement(IDType,_newACCOMPAGNEMENTType)==null){
                            add=true;
                        }
                    } else{
                        add=true;
                    }
                    boolean alReadyAdd = alReadyAdd(IDType,listIDAdd);
                    // Ajout du noeud TYPE � la nouvelle formation
                    if (add){
                        if (alReadyAdd){
                            newIDType = getIDinlistIDAdd(IDType,listIDAdd);
                        } else {
                            TYPE_ACCOMPAGNEMENTType _TYPE_ACCOMPAGNEMENTTypeNew = _TYPES_ACCOMPAGNEMENTType.newTYPE_ACCOMPAGNEMENT();
                            _TYPE_ACCOMPAGNEMENTTypeNew.addnID(new SchemaLong(newIDType));
                            _TYPE_ACCOMPAGNEMENTTypeNew.addtINTITULE_TYPE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_IntituleTypeAccompagnement(_TYPE_ACCOMPAGNEMENTType)));
                            _TYPE_ACCOMPAGNEMENTTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_CommmentaireTypeAccompagnement(_TYPE_ACCOMPAGNEMENTType)));
                            _TYPES_ACCOMPAGNEMENTType.addTYPE_ACCOMPAGNEMENT(_TYPE_ACCOMPAGNEMENTTypeNew);
                            Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                            _Hashtable.put(new Long(IDType),new Long(newIDType));
                            listIDAdd.add(_Hashtable);
                        }
                    }
                    ////////////////////
                    
                }
            }
            
            //////////////////////////////////////////
            // ATTITUDES
            //////////////////////////////////////////
            long IDAttitude = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_Attitude(_ACCOMPAGNEMENT_GLOBALType3);
            
            if (_oldACCOMPAGNEMENTType2.hasATTITUDES()) {
                // Noeud ATTITUDEType
                ATTITUDEType _ATTITUDEType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Attitude(IDAttitude,_oldACCOMPAGNEMENTType2);
                
                ATTITUDESType _ATTITUDESType = XMLTools.FormationXMLParametrage.get_ParametrageModule_Attitudes(_newACCOMPAGNEMENTType2);
                // Cr�er un nouvelle ID dans la nouvelle formation
                newIDAttitude = getnewID(IDAttitude,_newFORMATIONType);
                boolean add = false;
                if (newIDAttitude <100){
                    // Champ par default n'existe pas dans la nouvelle formation
                    if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Attitude(IDAttitude,_newACCOMPAGNEMENTType2)==null){
                        add=true;
                    }
                } else{
                    add=true;
                }
                boolean alReadyAdd = alReadyAdd(IDAttitude,listIDAdd);
                // Ajout du noeud ATTITUDE � la nouvelle formation
                if (add){
                    if (alReadyAdd){
                        newIDAttitude = getIDinlistIDAdd(IDAttitude,listIDAdd);
                    } else {
                        ATTITUDEType _ATTITUDETypeNew = _ATTITUDESType.newATTITUDE();
                        _ATTITUDETypeNew.addnID(new SchemaLong(newIDAttitude));
                        _ATTITUDETypeNew.addtINTITULE_ATTITUDE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleAttitude(_ATTITUDEType)));
                        _ATTITUDETypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireAttitude(_ATTITUDEType)));
                        _ATTITUDESType.addATTITUDE(_ATTITUDETypeNew);
                        Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                        _Hashtable.put(new Long(IDAttitude),new Long(newIDAttitude));
                        listIDAdd.add(_Hashtable);
                    }
                }
            }
            //////////////////////////////////////////
            // GROUPE
            //////////////////////////////////////////
            long IDGroupe = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_Groupe(_ACCOMPAGNEMENT_GLOBALType3);
            
            if (_oldACCOMPAGNEMENTType2.hasSOUS_GROUPES()) {
                // Noeud SOUS_GROUPEType
                SOUS_GROUPEType _SOUS_GROUPEType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_SousGroupe(IDGroupe,_oldACCOMPAGNEMENTType2);
                
                SOUS_GROUPESType _SOUS_GROUPESType = XMLTools.FormationXMLParametrage.get_ParametrageModule_SousGroupe(_newACCOMPAGNEMENTType2);
                // Cr�er un nouvelle ID dans la nouvelle formation
                newIDGroupe = getnewID(IDGroupe,_newFORMATIONType);
                // Ajout du noeud SOUS GROUPE � la nouvelle formation
                boolean add = false;
                if (newIDGroupe <100){
                    // Champ par default n'existe pas dans la nouvelle formation
                    if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_SousGroupe(IDGroupe,_newACCOMPAGNEMENTType2)==null){
                        add=true;
                    }
                } else{
                    add=true;
                }
                boolean alReadyAdd = alReadyAdd(IDGroupe,listIDAdd);
                // Ajout du noeud SOUS GROUPE � la nouvelle formation
                if (add){
                    if (alReadyAdd){
                        newIDGroupe = getIDinlistIDAdd(IDGroupe,listIDAdd);
                    } else {
                        SOUS_GROUPEType _SOUS_GROUPETypeNew = _SOUS_GROUPESType.newSOUS_GROUPE();
                        _SOUS_GROUPETypeNew.addnID(new SchemaLong(newIDGroupe));
                        _SOUS_GROUPETypeNew.addtINTITULE_GROUPE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleSousGroupe(_SOUS_GROUPEType)));
                        _SOUS_GROUPETypeNew.addnNBRE_APPRENANT(new SchemaInt(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_NbreApprenantSousGroupe(_SOUS_GROUPEType)));
                        _SOUS_GROUPETypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireSousGroupe(_SOUS_GROUPEType)));
                        _SOUS_GROUPESType.addSOUS_GROUPE(_SOUS_GROUPETypeNew);
                        Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                        _Hashtable.put(new Long(IDGroupe),new Long(newIDGroupe));
                        listIDAdd.add(_Hashtable);
                    }
                }
            }
            
            
            //////////////////////////////////////////
            // Mise � jour de l'accompagnement courant suivant les nouveaux ID
            XMLTools.ModuleXMLProprietes.update_Proprietes_AccompagnementGlobal(newIDNom,newIDType,newIDAttitude,newIDGroupe,i,_ACCOMPAGNEMENTS_GLOBAUXType3);
            //////////////////////////////////////////
            
            
        }
        
        /////////////////////////////////////////
        // OUTIL D ECHANGE
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        long newIDOutil=0;
        
        nTYPE_OUTILType3 _nTYPE_OUTILType3 = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_TypeOutil(_ACCOMPAGNEMENT_MODULEType);
        long IDOutilEchange = _nTYPE_OUTILType3.getValue().getValue();
        
        if (_oldOUTILS_SERVICESType.hasOUTILS()){
            OUTILType _OUTILType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilEchange,_oldOUTILS_SERVICESType);
            OUTILSType _OUTILSType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_Outils(_newOUTILS_SERVICESType);
            
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDOutil = getnewID(IDOutilEchange,_newFORMATIONType);
            // Ajout du noeud OUTIL � la nouvelle formation
            boolean add = false;
            if (newIDOutil <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilEchange,_newOUTILS_SERVICESType)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDOutilEchange,listIDAdd);
            // Ajout du noeud OUTIL � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDOutil = getIDinlistIDAdd(IDOutilEchange,listIDAdd);
                } else {
                    OUTILType _OUTILTypeNew = _OUTILSType.newOUTIL();
                    _OUTILTypeNew.addnID(new SchemaLong(newIDOutil));
                    _OUTILTypeNew.addtINTITULE_OUTIL(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_IntituleOutil(_OUTILType)));
                    _OUTILTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CommentaireOutil(_OUTILType)));
                    _OUTILTypeNew.addnCATEGORIE_AFFICHAGE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CategorieOutil(_OUTILType)));
                    _OUTILTypeNew.addnCARACTERISTIQUE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CaracteristiqueOutil(_OUTILType)));
                    _OUTILSType.addOUTIL(_OUTILTypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDOutilEchange),new Long(newIDOutil));
                    listIDAdd.add(_Hashtable);
                }
            }
            /////////// Met � jour l'outil
            XMLTools.ModuleXMLProprietes.update_Proprietes_Accompagnement_TypeOutil(newIDOutil,_ACCOMPAGNEMENT_MODULEType);
            ////////////////////////////////////////////
        }
        
        /////////////////////////////////////////
        // OUTIL DE SUBSTITUTION
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        long newIDOutilSub=0;
        
        nOUTIL_SUBSTITUTIONType4 _nOUTIL_SUBSTITUTIONType4 = XMLTools.ModuleXMLProprietes.get_Proprietes_Accompagnement_OutilSubstitution(_ACCOMPAGNEMENT_MODULEType);
        long IDOutilSub = _nOUTIL_SUBSTITUTIONType4.getValue().getValue();
        
        if (_oldOUTILS_SERVICESType.hasOUTILS()){
            OUTILType _OUTILType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilSub,_oldOUTILS_SERVICESType);
            OUTILSType _OUTILSType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_Outils(_newOUTILS_SERVICESType);
            
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDOutilSub = getnewID(IDOutilSub,_newFORMATIONType);
            // Ajout du noeud OUTIL � la nouvelle formation
            boolean add = false;
            if (newIDOutilSub <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilSub,_newOUTILS_SERVICESType)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDOutilSub,listIDAdd);
            // Ajout du noeud OUTIL � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDOutilSub = getIDinlistIDAdd(IDOutilSub,listIDAdd);
                } else {
                    OUTILType _OUTILTypeNew = _OUTILSType.newOUTIL();
                    _OUTILTypeNew.addnID(new SchemaLong(newIDOutilSub));
                    _OUTILTypeNew.addtINTITULE_OUTIL(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_IntituleOutil(_OUTILType)));
                    _OUTILTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CommentaireOutil(_OUTILType)));
                    _OUTILTypeNew.addnCATEGORIE_AFFICHAGE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CategorieOutil(_OUTILType)));
                    _OUTILTypeNew.addnCARACTERISTIQUE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CaracteristiqueOutil(_OUTILType)));
                    _OUTILSType.addOUTIL(_OUTILTypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDOutilSub),new Long(newIDOutilSub));
                    listIDAdd.add(_Hashtable);
                }
            }
            /////////// Met � jour l'outil
            XMLTools.ModuleXMLProprietes.update_Proprietes_Accompagnement_OutilSubstitution(newIDOutilSub,_ACCOMPAGNEMENT_MODULEType);
            ////////////////////////////////////////////
        }
    }
    
    
    
    
    
    /**
     *
     *Importation des donn�es pour la SEQUENCE donn�e en parametre
     *
     */
    public void importDataofSequence(oSequence _oSequence){
        
        
        
    }
    
    /**
     *
     *Importation des donn�es pour l'ACTIVITE donn�e en parametre
     *
     */
    public void importDataofActivite(oActivite _oActivite){
        
        ACTIVITEType _ACTIVITEType = (ACTIVITEType)((XMLUserObject)_oActivite.getUserObject()).getXMLNode();
        
        // Parcours les prori�t� du module
        PROPRIETES_ACTIVITESType _PROPRIETES_ACTIVITESType = XMLTools.ActiviteXMLProprietes.get_Proprietes(_ACTIVITEType);
        DESCRIPTIF_ACTIVITEType _DESCRIPTIF_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif(_PROPRIETES_ACTIVITESType);
        PRODUCTION_ACTIVITEType _PRODUCTION_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Production(_PROPRIETES_ACTIVITESType);
        ACCOMPAGNEMENT_ACTIVITEType _ACCOMPAGNEMENT_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement(_PROPRIETES_ACTIVITESType);
        RESSOURCES_DOCS_ACTIVITEType _RESSOURCES_DOCS_ACTIVITEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Ressources(_PROPRIETES_ACTIVITESType);
        
        
        /// Parcours l'ancienne formation
        PARAM_MODULEType _oldPARAM_MODULEType = XMLTools.FormationXMLParametrage.get_ParametrageModule(_oldFORMATIONType);
        ACTIVITEType2 _oldACTIVITEType2 = XMLTools.FormationXMLParametrage.get_ParametrageModule_Activite(_oldPARAM_MODULEType);
        ACCOMPAGNEMENTType2 _oldACCOMPAGNEMENTType2 = XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement(_oldPARAM_MODULEType);
        RESSOURCES_DOCSType _oldRESSOURCES_DOCSType = XMLTools.FormationXMLParametrage.get_ParametrageModule_Ressources(_oldPARAM_MODULEType);
        PARAM_FORMATIONType _oldPARAM_FORMATIONType = XMLTools.FormationXMLParametrage.get_ParametrageFormation(_oldFORMATIONType);
        ACCOMPAGNEMENTType _oldACCOMPAGNEMENTType = XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement(_oldPARAM_FORMATIONType);
        OUTILS_SERVICESType _oldOUTILS_SERVICESType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices(_oldPARAM_FORMATIONType);
        
        /// Parcours la nouvelle formation
        PARAM_MODULEType _newPARAM_MODULEType = XMLTools.FormationXMLParametrage.get_ParametrageModule(_newFORMATIONType);
        ACTIVITEType2 _newACTIVITEType2 = XMLTools.FormationXMLParametrage.get_ParametrageModule_Activite(_newPARAM_MODULEType);
        ACCOMPAGNEMENTType2 _newACCOMPAGNEMENTType2 = XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement(_newPARAM_MODULEType);
        RESSOURCES_DOCSType _newRESSOURCES_DOCSType = XMLTools.FormationXMLParametrage.get_ParametrageModule_Ressources(_newPARAM_MODULEType);
        PARAM_FORMATIONType _newPARAM_FORMATIONType = XMLTools.FormationXMLParametrage.get_ParametrageFormation(_newFORMATIONType);
        ACCOMPAGNEMENTType _newACCOMPAGNEMENTType = XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement(_newPARAM_FORMATIONType);
        OUTILS_SERVICESType _newOUTILS_SERVICESType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices(_newPARAM_FORMATIONType);
        
        /////////////////////////////////////////
        // TYPE ACTIVITE
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        long newIDTypeActivite=0;
        
        nTYPEType _nTYPEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif_Type(_DESCRIPTIF_ACTIVITEType);
        long IDTypeActivite = _nTYPEType.getValue().getValue();
        
        if (_oldACTIVITEType2.hasTYPES_ACTIVITES()){
            
            TYPE_ACTIVITEType _TYPE_ACTIVITEType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Activites(IDTypeActivite,_oldACTIVITEType2);
            TYPES_ACTIVITESType _TYPES_ACTIVITESType = XMLTools.FormationXMLParametrage.get_ParametrageModule_TypesActivites(_newACTIVITEType2);
            
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDTypeActivite = getnewID(IDTypeActivite,_newFORMATIONType);
            // Ajout du noeud OUTIL � la nouvelle formation
            boolean add = false;
            if (newIDTypeActivite <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Activites(IDTypeActivite,_oldACTIVITEType2)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDTypeActivite,listIDAdd);
            // Ajout du noeud OUTIL � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDTypeActivite = getIDinlistIDAdd(IDTypeActivite,listIDAdd);
                } else {
                    TYPE_ACTIVITEType _TYPE_ACTIVITETypeNew = _TYPES_ACTIVITESType.newTYPE_ACTIVITE();
                    _TYPE_ACTIVITETypeNew.addnID(new SchemaLong(newIDTypeActivite));
                    _TYPE_ACTIVITETypeNew.addtINTITULE_ACTIVITE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Activites_IntituleActivite(_TYPE_ACTIVITEType)));
                    _TYPE_ACTIVITETypeNew.addnCOULEUR(new SchemaInt(XMLTools.FormationXMLParametrage.get_ParametrageModule_Activites_CouleurActivite(_TYPE_ACTIVITEType)));
                    _TYPE_ACTIVITETypeNew.addtDESCRIPTIF(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Activites_DescriptifActivite(_TYPE_ACTIVITEType)));
                    _TYPES_ACTIVITESType.addTYPE_ACTIVITE(_TYPE_ACTIVITETypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDTypeActivite),new Long(newIDTypeActivite));
                    listIDAdd.add(_Hashtable);
                }
            }
            /////////// Met � jour du type d'activite
            XMLTools.ActiviteXMLProprietes.update_Proprietes_Descriptif_TypeActivite(newIDTypeActivite,_DESCRIPTIF_ACTIVITEType);
            ////////////////////////////////////////////
        }
        
        /////////////////////////////////////////
        // TYPE DE TRAVAIL
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        long newIDTypeTravail=0;
        
        nINDIVIDUELCOLLECTIFType _nINDIVIDUELCOLLECTIFType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Descriptif_IndividuelColl(_DESCRIPTIF_ACTIVITEType);
        long IDTypeTravail = _nINDIVIDUELCOLLECTIFType.getValue().getValue();
        
        if (_oldACTIVITEType2.hasTYPES_TRAVAIL()){
            
            TYPE_TRAVAILType _TYPE_TRAVAILType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeTravail(IDTypeTravail,_oldACTIVITEType2);
            TYPES_TRAVAILType _TYPES_TRAVAILType = XMLTools.FormationXMLParametrage.get_ParametrageModule_TypesTravail(_newACTIVITEType2);
            
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDTypeTravail = getnewID(IDTypeTravail,_newFORMATIONType);
            // Ajout du noeud OUTIL � la nouvelle formation
            boolean add = false;
            if (newIDTypeTravail <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeTravail(IDTypeTravail,_oldACTIVITEType2)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDTypeTravail,listIDAdd);
            // Ajout du noeud OUTIL � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDTypeTravail = getIDinlistIDAdd(IDTypeTravail,listIDAdd);
                } else {
                    TYPE_TRAVAILType _TYPE_TRAVAILTypeNew = _TYPES_TRAVAILType.newTYPE_TRAVAIL();
                    _TYPE_TRAVAILTypeNew.addnID(new SchemaLong(newIDTypeTravail));
                    _TYPE_TRAVAILTypeNew.addtINTITULE_TRAVAIL(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_TypesTravail_Intitule(_TYPE_TRAVAILType)));
                    _TYPE_TRAVAILTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_TypesTravail_Commentaires(_TYPE_TRAVAILType)));
                    _TYPES_TRAVAILType.addTYPE_TRAVAIL(_TYPE_TRAVAILTypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDTypeTravail),new Long(newIDTypeTravail));
                    listIDAdd.add(_Hashtable);
                }
            }
            /////////// Met � jour du type d'activite
            XMLTools.ActiviteXMLProprietes.update_Proprietes_Descriptif_TypeTravail(newIDTypeTravail,_DESCRIPTIF_ACTIVITEType);
            ////////////////////////////////////////////
        }
        
        /////////////////////////////////////////
        // PRODUCTION A RENDRE --> OUTIL ECHANGE
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        long newIDOutilEchangeProd=0;
        
        nOUTIL_ECHANGEType _nOUTIL_ECHANGEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Production_OutilEchange(_PRODUCTION_ACTIVITEType);
        long IDOutilEchangeProd = _nOUTIL_ECHANGEType.getValue().getValue();
        
        if (_oldOUTILS_SERVICESType.hasOUTILS()){
            OUTILType _OUTILType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilEchangeProd,_oldOUTILS_SERVICESType);
            OUTILSType _OUTILSType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_Outils(_newOUTILS_SERVICESType);
            
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDOutilEchangeProd = getnewID(IDOutilEchangeProd,_newFORMATIONType);
            // Ajout du noeud OUTIL � la nouvelle formation
            boolean add = false;
            if (newIDOutilEchangeProd <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilEchangeProd,_newOUTILS_SERVICESType)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDOutilEchangeProd,listIDAdd);
            // Ajout du noeud OUTIL � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDOutilEchangeProd = getIDinlistIDAdd(IDOutilEchangeProd,listIDAdd);
                } else {
                    OUTILType _OUTILTypeNew = _OUTILSType.newOUTIL();
                    _OUTILTypeNew.addnID(new SchemaLong(newIDOutilEchangeProd));
                    _OUTILTypeNew.addtINTITULE_OUTIL(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_IntituleOutil(_OUTILType)));
                    _OUTILTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CommentaireOutil(_OUTILType)));
                    _OUTILTypeNew.addnCATEGORIE_AFFICHAGE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CategorieOutil(_OUTILType)));
                    _OUTILTypeNew.addnCARACTERISTIQUE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CaracteristiqueOutil(_OUTILType)));
                    _OUTILSType.addOUTIL(_OUTILTypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDOutilEchangeProd),new Long(newIDOutilEchangeProd));
                    listIDAdd.add(_Hashtable);
                }
            }
            /////////// Met � jour l'outil
            XMLTools.ActiviteXMLProprietes.update_Proprietes_Production_OutilEchange(newIDOutilEchangeProd,_PRODUCTION_ACTIVITEType);
            ////////////////////////////////////////////
        }
        
        /////////////////////////////////////////
        // PRODUCTION A RENDRE --> OUTIL STITITUTION
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        long newIDOutilSubProd=0;
        
        nOUTIL_SUBSTITUTIONType _nOUTIL_SUBSTITUTIONType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Production_OutilSubstitution(_PRODUCTION_ACTIVITEType);
        long IDOutilSubProd = _nOUTIL_SUBSTITUTIONType.getValue().getValue();
        
        if (_oldOUTILS_SERVICESType.hasOUTILS()){
            OUTILType _OUTILType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilSubProd,_oldOUTILS_SERVICESType);
            OUTILSType _OUTILSType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_Outils(_newOUTILS_SERVICESType);
            
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDOutilSubProd = getnewID(IDOutilSubProd,_newFORMATIONType);
            // Ajout du noeud OUTIL � la nouvelle formation
            boolean add = false;
            if (newIDOutilSubProd <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilSubProd,_newOUTILS_SERVICESType)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDOutilSubProd,listIDAdd);
            // Ajout du noeud OUTIL � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDOutilSubProd = getIDinlistIDAdd(IDOutilSubProd,listIDAdd);
                } else {
                    OUTILType _OUTILTypeNew = _OUTILSType.newOUTIL();
                    _OUTILTypeNew.addnID(new SchemaLong(newIDOutilSubProd));
                    _OUTILTypeNew.addtINTITULE_OUTIL(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_IntituleOutil(_OUTILType)));
                    _OUTILTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CommentaireOutil(_OUTILType)));
                    _OUTILTypeNew.addnCATEGORIE_AFFICHAGE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CategorieOutil(_OUTILType)));
                    _OUTILTypeNew.addnCARACTERISTIQUE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CaracteristiqueOutil(_OUTILType)));
                    _OUTILSType.addOUTIL(_OUTILTypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDOutilSubProd),new Long(newIDOutilSubProd));
                    listIDAdd.add(_Hashtable);
                }
            }
            /////////// Met � jour l'outil
            XMLTools.ActiviteXMLProprietes.update_Proprietes_Production_OutilSubstitution(newIDOutilSubProd,_PRODUCTION_ACTIVITEType);
            ////////////////////////////////////////////
        }
        
        //////////////////////////////////////////
        // ACCOMPAGNEMENT GLOBAUX
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ACCOMPAGNEMENTS_GLOBAUXType _ACCOMPAGNEMENTS_GLOBAUXType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_AccompagnementsGlobaux(_ACCOMPAGNEMENT_ACTIVITEType);
        // Pour chaque accompagnement r�el
        for (int i=1 ; i<_ACCOMPAGNEMENTS_GLOBAUXType.getACCOMPAGNEMENT_GLOBALCount();i++) {
            long newIDNom=0;
            long newIDType=0;
            long newIDAttitude=0;
            long newIDGroupe=0;
            long newIDAction=0;
            
            ACCOMPAGNEMENT_GLOBALType _ACCOMPAGNEMENT_GLOBALType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_AccompagnementsGlobaux(_ACCOMPAGNEMENTS_GLOBAUXType,i);
            
            
            //////////////////////////////////////////
            // NOM ACCOMPAGNATEUR
            //////////////////////////////////////////
            long IDNom = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_Nom(_ACCOMPAGNEMENT_GLOBALType);
            
            if (_oldACCOMPAGNEMENTType2.hasNOMS()) {
                // Noeud NOM
                NOMType _NOMType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Nom(IDNom,_oldACCOMPAGNEMENTType2);
                if (_NOMType != null) {
                    NOMSType _NOMSType = XMLTools.FormationXMLParametrage.get_ParametrageModule_Noms(_newACCOMPAGNEMENTType2);
                    // Cr�er un nouvelle ID dans la nouvelle formation
                    newIDNom = getnewID(IDNom,_newFORMATIONType);
                    boolean add = false;
                    if (newIDNom <100){
                        // Champ par default n'existe pas dans la nouvelle formation
                        if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Nom(IDNom,_newACCOMPAGNEMENTType2)==null){
                            add=true;
                        }
                    } else{
                        add=true;
                    }
                    boolean alReadyAdd = alReadyAdd(IDNom,listIDAdd);
                    // Ajout du noeud NOM � la nouvelle formation
                    if (add){
                        if (alReadyAdd){
                            newIDNom = getIDinlistIDAdd(IDNom,listIDAdd);
                        } else {
                            NOMType _NOMSTypeNew = _NOMSType.newNOM();
                            _NOMSTypeNew.addnID(new SchemaLong(newIDNom));
                            _NOMSTypeNew.addtINTITULE_NOM(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleNom(_NOMType)));
                            _NOMSTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireNom(_NOMType)));
                            _NOMSTypeNew.addtMEL(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_MelNom(_NOMType)));
                            _NOMSType.addNOM(_NOMSTypeNew);
                            Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                            _Hashtable.put(new Long(IDNom),new Long(newIDNom));
                            listIDAdd.add(_Hashtable);
                            
                        }
                        
                    }
                } else {
                    ACCOMPAGNATEURType _ACCOMPAGNATEURType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_Accompagnateur(IDNom,_oldACCOMPAGNEMENTType);
                    
                    ACCOMPAGNATEURSType _ACCOMPAGNATEURSType = XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_Accompagnateurs(_newACCOMPAGNEMENTType);
                    // Cr�er un nouvelle ID dans la nouvelle formation
                    newIDNom = getnewID(IDNom,_newFORMATIONType);
                    boolean add = false;
                    if (newIDNom <100){
                        // Champ par default n'existe pas dans la nouvelle formation
                        if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_Accompagnateur(IDNom,_newACCOMPAGNEMENTType)==null){
                            add=true;
                        }
                    } else{
                        add=true;
                    }
                    boolean alReadyAdd = alReadyAdd(IDNom,listIDAdd);
                    // Ajout du noeud NOM � la nouvelle formation
                    if (add){
                        if (alReadyAdd){
                            newIDNom = getIDinlistIDAdd(IDNom,listIDAdd);
                        } else {
                            ACCOMPAGNATEURType _ACCOMPAGNATEURTypeNew = _ACCOMPAGNATEURSType.newACCOMPAGNATEUR();
                            _ACCOMPAGNATEURTypeNew.addnID(new SchemaLong(newIDNom));
                            _ACCOMPAGNATEURTypeNew.addtINTITULE_ACCOMPAGNATEUR(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_IntituleAccompagnateur(_ACCOMPAGNATEURType)));
                            _ACCOMPAGNATEURTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_CommmentaireAccompagnateur(_ACCOMPAGNATEURType)));
                            _ACCOMPAGNATEURTypeNew.addtMEL(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_MelAccompagnateur(_ACCOMPAGNATEURType)));
                            _ACCOMPAGNATEURSType.addACCOMPAGNATEUR(_ACCOMPAGNATEURTypeNew);
                            Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                            _Hashtable.put(new Long(IDNom),new Long(newIDNom));
                            listIDAdd.add(_Hashtable);
                            
                        }
                        
                    }
                }
                ////////////////////////////
                ////////////////////////////                NOMSType _NOMSType = XMLTools.FormationXMLParametrage.get_ParametrageModule_Noms(_newACCOMPAGNEMENTType2);
                ////////////////////////////                // Cr�er un nouvelle ID dans la nouvelle formation
                ////////////////////////////                newIDNom = getnewID(IDNom,_newFORMATIONType);
                ////////////////////////////                boolean add = false;
                ////////////////////////////                if (newIDNom <100){
                ////////////////////////////                    // Champ par default n'existe pas dans la nouvelle formation
                ////////////////////////////                    if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Nom(IDNom,_newACCOMPAGNEMENTType2)==null){
                ////////////////////////////                        add=true;
                ////////////////////////////                    }
                ////////////////////////////                } else{
                ////////////////////////////                    add=true;
                ////////////////////////////                }
                ////////////////////////////                boolean alReadyAdd = alReadyAdd(IDNom,listIDAdd);
                ////////////////////////////                // Ajout du noeud NOM � la nouvelle formation
                ////////////////////////////                if (add){
                ////////////////////////////                    if (alReadyAdd){
                ////////////////////////////                        newIDNom = getIDinlistIDAdd(IDNom,listIDAdd);
                ////////////////////////////                    } else {
                ////////////////////////////                        NOMType _NOMSTypeNew = _NOMSType.newNOM();
                ////////////////////////////                        _NOMSTypeNew.addnID(new SchemaLong(newIDNom));
                ////////////////////////////                        _NOMSTypeNew.addtINTITULE_NOM(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleNom(_NOMType)));
                ////////////////////////////                        _NOMSTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireNom(_NOMType)));
                ////////////////////////////                        _NOMSTypeNew.addtMEL(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_MelNom(_NOMType)));
                ////////////////////////////                        _NOMSType.addNOM(_NOMSTypeNew);
                ////////////////////////////                        Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                ////////////////////////////                        _Hashtable.put(new Long(IDNom),new Long(newIDNom));
                ////////////////////////////                        listIDAdd.add(_Hashtable);
                ////////////////////////////
                ////////////////////////////                    }
                ////////////////////////////
                ////////////////////////////                }
            }
            //////////////////////////////////////////
            // TYPE ACCOMPAGNEMENT
            //////////////////////////////////////////
            long IDType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_Type(_ACCOMPAGNEMENT_GLOBALType);
            
            if (_oldACCOMPAGNEMENTType2.hasTYPES_ACCOMPAGNEMENT()) {
                // Noeud TYPE ACCOMPAGNEMENT
                TYPE_ACCOMPAGNEMENTType2 _TYPE_ACCOMPAGNEMENTType2 = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeAccompagnement(IDType,_oldACCOMPAGNEMENTType2);
                if (_TYPE_ACCOMPAGNEMENTType2 != null) {
                    TYPES_ACCOMPAGNEMENTType2 _TYPES_ACCOMPAGNEMENTType2 = XMLTools.FormationXMLParametrage.get_ParametrageModule_TypesAccompagnement(_newACCOMPAGNEMENTType2);
                    // Cr�er un nouvelle ID dans la nouvelle formation
                    newIDType = getnewID(IDType,_newFORMATIONType);
                    boolean add = false;
                    if (newIDType <100){
                        // Champ par default n'existe pas dans la nouvelle formation
                        if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeAccompagnement(IDType,_newACCOMPAGNEMENTType2)==null){
                            add=true;
                        }
                    } else{
                        add=true;
                    }
                    boolean alReadyAdd = alReadyAdd(IDType,listIDAdd);
                    // Ajout du noeud TYPE � la nouvelle formation
                    if (add){
                        if (alReadyAdd){
                            newIDType = getIDinlistIDAdd(IDType,listIDAdd);
                        } else {
                            TYPE_ACCOMPAGNEMENTType2 TYPE_ACCOMPAGNEMENTType2New = _TYPES_ACCOMPAGNEMENTType2.newTYPE_ACCOMPAGNEMENT();
                            TYPE_ACCOMPAGNEMENTType2New.addnID(new SchemaLong(newIDType));
                            TYPE_ACCOMPAGNEMENTType2New.addtINTITULE_TYPE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleTypeAccompagnement(_TYPE_ACCOMPAGNEMENTType2)));
                            TYPE_ACCOMPAGNEMENTType2New.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireTypeAccompagnement(_TYPE_ACCOMPAGNEMENTType2)));
                            _TYPES_ACCOMPAGNEMENTType2.addTYPE_ACCOMPAGNEMENT(TYPE_ACCOMPAGNEMENTType2New);
                            Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                            _Hashtable.put(new Long(IDType),new Long(newIDType));
                            listIDAdd.add(_Hashtable);
                        }
                    }
                } else{
                    TYPE_ACCOMPAGNEMENTType _TYPE_ACCOMPAGNEMENTType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_TypeAccompagnement(IDType,_oldACCOMPAGNEMENTType);
                    ////////////
                    TYPES_ACCOMPAGNEMENTType _TYPES_ACCOMPAGNEMENTType = XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_TypesAccompagnements(_newACCOMPAGNEMENTType);
                    // Cr�er un nouvelle ID dans la nouvelle formation
                    newIDType = getnewID(IDType,_newFORMATIONType);
                    boolean add = false;
                    if (newIDType <100){
                        // Champ par default n'existe pas dans la nouvelle formation
                        if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_TypeAccompagnement(IDType,_newACCOMPAGNEMENTType)==null){
                            add=true;
                        }
                    } else{
                        add=true;
                    }
                    boolean alReadyAdd = alReadyAdd(IDType,listIDAdd);
                    // Ajout du noeud TYPE � la nouvelle formation
                    if (add){
                        if (alReadyAdd){
                            newIDType = getIDinlistIDAdd(IDType,listIDAdd);
                        } else {
                            TYPE_ACCOMPAGNEMENTType _TYPE_ACCOMPAGNEMENTTypeNew = _TYPES_ACCOMPAGNEMENTType.newTYPE_ACCOMPAGNEMENT();
                            _TYPE_ACCOMPAGNEMENTTypeNew.addnID(new SchemaLong(newIDType));
                            _TYPE_ACCOMPAGNEMENTTypeNew.addtINTITULE_TYPE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_IntituleTypeAccompagnement(_TYPE_ACCOMPAGNEMENTType)));
                            _TYPE_ACCOMPAGNEMENTTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_Accompagnement_CommmentaireTypeAccompagnement(_TYPE_ACCOMPAGNEMENTType)));
                            _TYPES_ACCOMPAGNEMENTType.addTYPE_ACCOMPAGNEMENT(_TYPE_ACCOMPAGNEMENTTypeNew);
                            Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                            _Hashtable.put(new Long(IDType),new Long(newIDType));
                            listIDAdd.add(_Hashtable);
                        }
                    }
                    ////////////////////
                    
                    
                    
                    
                }
            }
            
            //////////////////////////////////////////
            // ATTITUDES
            //////////////////////////////////////////
            long IDAttitude = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_Attitude(_ACCOMPAGNEMENT_GLOBALType);
            
            if (_oldACCOMPAGNEMENTType2.hasATTITUDES()) {
                // Noeud ATTITUDEType
                ATTITUDEType _ATTITUDEType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Attitude(IDAttitude,_oldACCOMPAGNEMENTType2);
                
                ATTITUDESType _ATTITUDESType = XMLTools.FormationXMLParametrage.get_ParametrageModule_Attitudes(_newACCOMPAGNEMENTType2);
                // Cr�er un nouvelle ID dans la nouvelle formation
                newIDAttitude = getnewID(IDAttitude,_newFORMATIONType);
                boolean add = false;
                if (newIDAttitude <100){
                    // Champ par default n'existe pas dans la nouvelle formation
                    if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Attitude(IDAttitude,_newACCOMPAGNEMENTType2)==null){
                        add=true;
                    }
                } else{
                    add=true;
                }
                boolean alReadyAdd = alReadyAdd(IDAttitude,listIDAdd);
                // Ajout du noeud ATTITUDE � la nouvelle formation
                if (add){
                    if (alReadyAdd){
                        newIDAttitude = getIDinlistIDAdd(IDAttitude,listIDAdd);
                    } else {
                        ATTITUDEType _ATTITUDETypeNew = _ATTITUDESType.newATTITUDE();
                        _ATTITUDETypeNew.addnID(new SchemaLong(newIDAttitude));
                        _ATTITUDETypeNew.addtINTITULE_ATTITUDE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleAttitude(_ATTITUDEType)));
                        _ATTITUDETypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireAttitude(_ATTITUDEType)));
                        _ATTITUDESType.addATTITUDE(_ATTITUDETypeNew);
                        Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                        _Hashtable.put(new Long(IDAttitude),new Long(newIDAttitude));
                        listIDAdd.add(_Hashtable);
                    }
                }
            }
            //////////////////////////////////////////
            // ACTIONS
            //////////////////////////////////////////
            long IDAction = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_Action(_ACCOMPAGNEMENT_GLOBALType);
            
            if (_oldACCOMPAGNEMENTType2.hasACTIONS()) {
                // Noeud ATTITUDEType
                ACTIONType _ACTIONType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Action(IDAction,_oldACCOMPAGNEMENTType2);
                
                ACTIONSType _ACTIONSType = XMLTools.FormationXMLParametrage.get_ParametrageModule_Actions(_newACCOMPAGNEMENTType2);
                // Cr�er un nouvelle ID dans la nouvelle formation
                newIDAction = getnewID(IDAction,_newFORMATIONType);
                boolean add = false;
                if (newIDAction <100){
                    // Champ par default n'existe pas dans la nouvelle formation
                    if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_Action(IDAction,_newACCOMPAGNEMENTType2)==null){
                        add=true;
                    }
                } else{
                    add=true;
                }
                boolean alReadyAdd = alReadyAdd(IDAction,listIDAdd);
                // Ajout du noeud ATTITUDE � la nouvelle formation
                if (add){
                    if (alReadyAdd){
                        newIDAction = getIDinlistIDAdd(IDAction,listIDAdd);
                    } else {
                        ACTIONType _ACTIONTypeNew = _ACTIONSType.newACTION();
                        _ACTIONTypeNew.addnID(new SchemaLong(newIDAction));
                        _ACTIONTypeNew.addtINTITULE_ACTION(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleAction(_ACTIONType)));
                        _ACTIONTypeNew.addtCOMMENTAIRES(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireAction(_ACTIONType)));
                        _ACTIONSType.addACTION(_ACTIONTypeNew);
                        Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                        _Hashtable.put(new Long(IDAction),new Long(newIDAction));
                        listIDAdd.add(_Hashtable);
                    }
                }
            }
            
            
            //////////////////////////////////////////
            // GROUPE
            //////////////////////////////////////////
            long IDGroupe = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_Groupe(_ACCOMPAGNEMENT_GLOBALType);
            
            if (_oldACCOMPAGNEMENTType2.hasSOUS_GROUPES()) {
                // Noeud SOUS_GROUPEType
                SOUS_GROUPEType _SOUS_GROUPEType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_SousGroupe(IDGroupe,_oldACCOMPAGNEMENTType2);
                
                SOUS_GROUPESType _SOUS_GROUPESType = XMLTools.FormationXMLParametrage.get_ParametrageModule_SousGroupe(_newACCOMPAGNEMENTType2);
                // Cr�er un nouvelle ID dans la nouvelle formation
                newIDGroupe = getnewID(IDGroupe,_newFORMATIONType);
                // Ajout du noeud SOUS GROUPE � la nouvelle formation
                boolean add = false;
                if (newIDGroupe <100){
                    // Champ par default n'existe pas dans la nouvelle formation
                    if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_SousGroupe(IDGroupe,_newACCOMPAGNEMENTType2)==null){
                        add=true;
                    }
                } else{
                    add=true;
                }
                boolean alReadyAdd = alReadyAdd(IDGroupe,listIDAdd);
                // Ajout du noeud SOUS GROUPE � la nouvelle formation
                if (add){
                    if (alReadyAdd){
                        newIDGroupe = getIDinlistIDAdd(IDGroupe,listIDAdd);
                    } else {
                        SOUS_GROUPEType _SOUS_GROUPETypeNew = _SOUS_GROUPESType.newSOUS_GROUPE();
                        _SOUS_GROUPETypeNew.addnID(new SchemaLong(newIDGroupe));
                        _SOUS_GROUPETypeNew.addtINTITULE_GROUPE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_IntituleSousGroupe(_SOUS_GROUPEType)));
                        _SOUS_GROUPETypeNew.addnNBRE_APPRENANT(new SchemaInt(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_NbreApprenantSousGroupe(_SOUS_GROUPEType)));
                        _SOUS_GROUPETypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_Accompagnement_CommentaireSousGroupe(_SOUS_GROUPEType)));
                        _SOUS_GROUPESType.addSOUS_GROUPE(_SOUS_GROUPETypeNew);
                        Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                        _Hashtable.put(new Long(IDGroupe),new Long(newIDGroupe));
                        listIDAdd.add(_Hashtable);
                    }
                }
            }
            
            
            //////////////////////////////////////////
            // Mise � jour de l'accompagnement courant suivant les nouveaux ID
            XMLTools.ActiviteXMLProprietes.update_Proprietes_AccompagnementGlobal(newIDNom,newIDType,newIDAttitude,newIDAction,newIDGroupe,i,_ACCOMPAGNEMENTS_GLOBAUXType);
            //////////////////////////////////////////
            
            
        }
        
        
        /////////////////////////////////////////
        // OUTIL D ECHANGE
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        long newIDOutil=0;
        
        nTYPE_OUTILType _nTYPE_OUTILType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_TypeOutil(_ACCOMPAGNEMENT_ACTIVITEType);
        long IDOutilEchange = _nTYPE_OUTILType.getValue().getValue();
        
        if (_oldOUTILS_SERVICESType.hasOUTILS()){
            OUTILType _OUTILType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilEchange,_oldOUTILS_SERVICESType);
            OUTILSType _OUTILSType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_Outils(_newOUTILS_SERVICESType);
            
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDOutil = getnewID(IDOutilEchange,_newFORMATIONType);
            // Ajout du noeud OUTIL � la nouvelle formation
            boolean add = false;
            if (newIDOutil <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilEchange,_newOUTILS_SERVICESType)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDOutilEchange,listIDAdd);
            // Ajout du noeud OUTIL � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDOutil = getIDinlistIDAdd(IDOutilEchange,listIDAdd);
                } else {
                    OUTILType _OUTILTypeNew = _OUTILSType.newOUTIL();
                    _OUTILTypeNew.addnID(new SchemaLong(newIDOutil));
                    _OUTILTypeNew.addtINTITULE_OUTIL(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_IntituleOutil(_OUTILType)));
                    _OUTILTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CommentaireOutil(_OUTILType)));
                    _OUTILTypeNew.addnCATEGORIE_AFFICHAGE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CategorieOutil(_OUTILType)));
                    _OUTILTypeNew.addnCARACTERISTIQUE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CaracteristiqueOutil(_OUTILType)));
                    _OUTILSType.addOUTIL(_OUTILTypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDOutilEchange),new Long(newIDOutil));
                    listIDAdd.add(_Hashtable);
                }
            }
            /////////// Met � jour l'outil
            XMLTools.ActiviteXMLProprietes.update_Proprietes_Accompagnement_TypeOutil(newIDOutil,_ACCOMPAGNEMENT_ACTIVITEType);
            ////////////////////////////////////////////
        }
        
        /////////////////////////////////////////
        // OUTIL DE SUBSTITUTION
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        long newIDOutilSub=0;
        
        nOUTIL_SUBSTITUTIONType2 _nOUTIL_SUBSTITUTIONType2 = XMLTools.ActiviteXMLProprietes.get_Proprietes_Accompagnement_OutilSubstitution(_ACCOMPAGNEMENT_ACTIVITEType);
        long IDOutilSub = _nOUTIL_SUBSTITUTIONType2.getValue().getValue();
        
        if (_oldOUTILS_SERVICESType.hasOUTILS()){
            OUTILType _OUTILType = XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilSub,_oldOUTILS_SERVICESType);
            OUTILSType _OUTILSType = XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_Outils(_newOUTILS_SERVICESType);
            
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDOutilSub = getnewID(IDOutilSub,_newFORMATIONType);
            // Ajout du noeud OUTIL � la nouvelle formation
            boolean add = false;
            if (newIDOutilSub <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_Parametrage_Outil(IDOutilSub,_newOUTILS_SERVICESType)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDOutilSub,listIDAdd);
            // Ajout du noeud OUTIL � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDOutilSub = getIDinlistIDAdd(IDOutilSub,listIDAdd);
                } else {
                    OUTILType _OUTILTypeNew = _OUTILSType.newOUTIL();
                    _OUTILTypeNew.addnID(new SchemaLong(newIDOutilSub));
                    _OUTILTypeNew.addtINTITULE_OUTIL(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_IntituleOutil(_OUTILType)));
                    _OUTILTypeNew.addtCOMMENTAIRE(new SchemaString(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CommentaireOutil(_OUTILType)));
                    _OUTILTypeNew.addnCATEGORIE_AFFICHAGE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CategorieOutil(_OUTILType)));
                    _OUTILTypeNew.addnCARACTERISTIQUE(new SchemaInt(XMLTools.FormationXMLParametrage.get_Parametrage_OutilsServices_CaracteristiqueOutil(_OUTILType)));
                    _OUTILSType.addOUTIL(_OUTILTypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDOutilSub),new Long(newIDOutilSub));
                    listIDAdd.add(_Hashtable);
                }
            }
            /////////// Met � jour l'outil
            XMLTools.ActiviteXMLProprietes.update_Proprietes_Accompagnement_OutilSubstitution(newIDOutilSub,_ACCOMPAGNEMENT_ACTIVITEType);
            ////////////////////////////////////////////
        }
        /////////////////////////////////////////
        // RESSOURCES PEDAGOGIQUES
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        RESSOURCES_PEDAGOGIQUESType _RESSOURCES_PEDAGOGIQUESType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Ressources_Pedagogiques(_RESSOURCES_DOCS_ACTIVITEType);
        // Pour chaque accompagnement r�el
        for (int i=1 ; i<_RESSOURCES_PEDAGOGIQUESType.getRESSOURCE_PEDAGOGIQUECount();i++) {
            long newIDTypeRessource=0;
            
            RESSOURCE_PEDAGOGIQUEType _RESSOURCE_PEDAGOGIQUEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Ressources_Pedagogiques_RessourcePedagogique(_RESSOURCES_PEDAGOGIQUESType,i);
            
            
            //////////////////////////////////////////
            // TYPE RESSOURCE
            //////////////////////////////////////////
            long IDTypeRessource = XMLTools.ActiviteXMLProprietes.get_Proprietes_Ressources_Pedagogiques_Type(_RESSOURCE_PEDAGOGIQUEType);
            
            if (_oldRESSOURCES_DOCSType.hasTYPES_RESSOURCES()) {
                // Noeud TYPE RESSOURCE
                TYPE_RESSOURCEType _TYPE_RESSOURCEType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeRessource(IDTypeRessource,_oldRESSOURCES_DOCSType);
                
                TYPES_RESSOURCESType _TYPES_RESSOURCESType = XMLTools.FormationXMLParametrage.get_ParametrageModule_TypesRessource(_newRESSOURCES_DOCSType);
                // Cr�er un nouvelle ID dans la nouvelle formation
                newIDTypeRessource = getnewID(IDTypeRessource,_newFORMATIONType);
                boolean add = false;
                if (newIDTypeRessource <100){
                    // Champ par default n'existe pas dans la nouvelle formation
                    if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeRessource(IDTypeRessource,_newRESSOURCES_DOCSType)==null){
                        add=true;
                    }
                } else{
                    add=true;
                }
                boolean alReadyAdd = alReadyAdd(IDTypeRessource,listIDAdd);
                // Ajout du noeud NOM � la nouvelle formation
                if (add){
                    if (alReadyAdd){
                        newIDTypeRessource = getIDinlistIDAdd(IDTypeRessource,listIDAdd);
                    } else {
                        TYPE_RESSOURCEType _TYPE_RESSOURCETypeNew = _TYPES_RESSOURCESType.newTYPE_RESSOURCE();
                        _TYPE_RESSOURCETypeNew.addnID(new SchemaLong(newIDTypeRessource));
                        _TYPE_RESSOURCETypeNew.addtINTITULE_RESSOURCES(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_TypeRessource_Intitule(_TYPE_RESSOURCEType)));
                        _TYPE_RESSOURCETypeNew.addtCOMMENTAIRES(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_TypeRessource_Commentaires(_TYPE_RESSOURCEType)));
                        _TYPES_RESSOURCESType.addTYPE_RESSOURCE(_TYPE_RESSOURCETypeNew);
                        Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                        _Hashtable.put(new Long(IDTypeRessource),new Long(newIDTypeRessource));
                        listIDAdd.add(_Hashtable);
                        
                    }
                    
                }
            }
            
        }
        /////////////////////////////////////////
        // TYPE DE SALLE
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        RESSOURCES_LOGISTIQUESType _RESSOURCES_LOGISTIQUESType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Ressources_Logistiques(_RESSOURCES_DOCS_ACTIVITEType);
        
        long newIDTypeSalle=0;
        
        nTYPE_SALLEType _nTYPE_SALLEType = XMLTools.ActiviteXMLProprietes.get_Proprietes_Ressources_Logistiques_TypeSalle(_RESSOURCES_LOGISTIQUESType);
        long IDTypeSalle = _nTYPE_SALLEType.getValue().getValue();
        
        if (_oldRESSOURCES_DOCSType.hasTYPES_SALLES()){
            // Noeud TYPE RESSOURCE
            TYPE_SALLEType _TYPE_SALLEType = XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeSalle(IDTypeSalle,_oldRESSOURCES_DOCSType);
            
            TYPES_SALLESType _TYPES_SALLESType = XMLTools.FormationXMLParametrage.get_ParametrageModule_TypesSalle(_newRESSOURCES_DOCSType);
            // Cr�er un nouvelle ID dans la nouvelle formation
            newIDTypeSalle = getnewID(IDTypeSalle,_newFORMATIONType);
            boolean add = false;
            if (newIDTypeSalle <100){
                // Champ par default n'existe pas dans la nouvelle formation
                if (XMLTools.FormationXMLParametrage.getwithID_ParametrageModule_TypeSalle(IDTypeSalle,_newRESSOURCES_DOCSType)==null){
                    add=true;
                }
            } else{
                add=true;
            }
            boolean alReadyAdd = alReadyAdd(IDTypeSalle,listIDAdd);
            // Ajout du noeud NOM � la nouvelle formation
            if (add){
                if (alReadyAdd){
                    newIDTypeSalle = getIDinlistIDAdd(IDTypeSalle,listIDAdd);
                } else {
                    TYPE_SALLEType _TYPE_SALLETypeNew = _TYPES_SALLESType.newTYPE_SALLE();
                    _TYPE_SALLETypeNew.addnID(new SchemaLong(newIDTypeSalle));
                    _TYPE_SALLETypeNew.addtINTITULE_SALLE(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_TypeSalle_Intitule(_TYPE_SALLEType)));
                    _TYPE_SALLETypeNew.addtCOMMENTAIRES(new SchemaString(XMLTools.FormationXMLParametrage.get_ParametrageModule_TypeSalle_Commentaires(_TYPE_SALLEType)));
                    _TYPES_SALLESType.addTYPE_SALLE(_TYPE_SALLETypeNew);
                    Hashtable<Long,Long> _Hashtable = new Hashtable<Long,Long>();
                    _Hashtable.put(new Long(IDTypeSalle),new Long(newIDTypeSalle));
                    listIDAdd.add(_Hashtable);
                    
                }
                
            }
            /////////// Met � jour du type d'activite
            XMLTools.ActiviteXMLProprietes.update_Proprietes_Descriptif_TypeSalle(newIDTypeSalle,_RESSOURCES_LOGISTIQUESType);
            ////////////////////////////////////////////
        }
        
    }
    
    /**
     *Renvoi true si l'ID donner en parametre � d�ja �t� ajouter
     *
     */
    private boolean alReadyAdd(long ID,ArrayList<Hashtable> listIDAdd){
        boolean exist = false;
        for(int i=0;i<listIDAdd.size();i++) {
            boolean GoodItem = listIDAdd.get(i).containsKey(ID);
            if (GoodItem)
                exist = true;
        }
        
        return exist;
        
    }
    
    /**
     *
     *Retourne le nouvelle ID attribuer pr�cedement � l' ancien ID donner en parametre
     *
     */
    private long getIDinlistIDAdd(long ID,ArrayList<Hashtable> listIDAdd){
        long value = ID;
        for(int i=0;i<listIDAdd.size();i++) {
            boolean GoodItem = listIDAdd.get(i).containsKey(ID);
            if (GoodItem)
                value = (Long)listIDAdd.get(i).get(ID);
        }
        
        return value;
        
    }
    
    /**
     *
     *Genere un nouvelle ID suivant le cas
     *SI ID < 100 --> je le garde
     *SI ID > 100 --> je cr�er un nouvelle ID avec l'ID_GENERAL de la nouvelle formation
     *
     *
     */
    private long getnewID(long oldID,FORMATIONType newFORMATIONType){
        long newID = 0;
        if (oldID > 99){
            newID = XMLTools.FormationXMLParametrage.get_IDGENERAL(newFORMATIONType) + 1;
            // MAJ l'id Generale
            XMLTools.FormationXMLParametrage.update_IDGENERAL(newFORMATIONType,newID);
        } else
            newID = oldID;
        
        return newID;
    }
    
    
}
